
let currentLesson=null, reviewCards=[], reviewIndex=0, translationIndex=0;
let rememberedSet=new Set(), notRememberedSet=new Set();
let quizState=null;
const $=id=>document.getElementById(id);
const normalize=s=>String(s||"").trim().replace(/[\s，。！？、,.!?；;：“”"'（）()]/g,"");
const escapeHtml=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));

const PROGRESS_KEY="yuhua_hsk3_progress_v16";
const REVIEW_KEY="yuhua_hsk3_review_v16";

const HSK_LEVELS = [
  {level:1, title:"HSK 1", status:"ready", desc:"15 bài theo New HSK Course 1."},
  {level:2, title:"HSK 2", status:"ready", desc:"15 bài theo New HSK Course 2."},
  {level:3, title:"HSK 3", status:"ready", desc:""},
  {level:4, title:"HSK 4", status:"ready", desc:"20 bài theo 新HSK教程4上、下"},
  {level:5, title:"HSK 5", status:"coming", desc:""},
  {level:6, title:"HSK 6", status:"coming", desc:""}
];
let selectedHSKLevel = 3;
let selectedHSKSystem = "3.0";

const HSK_SYSTEMS = [
  {
    id:"3.0",
    title:"HSK 3.0",
    subtitle:"新HSK 3.0",
    desc:"Chương trình hiện có của website. Toàn bộ dữ liệu HSK 1–6 hiện tại thuộc hệ HSK 3.0."
  },
  {
    id:"2.0",
    title:"HSK 2.0",
    subtitle:"旧HSK / HSK 2.0",
    desc:"Khung HSK 2.0 được chia thành HSK 1–6 để bổ sung nội dung riêng."
  }
];

function currentLevelData(){
  if(selectedHSKSystem!=="3.0") return [];
  if(selectedHSKLevel===1) return HSK1_DATA;
  if(selectedHSKLevel===2) return HSK2_DATA;
  if(selectedHSKLevel===3) return HSK3_DATA;
  if(selectedHSKLevel===4) return HSK4_DATA;
  return [];
}
function isHSK1(){ return selectedHSKLevel===1; }
function isHSK2(){ return selectedHSKLevel===2; }

const totalWords=HSK3_DATA.reduce((s,l)=>s+(l.words?.length||0),0);
const textCount=HSK3_DATA.reduce((s,l)=>s+(l.texts?.length||0),0);
$("globalStat").textContent=`HSK 3.0 + HSK 2.0 • HSK 1–6 • v30`;

function loadStore(key){
  try{return JSON.parse(localStorage.getItem(key)||"{}")}catch{return {}}
}
function saveStore(key,data){localStorage.setItem(key,JSON.stringify(data))}
function lessonProgressKey(n){return selectedHSKSystem==="3.0" && selectedHSKLevel===3 ? String(n) : `${selectedHSKSystem}:${selectedHSKLevel}:${n}`}
function getProgressData(){return loadStore(PROGRESS_KEY)}
function setCompleted(n,module,done=true){
  const all=getProgressData();
  const k=lessonProgressKey(n);
  all[k]=all[k]||{};
  if(done) all[k][module]=true; else delete all[k][module];
  saveStore(PROGRESS_KEY,all);
  updateProgressUI();
}
function isCompleted(n,module){
  const all=getProgressData();
  return !!all?.[lessonProgressKey(n)]?.[module];
}
function availableModules(l){
  const mods=(l.words||[]).length?["vocab"]:[];
  if(selectedHSKLevel===4 && l.grammar?.length) mods.push("grammar");
  (l.texts||[]).forEach(t=>mods.push(`text${t.id}`));
  if((l.words||[]).length) mods.push("review");
  if((l.translations||[]).length) mods.push("translate");
  if((l.texts||[]).length) mods.push("fill","quiz");
  return mods;
}
function lessonPercent(l){
  const mods=availableModules(l);
  const done=mods.filter(m=>isCompleted(l.n,m)).length;
  return mods.length?Math.round(done/mods.length*100):0;
}
function updateProgressUI(){
  const allModules=currentLevelData().flatMap(l=>availableModules(l).map(m=>[l.n,m]));
  const completed=allModules.filter(([n,m])=>isCompleted(n,m)).length;
  const pct=allModules.length?Math.round(completed/allModules.length*100):0;
  if($("overallProgressText")) $("overallProgressText").textContent=`${pct}% hoàn thành`;
  if($("overallProgressBar")) $("overallProgressBar").style.width=`${pct}%`;
  if(currentLesson && $("lesson").classList.contains("active") && $("lessonProgressText")){
    const lp=lessonPercent(currentLesson);
    $("lessonProgressText").textContent=`${lp}%`;
    $("lessonProgressBar").style.width=`${lp}%`;
  }
  renderLessons();
  updateModuleCompletionBadges();
}
function updateModuleCompletionBadges(){
  if(!currentLesson || !$("lesson").classList.contains("active"))return;
  document.querySelectorAll("[data-module]").forEach(btn=>{
    const mod=btn.dataset.module;
    btn.classList.toggle("module-done",isCompleted(currentLesson.n,mod));
    let check=btn.querySelector(".module-check");
    if(isCompleted(currentLesson.n,mod)){
      if(!check){
        check=document.createElement("em");
        check.className="module-check";
        check.textContent="✓ Đã học";
        btn.appendChild(check);
      }
    }else if(check) check.remove();
  });
}

function statusText(l){
  if(l.sourceUnavailable) return `<span class="badge missing">Chưa có nội dung</span>`;
  const n=l.texts?.length||0;
  return `<span class="badge ${n===4?"complete":"partial"}">${n===4?"✓ ":"Có "}${n}/4 bài khóa</span>`;
}
function renderLessons(){
  const container=$("levelContent");
  if(!container)return;

  const lvl=HSK_LEVELS.find(x=>x.level===selectedHSKLevel);
  const data=currentLevelData();
  const systemLabel=`HSK ${selectedHSKSystem}`;
  const levelLabel=`HSK ${selectedHSKLevel}`;

  if(!data.length){
    container.innerHTML=`
      <div class="coming-level curriculum-empty">
        <div class="coming-icon">📘</div>
        <h3>${systemLabel} • ${levelLabel}</h3>
        <p class="muted">Chưa có nội dung được nhập cho cấp độ này.</p>
      </div>`;
    return;
  }

  container.innerHTML=`
    <div class="level-action-grid">
      <div class="level-review-entry">
        <div>
          <div class="kicker">Tổng kết trình độ • ${systemLabel}</div>
          <h3>Ôn tập ${levelLabel}</h3>
          <p class="muted">Tổng hợp toàn bộ từ vựng của ${levelLabel} thuộc ${systemLabel} và làm một bài tập chung.</p>
        </div>
        <button class="primary" onclick="renderLevelReview(${selectedHSKLevel})">Bắt đầu ôn tập</button>
      </div>

      <div class="level-final-test-entry">
        <div>
          <div class="kicker">Kiểm tra cuối khóa • ${systemLabel}</div>
          <h3>Final Test ${levelLabel}</h3>
          <p class="muted">Bài kiểm tra tổng hợp từ vựng, pinyin và nội dung bài khóa của toàn bộ cấp độ.</p>
        </div>
        <button class="final-test-btn" onclick="renderFinalCourseTest(${selectedHSKLevel})">Làm test cuối khóa</button>
      </div>
    </div>

    <h2 class="lesson-heading">Các bài ${levelLabel} • ${systemLabel}</h2>
    <div id="lessonGrid" class="lesson-grid"></div>`;

  const grid=$("lessonGrid");
  grid.innerHTML=data.map(l=>{
    if(selectedHSKLevel===1 || selectedHSKLevel===2){
      const textCount=(l.texts||[]).length;
      const wordCount=(l.words||[]).length;
      return `<button class="lesson-card" onclick="openLesson(${l.n})">
        <div class="lesson-num">BÀI ${l.n}</div>
        <h3>${escapeHtml(l.title)}</h3>
        ${selectedHSKLevel===2?`<div class="grammar-mini">${(l.grammar||[]).map(g=>`<span>${escapeHtml(g)}</span>`).join("")}</div>`:""}
        <div class="muted" style="margin-top:10px">${wordCount} từ • ${textCount} bài khóa</div>
      </button>`;
    }

    const pct=lessonPercent(l);
    return `${selectedHSKLevel===4 && (l.n===1||l.n===11)?`<h3 class="hsk-volume-heading">${l.n===1?"HSK 4 – Quyển thượng (Bài 1–10)":"HSK 4 – Quyển hạ (Bài 11–20)"}</h3>`:""}<button class="lesson-card" onclick="openLesson(${l.n})">
      <div class="lesson-num">BÀI ${l.n}</div>
      <h3>${escapeHtml(l.title)}</h3>
      ${statusText(l)}
      <div class="muted" style="margin-top:8px">${l.words?.length||0} từ • ${l.texts?.length||0}/4 bài khóa</div>
      <div class="lesson-progress-mini">
        <span>${pct}%</span><div class="progress-track small"><div class="progress-bar" style="width:${pct}%"></div></div>
      </div>
    </button>`;
  }).join("");
}

function renderHomeTeacher(){
  $("homePanel").innerHTML=`
    <div class="home-panel-card">
      <div class="panel-title-row">
        <div>
          <div class="kicker">Giáo viên</div>
          <h2>Thông tin giáo viên</h2>
        </div>
        <button class="ghost" onclick="closeHomePanel()">Đóng</button>
      </div>

      <div class="teacher-profile">
        <div class="teacher-avatar">👩‍🏫</div>
        <div class="teacher-details">
          <h3>YuHua Chinese</h3>
          <p>Giáo viên tiếng Trung</p>
          <div class="info-note">
            Bạn có thể chỉnh tên giáo viên, thông tin liên hệ, kinh nghiệm giảng dạy và lời giới thiệu trong file <b>app-v19.js</b>.
          </div>
        </div>
      </div>
    </div>`;
}

function renderHomeClass(){
  $("homePanel").innerHTML=`
    <div class="home-panel-card">
      <div class="panel-title-row">
        <div>
          <div class="kicker">Lớp học</div>
          <h2>Thông tin lớp học</h2>
        </div>
        <button class="ghost" onclick="closeHomePanel()">Đóng</button>
      </div>

      <div class="class-info-grid">
        <div class="class-info-item">
          <span>📘</span>
          <div><b>Chương trình học</b><p>HSK 1 – HSK 6</p></div>
        </div>
        <div class="class-info-item">
          <span>🗓️</span>
          <div><b>Lịch học</b><p>Thông tin lịch học có thể bổ sung tại đây.</p></div>
        </div>
        <div class="class-info-item">
          <span>🎯</span>
          <div><b>Mục tiêu</b><p>Học từ vựng, bài khóa và luyện tập theo từng trình độ.</p></div>
        </div>
      </div>
    </div>`;
}

function renderHomeReview(){
  $("homePanel").innerHTML=`
    <div class="home-panel-card">
      <div class="panel-title-row">
        <div>
          <div class="kicker">Ôn tập bài học</div>
          <h2>Chọn chương trình HSK</h2>
          <p class="muted">Bước 1: chọn HSK 3.0 hoặc HSK 2.0. Bước 2: chọn cấp HSK 1–6.</p>
        </div>
        <button class="ghost" onclick="closeHomePanel()">Đóng</button>
      </div>

      <div id="systemGrid" class="system-grid"></div>

      <div class="curriculum-level-section">
        <div class="curriculum-level-head">
          <div>
            <div class="kicker">Cấp độ</div>
            <h3 id="selectedSystemTitle">HSK 3.0</h3>
          </div>
          <div id="selectedSystemDesc" class="muted"></div>
        </div>

        <div id="levelGrid" class="level-grid review-level-grid"></div>
      </div>

      <div id="selectedLevelPanel" class="selected-level-panel">
        <div class="level-panel-head">
          <div>
            <div class="kicker" id="selectedLevelKicker">Trình độ đang chọn</div>
            <h2 id="selectedLevelTitle">HSK 3</h2>
            <p id="selectedLevelDesc" class="muted"></p>
          </div>
          <span id="selectedLevelStatus" class="badge complete" style="display:none"></span>
        </div>

        <div id="hsk3ProgressWrap" class="home-progress">
          <div>
            <div class="kicker" id="levelProgressLabel">Tiến độ HSK 3 của bạn</div>
            <h3 id="overallProgressText">0% hoàn thành</h3>
          </div>
          <div class="progress-track"><div id="overallProgressBar" class="progress-bar"></div></div>
          <button id="resetProgressBtn" class="ghost">Đặt lại tiến độ</button>
        </div>

        <div id="levelContent"></div>
      </div>
    </div>`;

  const resetBtn=$("resetProgressBtn");
  if(resetBtn){
    resetBtn.onclick=()=>{
      if(confirm("Xóa tiến độ của cấp HSK đang chọn trên thiết bị này?")){
        const prefix=`${selectedHSKSystem}:${selectedHSKLevel}:`;
        for(const key of [PROGRESS_KEY,REVIEW_KEY]){const data=loadStore(key);for(const k of Object.keys(data)){if(selectedHSKLevel===3 ? /^\d+$/.test(k):k.startsWith(prefix))delete data[k]}saveStore(key,data)}
        updateProgressUI();
      }
    };
  }

  renderSystemGrid();
  renderLevelGrid();
  selectHSKSystem(selectedHSKSystem, false);
  selectHSKLevel(selectedHSKLevel, false);
}

window.openHomePanel=type=>{
  const panel=$("homePanel");
  panel.classList.remove("hidden");

  if(type==="teacher") renderHomeTeacher();
  else if(type==="class") renderHomeClass();
  else renderHomeReview();

  setTimeout(()=>panel.scrollIntoView({behavior:"smooth",block:"start"}),50);
};

window.closeHomePanel=()=>{
  const panel=$("homePanel");
  panel.classList.add("hidden");
  panel.innerHTML="";
};

function renderSystemGrid(){
  const grid=$("systemGrid");
  if(!grid)return;
  grid.innerHTML=HSK_SYSTEMS.map(s=>`
    <button class="system-card ${selectedHSKSystem===s.id?"active":""}"
      onclick="selectHSKSystem('${s.id}')">
      <div class="system-icon">${s.id==="3.0"?"新":"旧"}</div>
      <div>
        <b>${s.title}</b>
        <small>${s.subtitle}</small>
      </div>
    </button>`).join("");
}

window.selectHSKSystem=(system,doScroll=true)=>{
  selectedHSKSystem=system;
  const s=HSK_SYSTEMS.find(x=>x.id===system);
  if($("selectedSystemTitle")) $("selectedSystemTitle").textContent=s.title;
  if($("selectedSystemDesc")) $("selectedSystemDesc").textContent=s.desc;

  // Use HSK 3 as default inside HSK 3.0; HSK 1 as default for the new HSK 2.0 branch.
  if(system==="2.0" && selectedHSKLevel>6) selectedHSKLevel=1;

  renderSystemGrid();
  renderLevelGrid();
  selectHSKLevel(selectedHSKLevel,false);

  if(doScroll && $("selectedLevelPanel")){
    window.scrollTo({top:$("selectedLevelPanel").offsetTop-20,behavior:"smooth"});
  }
};

function renderLevelGrid(){
  const grid=$("levelGrid");
  if(!grid)return;
  grid.innerHTML=HSK_LEVELS.map(l=>`
    <button class="level-card ${selectedHSKLevel===l.level?"active":""}"
      onclick="selectHSKLevel(${l.level})">
      <div class="level-number">${l.level}</div>
      <div class="level-card-body">
        <b>${l.title}</b>
      </div>
    </button>`).join("");
}

window.selectHSKLevel=(level,doScroll=true)=>{
  selectedHSKLevel=level;
  const lvl=HSK_LEVELS.find(x=>x.level===level);
  if(!$("selectedLevelTitle")) return;

  $("selectedLevelTitle").textContent=`${lvl.title} • HSK ${selectedHSKSystem}`;
  $("selectedLevelDesc").textContent =
    selectedHSKSystem==="3.0"
      ? (currentLevelData().length ? "Nội dung hiện có thuộc hệ HSK 3.0." : "")
      : "";
  $("selectedLevelKicker").textContent=`Trình độ đang chọn • HSK ${selectedHSKSystem}`;

  const status=$("selectedLevelStatus");
  if(status) status.style.display="none";

  // Existing localStorage progress is currently only for the HSK3 level content under HSK 3.0.
  if($("hsk3ProgressWrap")){
    $("hsk3ProgressWrap").style.display =
      (selectedHSKSystem==="3.0" && [3,4].includes(level)) ? "" : "none";
    $("levelProgressLabel").textContent=`Tiến độ HSK ${level} của bạn`;
  }

  renderLevelGrid();
  updateProgressUI();

  if(doScroll && $("selectedLevelPanel")){
    window.scrollTo({top:$("selectedLevelPanel").offsetTop-20,behavior:"smooth"});
  }
};

window.openLesson=n=>{
  currentLesson=currentLevelData().find(x=>x.n===n);
  if(!currentLesson)return;
  reviewIndex=0;translationIndex=0;
  $("home").classList.remove("active");$("lesson").classList.add("active");
  $("backBtn").textContent=`← HSK ${selectedHSKSystem} / HSK ${selectedHSKLevel} / Các bài`;
  $("lessonNo").textContent=`BÀI ${currentLesson.n} • HSK ${selectedHSKSystem} • HSK ${selectedHSKLevel}`;
  $("lessonTitle").textContent=currentLesson.title;

  if(isHSK1()){
    $("lessonStatus").innerHTML=`
      <div class="hsk2-source-meta">
        <span class="badge complete">New HSK Course 1</span>
        <span class="muted">${(currentLesson.words||[]).length} từ • ${(currentLesson.texts||[]).length} bài khóa</span>
      </div>`;
    configureHsk1Modules();
    $("lessonBreadcrumb").textContent=`HSK ${selectedHSKSystem} / HSK 1 / Bài ${currentLesson.n}`;
    showModule("vocab");
  }else if(isHSK2()){
    $("lessonStatus").innerHTML=`
      <div class="hsk2-source-meta">
        <span class="badge complete">New HSK Course 2</span>
        <span class="muted">Trang bắt đầu: ${currentLesson.page}</span>
        ${currentLesson.partial?'<span class="badge partial">Nội dung PDF kết thúc trong bài này</span>':""}
      </div>`;
    configureHsk2Modules();
    $("lessonBreadcrumb").textContent=`HSK ${selectedHSKSystem} / HSK 2 / Bài ${currentLesson.n}`;
    showModule("grammar");
  }else{
    $("lessonStatus").innerHTML=`
      ${statusText(currentLesson)}
      <div class="lesson-progress-box">
        <span>Tiến độ bài này: <b id="lessonProgressText">${lessonPercent(currentLesson)}%</b></span>
        <div class="progress-track"><div id="lessonProgressBar" class="progress-bar" style="width:${lessonPercent(currentLesson)}%"></div></div>
      </div>`;
    configureHsk3Modules();
    $("lessonBreadcrumb").textContent=`HSK ${selectedHSKSystem} / HSK ${selectedHSKLevel} / Bài ${currentLesson.n}`;
    showModule("vocab");
    updateModuleCompletionBadges();
  }
  window.scrollTo({top:0,behavior:"smooth"});
};
$("backBtn").onclick=()=>{
  $("lesson").classList.remove("active");
  $("home").classList.add("active");
  renderHomeReview();
  selectHSKSystem(selectedHSKSystem,false);
  selectHSKLevel(selectedHSKLevel,false);
  updateProgressUI();
  window.scrollTo({top:0,behavior:"smooth"});
};
document.querySelectorAll("[data-module]").forEach(b=>b.onclick=()=>showModule(b.dataset.module));

function unavailable(){
  $("moduleContent").innerHTML=`<div class="empty-state"><b>Phần này hiện chưa có dữ liệu.</b></div>`;
}
function completionButton(mod){
  const done=isCompleted(currentLesson.n,mod);
  return `<button class="${done?"done-btn":"secondary"}" onclick="toggleComplete('${mod}')">${done?"✓ Đã hoàn thành":"✓ Đánh dấu đã học"}</button>`;
}
window.toggleComplete=mod=>{
  const next=!isCompleted(currentLesson.n,mod);
  setCompleted(currentLesson.n,mod,next);
  if(/^text/.test(mod)) renderText(Number(mod.slice(-1)));
  else if(mod==="vocab") renderVocab();
  else if(mod==="grammar")renderGrammar();
};


function setModuleVisible(mod,visible){
  const btn=document.querySelector(`[data-module="${mod}"]`);
  if(btn) btn.style.display=visible?"":"none";
}
function configureHsk1Modules(){
  document.querySelectorAll(".learning-step").forEach(s=>s.style.display="");
  setModuleVisible("grammar",false);
  setModuleVisible("vocab",true);
  setModuleVisible("text1",true);
  setModuleVisible("text2",true);
  setModuleVisible("text3",true);
  setModuleVisible("text4",false);
  setModuleVisible("review",true);
  setModuleVisible("translate",false);
  setModuleVisible("fill",true);
  setModuleVisible("quiz",true);
}
function configureHsk2Modules(){
  document.querySelectorAll(".learning-step").forEach(s=>s.style.display="");
  setModuleVisible("grammar",true);
  setModuleVisible("vocab",(currentLesson.words||[]).length>0);
  for(let i=1;i<=4;i++) setModuleVisible(`text${i}`,(currentLesson.texts||[]).length>=i);
  setModuleVisible("review",(currentLesson.words||[]).length>0);
  setModuleVisible("translate",false);
  setModuleVisible("fill",(currentLesson.texts||[]).some(t=>(t.targets||[]).length>0));
  setModuleVisible("quiz",(currentLesson.words||[]).length>=4);
}
function configureHsk3Modules(){
  ["grammar","vocab","text1","text2","text3","text4","review","translate","fill","quiz"].forEach(m=>setModuleVisible(m,true));
  setModuleVisible("grammar",selectedHSKLevel===4 && !!currentLesson.grammar?.length);
}
function renderGrammar(){
  const grammar=currentLesson.grammar||[];
  $("moduleContent").innerHTML=`
    <div class="text-head">
      <div>
        <h3>Ngữ pháp trọng tâm</h3>
        <div class="muted">Bài ${currentLesson.n} • HSK ${selectedHSKLevel}</div>
      </div>
    </div>
    <div class="grammar-list">
      ${grammar.map((g,i)=>`
        <div class="grammar-item">
          <div class="grammar-num">${i+1}</div>
          <div><b>${escapeHtml(g)}</b></div>
        </div>`).join("")}
    </div>
    ${selectedHSKLevel===4?completionButton("grammar"):""}`;
}
function showModule(mod){
  if(!currentLesson)return;
  if(mod==="grammar")return renderGrammar();
  if(currentLesson.sourceUnavailable && mod!=="vocab") return unavailable();
  if(mod==="vocab")return renderVocab();
  if(/^text[1-4]$/.test(mod))return renderText(Number(mod.slice(-1)));
  if(mod==="review")return setupReview();
  if(mod==="translate")return renderTranslation();
  if(mod==="fill")return renderFill();
  if(mod==="quiz")return renderQuiz();
}

/* ---------- vocabulary examples ---------- */
function coreWord(hanzi){
  return String(hanzi||"").replace(/[（(].*?[）)]/g,"").trim();
}
function findExampleForWord(w){
  const key=coreWord(w.hanzi);
  const lines=[];
  (currentLesson.texts||[]).forEach(t=>{
    String(t.content||"").split(/\n+/).forEach(line=>lines.push(line.trim()));
  });
  (currentLesson.translations||[]).forEach(x=>lines.push(String(x.zh||"").trim()));
  if(selectedHSKLevel===4){const pieces=lines.flatMap(line=>line.match(/[^。！？；\n]+[。！？；]?/g)||[]).map(x=>x.trim()); return pieces.find(line=>key&&line.includes(key))||"";}
  const hit=lines.find(line=>key && line.includes(key));
  if(hit)return hit;
  if(key==="草地")return "孩子们在草地上玩儿。";
  return `我正在学习“${key}”这个词。`;
}
function renderVocab(){
  const words=currentLesson.words||[];
  if(!words.length)return unavailable();
  $("moduleContent").innerHTML=`
    <div class="text-head">
      <div><h3>Từ vựng</h3><div class="muted">${words.length} mục từ • Hán tự + pinyin + nghĩa tiếng Việt + ví dụ + phát âm</div></div>
      ${(isHSK1()||isHSK2())?"":completionButton("vocab")}
    </div>
    <div class="word-list">
      ${words.map((w,i)=>{
        const ex=findExampleForWord(w);
        return `<div class="word-row vocab-rich">
          <div class="muted">${i+1}</div>
          <div class="hanzi">${escapeHtml(w.hanzi)}</div>
          <div class="pinyin">${escapeHtml(w.pinyin)}</div>
          <div class="vi">${escapeHtml(w.vi)}</div>
          <div class="audio-pair">
            <button class="speak mini" onclick='speak(${JSON.stringify(w.hanzi)},"slow")'>🔊 Chậm</button>
            <button class="speak mini" onclick='speak(${JSON.stringify(w.hanzi)},"normal")'>▶ Chuẩn</button>
          </div>
          ${ex?`<div class="word-example"><b>例：</b>${escapeHtml(ex)}</div>`:""}
        </div>`;
      }).join("")}
    </div>`;
}

/* ---------- text + pinyin toggle ---------- */
function pinyinForText(text){
  if(!window.pinyinPro?.pinyin)return "";
  try{
    return String(text).split(/\n/).map(line=>{
      const py=window.pinyinPro.pinyin(line,{toneType:"symbol"});
      return `<div class="pinyin-line">${escapeHtml(py)}</div>`;
    }).join("");
  }catch{return ""}
}
function renderText(id){
  const t=(currentLesson.texts||[]).find(x=>x.id===id);
  if(!t){
    $("moduleContent").innerHTML=`<div class="empty-state"><b>Bài khóa ${id} hiện chưa có nội dung.</b></div>`;
    return;
  }
  const py=pinyinForText(t.content);
  $("moduleContent").innerHTML=`
    <div class="text-head">
      <div><h3>${escapeHtml(t.title)}</h3><div class="muted">Đọc trước không pinyin, chỉ bật khi cần kiểm tra.</div></div>
      <div class="text-actions">
        <button class="secondary" onclick="togglePinyin()">拼音 Hiện / Ẩn</button>
        <button class="speak" onclick='speak(${JSON.stringify(t.content.replace(/\n/g," "))},"slow")'>🔊 Chậm</button>
        <button class="speak" onclick='speak(${JSON.stringify(t.content.replace(/\n/g," "))},"normal")'>▶ Bình thường</button>
        ${(isHSK1()||isHSK2())?"":completionButton(`text${id}`)}
      </div>
    </div>
    <div id="pinyinBlock" class="pinyin-block hidden">
      ${py||'<div class="muted">Không tải được công cụ pinyin. Hãy kiểm tra kết nối mạng rồi thử lại.</div>'}
    </div>
    <div class="textbook-text">${escapeHtml(t.content)}</div>`;
}
window.togglePinyin=()=>{
  const block=$("pinyinBlock");
  if(block)block.classList.toggle("hidden");
};

/* ---------- flashcard self-check ---------- */
function reviewStorage(){
  const all=loadStore(REVIEW_KEY);
  const k=lessonProgressKey(currentLesson.n);
  all[k]=all[k]||{remembered:[],notRemembered:[]};
  return {all,k,item:all[k]};
}
function loadReviewState(){
  const {item}=reviewStorage();
  rememberedSet=new Set(item.remembered||[]);
  notRememberedSet=new Set(item.notRemembered||[]);
}
function saveReviewState(){
  const {all,k}=reviewStorage();
  all[k]={remembered:[...rememberedSet],notRemembered:[...notRememberedSet]};
  saveStore(REVIEW_KEY,all);
}
function makeReviewCards(){
  return (currentLesson.words||[]).filter(w=>w.hanzi).map(w=>({
    hanzi:w.hanzi,pinyin:w.pinyin||"",vi:w.vi||"",id:selectedHSKLevel===4?`${w.hanzi}|${w.pinyin}|${w.vi}`:w.hanzi
  }));
}
function setupReview(){
  reviewCards=makeReviewCards();
  reviewIndex=0;
  loadReviewState();
  if(!reviewCards.length){
    $("moduleContent").innerHTML='<div class="empty-state">Chưa có từ vựng để tạo flashcard.</div>';
    return;
  }
  renderReviewCard(false);
}
function reviewCounts(){
  return {remembered:rememberedSet.size,notRemembered:notRememberedSet.size,total:reviewCards.length};
}
function renderReviewCard(showBack=false){
  const x=reviewCards[reviewIndex], c=reviewCounts();
  $("moduleContent").innerHTML=`
    <div class="exercise-wrap">
      <div class="progress">Flashcard ${reviewIndex+1}/${reviewCards.length}</div>
      <h3>Ôn tập từ vựng</h3>
      <p class="exercise-sub">Lật thẻ để kiểm tra. Sau đó chọn <b>Nhớ rồi</b> hoặc <b>Chưa nhớ</b>. Những từ chưa nhớ có thể được lọc để ôn lại.</p>

      <div class="memory-summary">
        <span class="memory-good">✓ Nhớ rồi: ${c.remembered}</span>
        <span class="memory-bad">↻ Chưa nhớ: ${c.notRemembered}</span>
        <span>Còn lại: ${Math.max(c.total-c.remembered-c.notRemembered,0)}</span>
      </div>

      <div class="card-stage">
        <div id="flipCard" class="flip-card ${showBack?'is-flipped':''}" onclick="flipReview()">
          <div class="flip-card-inner">
            <div class="flip-face flip-front">
              <div class="flash-label">Mặt trước</div>
              <div class="flash-hanzi">${escapeHtml(x.hanzi)}</div>
              <div class="face-help">Nhìn chữ Hán và đoán cách đọc + nghĩa</div>
            </div>
            <div class="flip-face flip-back">
              <div class="flash-label">Mặt sau</div>
              <div class="flash-hanzi small">${escapeHtml(x.hanzi)}</div>
              <div class="flash-pinyin">${escapeHtml(x.pinyin)}</div>
              <div class="flash-meaning">${escapeHtml(x.vi)}</div>
              <div class="audio-pair center">
                <button class="speak" onclick='event.stopPropagation();speak(${JSON.stringify(x.hanzi)},"slow")'>🔊 Chậm</button>
                <button class="speak" onclick='event.stopPropagation();speak(${JSON.stringify(x.hanzi)},"normal")'>▶ Chuẩn</button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="memory-buttons">
        <button class="remember-btn" onclick="markRemembered()">✓ Nhớ rồi</button>
        <button class="forget-btn" onclick="markNotRemembered()">↻ Chưa nhớ</button>
      </div>

      <div class="controls">
        <button class="secondary" onclick="prevReview()">← Trước</button>
        <button class="secondary" onclick="flipReview()">Lật thẻ</button>
        <button class="secondary" onclick="nextReview()">Tiếp →</button>
        <button class="secondary" onclick="reviewOnlyForgotten()">Ôn từ chưa nhớ</button>
        <button class="secondary" onclick="shuffleReview()">🔀 Trộn thẻ</button>
      </div>
    </div>`;
}
window.flipReview=()=>{$("flipCard")?.classList.toggle("is-flipped")};
window.nextReview=()=>{reviewIndex=(reviewIndex+1)%reviewCards.length;renderReviewCard(false)};
window.prevReview=()=>{reviewIndex=(reviewIndex-1+reviewCards.length)%reviewCards.length;renderReviewCard(false)};
window.shuffleReview=()=>{
  for(let i=reviewCards.length-1;i>0;i--){
    const j=Math.floor(Math.random()*(i+1));
    [reviewCards[i],reviewCards[j]]=[reviewCards[j],reviewCards[i]];
  }
  reviewIndex=0;renderReviewCard(false);
};
window.markRemembered=()=>{
  const h=reviewCards[reviewIndex].id;
  rememberedSet.add(h);notRememberedSet.delete(h);saveReviewState();
  if(!isHSK1() && !isHSK2() && rememberedSet.size===makeReviewCards().length)setCompleted(currentLesson.n,"review",true);
  nextReview();
};
window.markNotRemembered=()=>{
  const h=reviewCards[reviewIndex].id;
  notRememberedSet.add(h);rememberedSet.delete(h);saveReviewState();
  if(!isHSK1() && !isHSK2()) setCompleted(currentLesson.n,"review",false);
  nextReview();
};
window.reviewOnlyForgotten=()=>{
  const all=makeReviewCards();
  const filtered=all.filter(x=>notRememberedSet.has(x.id));
  reviewCards=filtered.length?filtered:all;
  reviewIndex=0;renderReviewCard(false);
};

/* ---------- translation: phrase-group comparison ---------- */
function renderTranslation(){
  const set=currentLesson.translations||[];
  if(!set.length)return unavailable();
  const x=set[translationIndex];
  $("moduleContent").innerHTML=`
    <div class="exercise-wrap">
      <div class="progress">Câu ${translationIndex+1}/${set.length}</div>
      <h3>Dịch câu Việt → Trung</h3>
      <p class="exercise-sub">
        Sau khi dịch, bấm <b>So sánh với đáp án gợi ý</b>.
        <b>Màu đen = phần trùng với đáp án gợi ý</b>; <b class="red-note">màu đỏ = phần khác đáp án gợi ý</b>.
        <br><strong>Câu khác đáp án vẫn có thể đúng về ngữ pháp và ý nghĩa.</strong>
      </p>
      <div class="translate-prompt">${escapeHtml(x.vi)}</div>
      <textarea id="translationInput" class="textarea" placeholder="Nhập câu tiếng Trung của bạn..."></textarea>
      <div class="controls">
        <button class="primary" onclick="compareTranslation()">So sánh với đáp án gợi ý</button>
        <button class="secondary" onclick="showTranslation()">Xem đáp án gợi ý</button>
        <button class="secondary" onclick="nextTranslation()">Câu tiếp theo</button>
      </div>
      <div id="translationFeedback" class="feedback"></div>
      <div id="comparisonResult" class="comparison-result hidden"></div>
    </div>`;
}
function lcsDiff(student,reference){
  const a=[...student],b=[...reference],m=a.length,n=b.length;
  const dp=Array.from({length:m+1},()=>Array(n+1).fill(0));
  for(let i=m-1;i>=0;i--)for(let j=n-1;j>=0;j--)
    dp[i][j]=a[i]===b[j]?dp[i+1][j+1]+1:Math.max(dp[i+1][j],dp[i][j+1]);
  let i=0,j=0;const studentParts=[],refParts=[];
  while(i<m&&j<n){
    if(a[i]===b[j]){studentParts.push({char:a[i],match:true});refParts.push({char:b[j],match:true});i++;j++}
    else if(dp[i+1][j]>=dp[i][j+1])studentParts.push({char:a[i++],match:false});
    else refParts.push({char:b[j++],match:false});
  }
  while(i<m)studentParts.push({char:a[i++],match:false});
  while(j<n)refParts.push({char:b[j++],match:false});
  return {studentParts,refParts};
}
function groupDiff(parts){
  const groups=[];
  for(const p of parts){
    const last=groups[groups.length-1];
    if(last&&last.match===p.match)last.text+=p.char;
    else groups.push({match:p.match,text:p.char});
  }
  return groups;
}
function renderDiff(parts){
  return groupDiff(parts).map(g=>`<span class="${g.match?"diff-match":"diff-mismatch"}">${escapeHtml(g.text)}</span>`).join("");
}
window.compareTranslation=()=>{
  const x=currentLesson.translations[translationIndex];
  const user=$("translationInput").value.trim(),box=$("comparisonResult");
  if(!user){box.classList.remove("hidden");box.innerHTML='<div class="comparison-warning">Hãy nhập câu dịch trước.</div>';return}
  const diff=lcsDiff(user,x.zh);
  const total=Math.max([...x.zh].length,1);
  const matched=diff.refParts.filter(p=>p.match).length;
  const score=Math.round(matched/total*100);
  box.classList.remove("hidden");
  box.innerHTML=`
    <div class="comparison-card">
      <div class="comparison-title">Câu của bạn</div>
      <div class="comparison-line">${renderDiff(diff.studentParts)}</div>
    </div>
    <div class="comparison-card answer-card">
      <div class="comparison-title">Đáp án gợi ý</div>
      <div class="comparison-line">${renderDiff(diff.refParts)}</div>
    </div>
    <div class="comparison-legend">
      <span><i class="legend-dot black"></i> Trùng đáp án gợi ý</span>
      <span><i class="legend-dot red"></i> Khác đáp án gợi ý</span>
    </div>
    <div class="comparison-score">Mức độ trùng với đáp án gợi ý: <b>${score}%</b></div>
    <div class="translation-caution">⚠️ Đây là công cụ đối chiếu đáp án, không phải chấm ngữ pháp. Một cách dịch khác vẫn có thể đúng.</div>`;
  setCompleted(currentLesson.n,"translate",true);
};
window.showTranslation=()=>{
  const x=currentLesson.translations[translationIndex];
  $("translationFeedback").className="feedback";
  $("translationFeedback").innerHTML=`<b>Đáp án gợi ý:</b><br>${escapeHtml(x.zh)}`;
};
window.nextTranslation=()=>{
  translationIndex=(translationIndex+1)%currentLesson.translations.length;
  renderTranslation();
};

/* ---------- fill ---------- */
function blankPassage(text,targets){
  let r=text;targets.forEach((t,i)=>r=r.replace(t,`[[${i+1}]]`));
  return escapeHtml(r).replace(/\[\[(\d+)\]\]/g,'<span class="gap">[$1] ______</span>');
}
function renderFill(selectedId){
  const texts=currentLesson.texts||[];if(!texts.length)return unavailable();
  const id=Number(selectedId||texts[0].id),t=texts.find(x=>x.id===id)||texts[0],targets=t.targets.slice(0,10);
  const bank=[...targets].sort(()=>Math.random()-.5);
  $("moduleContent").innerHTML=`
  <div class="exercise-wrap">
    <div class="fill-toolbar"><b>Chọn bài khóa:</b><select onchange="renderFill(this.value)">${texts.map(x=>`<option value="${x.id}" ${x.id===t.id?"selected":""}>Bài khóa ${x.id}</option>`).join("")}</select></div>
    <h3>Điền từ vào Bài khóa ${t.id}</h3>
    <p class="exercise-sub">Điền ${targets.length} từ/cụm từ còn thiếu, sau đó kiểm tra.</p>
    <div class="answer-bank"><b>Ngân hàng từ:</b> ${bank.map(x=>`<span>${escapeHtml(x)}</span>`).join("")}</div>
    <div class="fill-passage">${blankPassage(t.content,targets)}</div>
    <div class="gap-inputs">${targets.map((_,i)=>`<label class="gap-row"><span class="gap-num">${i+1}</span><input id="gap${i}" placeholder="Từ số ${i+1}"></label>`).join("")}</div>
    <div class="controls"><button class="primary" onclick="checkFill(${t.id})">Kiểm tra ${targets.length} từ</button><button class="secondary" onclick="showFillAnswers(${t.id})">Xem đáp án</button></div>
    <div id="fillFeedback" class="feedback"></div>
  </div>`;
}
window.renderFill=renderFill;
window.checkFill=id=>{
  const t=currentLesson.texts.find(x=>x.id===Number(id)),targets=t.targets.slice(0,10);
  let correct=0;
  targets.forEach((a,i)=>{
    const inp=$(`gap${i}`),ok=normalize(inp.value)===normalize(a);
    if(ok)correct++;inp.style.borderColor=ok?"#22c55e":"#ef4444";
  });
  $("fillFeedback").className="feedback "+(correct===targets.length?"ok":"bad");
  $("fillFeedback").textContent=`Bạn đúng ${correct}/${targets.length} từ.`;
  if(!isHSK1() && !isHSK2() && targets.every((_,i)=>$( `gap${i}`).value.trim())) setCompleted(currentLesson.n,"fill",true);
};
window.showFillAnswers=id=>{
  const t=currentLesson.texts.find(x=>x.id===Number(id));
  $("fillFeedback").className="feedback";
  $("fillFeedback").innerHTML=`<b>Đáp án:</b> ${t.targets.slice(0,10).map((x,i)=>`${i+1}. ${escapeHtml(x)}`).join(" · ")}`;
};

/* ---------- mini quiz ---------- */
function sample(arr,n){const a=[...arr];for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a.slice(0,n)}
function uniqueChoices(correct,pool,n=4){
  const others=[...new Set(pool.filter(x=>x!==correct))];
  return sample(others,n-1).concat(correct).sort(()=>Math.random()-.5);
}
function makeQuiz(){
  const words=currentLesson.words||[], texts=currentLesson.texts||[], questions=[];
  const bank=words.filter(w=>!w.properNoun);
  const selected=sample(bank,Math.min(bank.length,8));
  const hsk4=selectedHSKLevel===4;
  selected.slice(0,hsk4?3:4).forEach(w=>questions.push({type:"meaning",prompt:`“${w.hanzi}” (${w.pinyin}) nghĩa là gì?`,answer:w.vi,choices:uniqueChoices(w.vi,bank.filter(x=>x.hanzi!==w.hanzi).map(x=>x.vi))}));
  selected.slice(hsk4?3:4,hsk4?5:8).forEach(w=>questions.push({type:"pinyin",prompt:`Pinyin của “${w.hanzi}” (${w.vi}) là:`,answer:w.pinyin,choices:uniqueChoices(w.pinyin,bank.filter(x=>x.hanzi!==w.hanzi).map(x=>x.pinyin))}));
  const targetPool=texts.flatMap(t=>(t.targets||[]).map(x=>({text:t.content,target:x}))).filter(x=>x.text.includes(x.target));
  sample(targetPool,Math.max(0,8-questions.length)).forEach(item=>{
    const sentence=item.text.split(/(?<=[。！？；])|\n/).find(line=>line.includes(item.target))||item.text;
    questions.push({type:"cloze",prompt:`Chọn từ còn thiếu trong bài khóa: ${sentence.replace(item.target,"______")}`,answer:item.target,choices:uniqueChoices(item.target,bank.map(x=>x.hanzi))});
  });
  return sample(questions,Math.min(8,questions.length));
}
function renderQuiz(){
  if(!(currentLesson.texts||[]).length)return unavailable();
  quizState={questions:makeQuiz()};
  $("moduleContent").innerHTML=`
    <div class="exercise-wrap">
      <h3>🏁 Mini quiz cuối bài</h3>
      <p class="exercise-sub">${quizState.questions.length} câu ôn tập: nghĩa từ vựng, pinyin và điền từ theo bài khóa (nếu có).</p>
      <div class="quiz-list">
        ${quizState.questions.map((q,i)=>`
          <div class="quiz-q" id="quizq${i}">
            <div class="quiz-number">Câu ${i+1}</div>
            <div class="quiz-prompt">${escapeHtml(q.prompt)}</div>
            <div class="quiz-choices">
              ${q.choices.map((c,j)=>`
                <label class="quiz-choice">
                  <input type="radio" name="q${i}" value="${escapeHtml(c)}">
                  <span>${escapeHtml(c)}</span>
                </label>`).join("")}
            </div>
          </div>`).join("")}
      </div>
      <div class="controls"><button class="primary" onclick="submitQuiz()">Nộp bài</button><button class="secondary" onclick="renderQuiz()">Làm bộ câu hỏi mới</button></div>
      <div id="quizResult"></div>
    </div>`;
}
window.renderQuiz=renderQuiz;
window.submitQuiz=()=>{
  let correct=0,answered=0;
  quizState.questions.forEach((q,i)=>{
    const chosen=document.querySelector(`input[name="q${i}"]:checked`);
    const card=$(`quizq${i}`);
    if(chosen){answered++;if(chosen.value===q.answer){correct++;card.classList.add("quiz-correct")}else card.classList.add("quiz-wrong")}
    if(!chosen||chosen.value!==q.answer){
      const note=document.createElement("div");
      note.className="quiz-answer";
      note.textContent=`Đáp án: ${q.answer}`;
      card.appendChild(note);
    }
  });
  const pct=Math.round(correct/quizState.questions.length*100);
  $("quizResult").innerHTML=`<div class="quiz-result-box"><b>${correct}/${quizState.questions.length} câu đúng (${pct}%)</b><br>${answered<quizState.questions.length?`Bạn còn ${quizState.questions.length-answered} câu chưa trả lời.`:"Đã hoàn thành mini quiz."}</div>`;
  if(!isHSK1() && !isHSK2()) setCompleted(currentLesson.n,"quiz",true);
};

/* ---------- speech: female Mandarin + 2 speeds ---------- */
let yuhuaChineseVoice=null,yuhuaVoicesLoaded=false,speechGeneration=0;
function chooseChineseFemaleVoice(){
  if(!("speechSynthesis" in window))return null;
  const voices=speechSynthesis.getVoices()||[];
  if(!voices.length)return null;
  const preferred=["Microsoft Xiaoxiao Online (Natural) - Chinese (Mainland)","Microsoft Xiaoxiao","Xiaoxiao","Ting-Ting","Tingting","Mei-Jia","Meijia","Sin-Ji","Google 普通话（中国大陆）","Google 普通话"];
  for(const wanted of preferred){
    const found=voices.find(v=>String(v.name||"").toLowerCase().includes(wanted.toLowerCase()));
    if(found)return found;
  }
  const zhCN=voices.filter(v=>/^zh[-_]CN$/i.test(v.lang||"")||String(v.lang||"").toLowerCase().startsWith("zh-cn"));
  const hinted=zhCN.find(v=>["xiaoxiao","ting","mei","female","woman","女","普通话"].some(h=>String(v.name||"").toLowerCase().includes(h)));
  return hinted||zhCN[0]||voices.find(v=>/^zh/i.test(v.lang||""))||null;
}
function refreshChineseVoice(){yuhuaChineseVoice=chooseChineseFemaleVoice();yuhuaVoicesLoaded=true}
if("speechSynthesis" in window){refreshChineseVoice();speechSynthesis.onvoiceschanged=refreshChineseVoice}
function speak(text,speed="slow"){
  if(!("speechSynthesis" in window)){alert("Trình duyệt này chưa hỗ trợ phát âm.");return}
  const raw=String(text||"").trim();if(!raw)return;
  const generation=++speechGeneration;
  speechSynthesis.cancel();
  if(!yuhuaVoicesLoaded||!yuhuaChineseVoice)refreshChineseVoice();
  const chunks=raw.replace(/\s+/g," ").match(/[^。！？!?；;，,]+[。！？!?；;，,]?/g)||[raw];
  let index=0;
  const speakNext=()=>{
    if(generation!==speechGeneration||index>=chunks.length)return;
    const part=chunks[index++].trim();if(!part){speakNext();return}
    const u=new SpeechSynthesisUtterance(part);
    u.lang="zh-CN";if(yuhuaChineseVoice)u.voice=yuhuaChineseVoice;
    u.rate=speed==="normal"?0.95:0.72;
    u.pitch=1.03;u.volume=1;
    u.onend=()=>setTimeout(speakNext,speed==="normal"?80:140);
    u.onerror=()=>setTimeout(speakNext,100);
    speechSynthesis.speak(u);
  };
  speakNext();
}
window.speak=speak;


/* ---------- Level-wide review HSK1/2/3 ---------- */
let levelReviewState=null;

function levelName(level){ return `HSK ${level}`; }

function allLevelWords(level){
  if(selectedHSKSystem!=="3.0") return [];
  const data = ({1:HSK1_DATA,2:HSK2_DATA,3:HSK3_DATA,4:HSK4_DATA})[level]||[];
  const seen = new Set();
  const result = [];
  data.forEach(lesson=>{
    (lesson.words||[]).forEach(w=>{
      const key = `${w.hanzi}|${w.pinyin}${level===4?"|"+w.vi:""}`;
      if(!seen.has(key)){
        seen.add(key);
        result.push({...w, lesson:lesson.n});
      }
    });
  });
  return result;
}

function buildLevelQuiz(level, words){
  const qs=[];
  const selected=sample(words,Math.min(12,words.length));

  selected.slice(0,6).forEach(w=>qs.push({
    type:"meaning",
    prompt:`“${w.hanzi}” nghĩa là gì?`,
    answer:w.vi,
    choices:uniqueChoices(w.vi,words.map(x=>x.vi))
  }));

  selected.slice(6,10).forEach(w=>qs.push({
    type:"pinyin",
    prompt:`Pinyin đúng của “${w.hanzi}” là:`,
    answer:w.pinyin,
    choices:uniqueChoices(w.pinyin,words.map(x=>x.pinyin))
  }));

  selected.slice(10,12).forEach(w=>qs.push({
    type:"hanzi",
    prompt:`Từ nào tương ứng với nghĩa “${w.vi}”?`,
    answer:w.hanzi,
    choices:uniqueChoices(w.hanzi,words.map(x=>x.hanzi))
  }));

  return sample(qs,Math.min(12,qs.length));
}

window.renderLevelReview=level=>{
  selectedHSKLevel=level;
  const words=allLevelWords(level);
  levelReviewState={level,words,quiz:buildLevelQuiz(level,words)};

  const panel=$("homePanel");
  panel.classList.remove("hidden");
  panel.innerHTML=`
    <div class="home-panel-card">
      <div class="panel-title-row">
        <div>
          <div class="kicker">Tổng kết HSK ${selectedHSKSystem} • ${levelName(level)}</div>
          <h2>Ôn tập ${levelName(level)} • HSK ${selectedHSKSystem}</h2>
          <p class="muted">Tổng hợp ${words.length} mục từ từ tất cả các bài thuộc HSK ${selectedHSKSystem} và một bài tập chung.</p>
        </div>
        <button class="ghost" onclick="renderHomeReview()">← Quay lại chọn HSK</button>
      </div>

      <div class="level-review-tabs">
        <button class="secondary active-review-tab" onclick="showLevelReviewTab('vocab')">Tất cả từ vựng</button>
        <button class="secondary" onclick="showLevelReviewTab('quiz')">Bài tập chung</button>
      </div>

      <div id="levelReviewContent"></div>
    </div>`;

  showLevelReviewTab("vocab");
  setTimeout(()=>panel.scrollIntoView({behavior:"smooth",block:"start"}),50);
};

window.showLevelReviewTab=tab=>{
  if(!levelReviewState)return;
  const box=$("levelReviewContent");
  document.querySelectorAll(".level-review-tabs button").forEach((b,i)=>{
    b.classList.toggle("active-review-tab",(tab==="vocab"&&i===0)||(tab==="quiz"&&i===1));
  });

  if(tab==="vocab"){
    const grouped={};
    levelReviewState.words.forEach(w=>{
      grouped[w.lesson]=grouped[w.lesson]||[];
      grouped[w.lesson].push(w);
    });

    box.innerHTML=`
      <div class="review-summary-bar">
        <b>${levelReviewState.words.length} mục từ</b>
        <span>${Object.keys(grouped).length} bài</span>
      </div>
      <div class="level-vocab-groups">
        ${Object.keys(grouped).map(lesson=>`
          <section class="level-vocab-group">
            <h3>Bài ${lesson}</h3>
            <div class="word-list">
              ${grouped[lesson].map((w,i)=>`
                <div class="word-row vocab-rich">
                  <div class="muted">${i+1}</div>
                  <div class="hanzi">${escapeHtml(w.hanzi)}</div>
                  <div class="pinyin">${escapeHtml(w.pinyin)}</div>
                  <div class="vi">${escapeHtml(w.vi)}</div>
                  <div class="audio-pair">
                    <button class="speak mini" onclick='speak(${JSON.stringify(w.hanzi)},"slow")'>🔊 Chậm</button>
                    <button class="speak mini" onclick='speak(${JSON.stringify(w.hanzi)},"normal")'>▶ Chuẩn</button>
                  </div>
                </div>`).join("")}
            </div>
          </section>`).join("")}
      </div>`;
    return;
  }

  const q=levelReviewState.quiz;
  box.innerHTML=`
    <div class="exercise-wrap">
      <h3>Bài tập chung ${levelName(levelReviewState.level)}</h3>
      <p class="exercise-sub">${q.length} câu tổng hợp toàn bộ từ vựng của trình độ này.</p>
      <div class="quiz-list">
        ${q.map((item,i)=>`
          <div class="quiz-q" id="levelq${i}">
            <div class="quiz-number">Câu ${i+1}</div>
            <div class="quiz-prompt">${escapeHtml(item.prompt)}</div>
            <div class="quiz-choices">
              ${item.choices.map(c=>`
                <label class="quiz-choice">
                  <input type="radio" name="levelq${i}" value="${escapeHtml(c)}">
                  <span>${escapeHtml(c)}</span>
                </label>`).join("")}
            </div>
          </div>`).join("")}
      </div>
      <div class="controls">
        <button class="primary" onclick="submitLevelReviewQuiz()">Nộp bài</button>
        <button class="secondary" onclick="newLevelReviewQuiz()">Tạo bộ câu hỏi mới</button>
      </div>
      <div id="levelReviewResult"></div>
    </div>`;
};

window.submitLevelReviewQuiz=()=>{
  if(!levelReviewState)return;
  let correct=0,answered=0;
  levelReviewState.quiz.forEach((q,i)=>{
    const chosen=document.querySelector(`input[name="levelq${i}"]:checked`);
    const card=$(`levelq${i}`);
    card.classList.remove("quiz-correct","quiz-wrong");
    card.querySelectorAll(".quiz-answer").forEach(x=>x.remove());

    if(chosen){
      answered++;
      if(chosen.value===q.answer){
        correct++;
        card.classList.add("quiz-correct");
      }else{
        card.classList.add("quiz-wrong");
      }
    }

    if(!chosen||chosen.value!==q.answer){
      const note=document.createElement("div");
      note.className="quiz-answer";
      note.textContent=`Đáp án: ${q.answer}`;
      card.appendChild(note);
    }
  });

  const total=levelReviewState.quiz.length;
  const pct=total?Math.round(correct/total*100):0;
  $("levelReviewResult").innerHTML=`
    <div class="quiz-result-box">
      <b>${correct}/${total} câu đúng (${pct}%)</b><br>
      ${answered<total?`Bạn còn ${total-answered} câu chưa trả lời.`:"Đã hoàn thành bài ôn tập."}
    </div>`;
};

window.newLevelReviewQuiz=()=>{
  if(!levelReviewState)return;
  levelReviewState.quiz=buildLevelQuiz(levelReviewState.level,levelReviewState.words);
  showLevelReviewTab("quiz");
};


/* ---------- Final course test ---------- */
let finalTestState=null;

function allLevelTexts(level){
  const data=currentLevelData();
  const rows=[];
  data.forEach(lesson=>{
    (lesson.texts||[]).forEach(t=>{
      rows.push({...t, lesson:lesson.n});
    });
  });
  return rows;
}

function buildFinalCourseTest(level){
  const words=allLevelWords(level);
  const texts=allLevelTexts(level);
  const questions=[];

  // 10 meaning questions
  sample(words,Math.min(10,words.length)).forEach(w=>{
    questions.push({
      type:"meaning",
      prompt:`“${w.hanzi}” nghĩa là gì?`,
      answer:w.vi,
      choices:uniqueChoices(w.vi,words.map(x=>x.vi))
    });
  });

  // 5 pinyin questions
  sample(words,Math.min(5,words.length)).forEach(w=>{
    questions.push({
      type:"pinyin",
      prompt:`Pinyin đúng của “${w.hanzi}” là:`,
      answer:w.pinyin,
      choices:uniqueChoices(w.pinyin,words.map(x=>x.pinyin))
    });
  });

  // 5 hanzi recognition questions
  sample(words,Math.min(5,words.length)).forEach(w=>{
    questions.push({
      type:"hanzi",
      prompt:`Chọn chữ Hán đúng với nghĩa “${w.vi}”:`,
      answer:w.hanzi,
      choices:uniqueChoices(w.hanzi,words.map(x=>x.hanzi))
    });
  });

  // Up to 5 text cloze questions from actual textbook texts.
  const clozePool=[];
  texts.forEach(t=>{
    (t.targets||[]).forEach(target=>{
      const sentence=String(t.content||"").split(/(?<=[。！？；])|\n/).find(line=>line.includes(target));
      if(sentence){
        clozePool.push({sentence,target});
      }
    });
  });

  sample(clozePool,Math.min(5,clozePool.length)).forEach(item=>{
    const blank=item.sentence.replace(item.target,"______");
    questions.push({
      type:"cloze",
      prompt:`Điền từ phù hợp: ${blank}`,
      answer:item.target,
      choices:uniqueChoices(item.target,words.map(x=>x.hanzi))
    });
  });

  return sample(questions,Math.min(25,questions.length));
}

window.renderFinalCourseTest=level=>{
  const data=currentLevelData();
  if(!data.length){
    const panel=$("homePanel");
    panel.classList.remove("hidden");
    panel.innerHTML=`
      <div class="home-panel-card">
        <div class="panel-title-row">
          <div>
            <div class="kicker">Test cuối khóa</div>
            <h2>HSK ${selectedHSKSystem} • HSK ${level}</h2>
          </div>
          <button class="ghost" onclick="renderHomeReview()">← Quay lại</button>
        </div>
        <div class="empty-state">
          Chưa có dữ liệu bài học để tạo test cuối khóa cho cấp độ này.
        </div>
      </div>`;
    return;
  }

  const questions=buildFinalCourseTest(level);
  finalTestState={
    level,
    system:selectedHSKSystem,
    questions,
    startedAt:Date.now()
  };

  const panel=$("homePanel");
  panel.classList.remove("hidden");
  panel.innerHTML=`
    <div class="home-panel-card final-test-page">
      <div class="panel-title-row">
        <div>
          <div class="kicker">Kiểm tra cuối khóa • HSK ${selectedHSKSystem}</div>
          <h2>Final Test HSK ${level}</h2>
          <p class="muted">${questions.length} câu • Từ vựng + Pinyin + Nhận diện chữ Hán + Bài khóa</p>
        </div>
        <button class="ghost" onclick="renderHomeReview()">← Thoát bài test</button>
      </div>

      <div class="final-test-info">
        <div><b>${questions.length}</b><span>Câu hỏi</span></div>
        <div><b>80%</b><span>Mốc đạt gợi ý</span></div>
        <div><b id="finalTestTimer">00:00</b><span>Thời gian</span></div>
      </div>

      <div class="final-test-note">
        Làm toàn bộ câu hỏi rồi bấm <b>Nộp bài</b>. Câu sai sẽ hiển thị đáp án đúng sau khi nộp.
      </div>

      <div class="quiz-list final-test-list">
        ${questions.map((q,i)=>`
          <div class="quiz-q" id="finalq${i}">
            <div class="quiz-number">Câu ${i+1}</div>
            <div class="quiz-prompt">${escapeHtml(q.prompt)}</div>
            <div class="quiz-choices">
              ${q.choices.map(c=>`
                <label class="quiz-choice">
                  <input type="radio" name="finalq${i}" value="${escapeHtml(c)}">
                  <span>${escapeHtml(c)}</span>
                </label>`).join("")}
            </div>
          </div>`).join("")}
      </div>

      <div class="final-test-submit-bar">
        <button class="primary final-submit-btn" onclick="submitFinalCourseTest()">Nộp bài test</button>
        <button class="secondary" onclick="restartFinalCourseTest()">Tạo đề mới</button>
      </div>

      <div id="finalTestResult"></div>
    </div>`;

  startFinalTestTimer();
  setTimeout(()=>panel.scrollIntoView({behavior:"smooth",block:"start"}),50);
};

let finalTestTimerHandle=null;

function startFinalTestTimer(){
  if(finalTestTimerHandle) clearInterval(finalTestTimerHandle);
  finalTestTimerHandle=setInterval(()=>{
    if(!finalTestState || !$("finalTestTimer")){
      clearInterval(finalTestTimerHandle);
      return;
    }
    const sec=Math.floor((Date.now()-finalTestState.startedAt)/1000);
    const mm=String(Math.floor(sec/60)).padStart(2,"0");
    const ss=String(sec%60).padStart(2,"0");
    $("finalTestTimer").textContent=`${mm}:${ss}`;
  },1000);
}

window.submitFinalCourseTest=()=>{
  if(!finalTestState || finalTestState.submitted)return;
  finalTestState.submitted=true;

  let correct=0;
  let answered=0;

  finalTestState.questions.forEach((q,i)=>{
    const chosen=document.querySelector(`input[name="finalq${i}"]:checked`);
    const card=$(`finalq${i}`);

    card.classList.remove("quiz-correct","quiz-wrong");
    card.querySelectorAll(".quiz-answer").forEach(x=>x.remove());

    if(chosen){
      answered++;
      if(chosen.value===q.answer){
        correct++;
        card.classList.add("quiz-correct");
      }else{
        card.classList.add("quiz-wrong");
      }
    }

    if(!chosen || chosen.value!==q.answer){
      const note=document.createElement("div");
      note.className="quiz-answer";
      note.textContent=`Đáp án đúng: ${q.answer}`;
      card.appendChild(note);
    }
  });

  const total=finalTestState.questions.length;
  const pct=total?Math.round(correct/total*100):0;
  const elapsed=Math.floor((Date.now()-finalTestState.startedAt)/1000);
  const mm=Math.floor(elapsed/60);
  const ss=elapsed%60;
  const passed=pct>=80;

  if(finalTestTimerHandle){
    clearInterval(finalTestTimerHandle);
    finalTestTimerHandle=null;
  }

  $("finalTestResult").innerHTML=`
    <div class="final-result ${passed?"pass":"fail"}">
      <div class="final-result-score">${pct}%</div>
      <div>
        <h3>${passed?"✓ Hoàn thành tốt":"Cần ôn tập thêm"}</h3>
        <p>Bạn trả lời đúng <b>${correct}/${total}</b> câu.</p>
        <p>Đã trả lời: ${answered}/${total} • Thời gian: ${mm} phút ${ss} giây.</p>
      </div>
    </div>`;

  document.querySelectorAll('.final-test-list input').forEach(x=>x.disabled=true);
  document.querySelector('.final-submit-btn').disabled=true;
  $("finalTestResult").scrollIntoView({behavior:"smooth",block:"center"});
};

window.restartFinalCourseTest=()=>{
  if(!finalTestState)return;
  renderFinalCourseTest(finalTestState.level);
};

/* ---------- search ---------- */
$("globalSearch").oninput=e=>{
  const q=e.target.value.trim().toLowerCase();
  if(!q){$("searchResults").classList.add("hidden");return}
  const hits=[];
  [HSK1_DATA,HSK2_DATA,HSK3_DATA,HSK4_DATA].forEach((level,i)=>level.forEach(l=>(l.words||[]).forEach(w=>{
    if(`${w.hanzi} ${w.pinyin} ${w.vi}`.toLowerCase().includes(q))hits.push({l,w,level:i+1})
  })));
  $("searchResults").classList.remove("hidden");
  $("searchResults").innerHTML=hits.length?hits.slice(0,80).map(x=>`<div class="search-hit"><b>HSK ${x.level} • Bài ${x.l.n}</b><span class="hanzi">${escapeHtml(x.w.hanzi)}</span><span class="pinyin">${escapeHtml(x.w.pinyin)}</span><span>${escapeHtml(x.w.vi)}</span></div>`).join(""):'<div class="muted">Không tìm thấy.</div>';
};
$("clearSearch").onclick=()=>{$("globalSearch").value="";$("searchResults").classList.add("hidden")};


updateProgressUI();
