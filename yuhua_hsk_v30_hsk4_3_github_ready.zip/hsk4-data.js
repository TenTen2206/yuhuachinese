/* Source: 新HSK教程4上、下; Vietnamese glosses and translation prompts prepared for this website. */
const HSK4_DATA = [
  {
    "n": 1,
    "title": "我们来中国学习了",
    "volume": "上",
    "page": 1,
    "grammar": [
      "任何",
      "要是……，就……",
      "随着",
      "一方面……，另一方面……"
    ],
    "words": [
      {
        "hanzi": "签证",
        "pinyin": "qiānzhèng",
        "vi": "thị thực; visa"
      },
      {
        "hanzi": "入学",
        "pinyin": "rùxué",
        "vi": "nhập học"
      },
      {
        "hanzi": "通知",
        "pinyin": "tōngzhī",
        "vi": "thông báo"
      },
      {
        "hanzi": "证件",
        "pinyin": "zhèngjiàn",
        "vi": "giấy tờ tùy thân; giấy tờ chứng nhận"
      },
      {
        "hanzi": "材料",
        "pinyin": "cáiliào",
        "vi": "tài liệu; hồ sơ"
      },
      {
        "hanzi": "证",
        "pinyin": "zhèng",
        "vi": "giấy chứng nhận"
      },
      {
        "hanzi": "任何",
        "pinyin": "rènhé",
        "vi": "bất kỳ"
      },
      {
        "hanzi": "食堂",
        "pinyin": "shítáng",
        "vi": "nhà ăn"
      },
      {
        "hanzi": "座",
        "pinyin": "zuò",
        "vi": "lượng từ cho công trình, núi"
      },
      {
        "hanzi": "申请",
        "pinyin": "shēnqǐng",
        "vi": "xin; đăng ký"
      },
      {
        "hanzi": "奖学金",
        "pinyin": "jiǎngxuéjīn",
        "vi": "học bổng"
      },
      {
        "hanzi": "表现",
        "pinyin": "biǎoxiàn",
        "vi": "biểu hiện; thể hiện"
      },
      {
        "hanzi": "获得",
        "pinyin": "huòdé",
        "vi": "đạt được; nhận được"
      },
      {
        "hanzi": "要是",
        "pinyin": "yàoshi",
        "vi": "nếu"
      },
      {
        "hanzi": "减轻",
        "pinyin": "jiǎnqīng",
        "vi": "giảm nhẹ"
      },
      {
        "hanzi": "经济",
        "pinyin": "jīngjì",
        "vi": "kinh tế"
      },
      {
        "hanzi": "压力",
        "pinyin": "yālì",
        "vi": "áp lực"
      },
      {
        "hanzi": "加油",
        "pinyin": "jiāyóu",
        "vi": "cố lên"
      },
      {
        "hanzi": "随着",
        "pinyin": "suízhe",
        "vi": "cùng với; theo"
      },
      {
        "hanzi": "课程",
        "pinyin": "kèchéng",
        "vi": "môn học; khóa học"
      },
      {
        "hanzi": "专业",
        "pinyin": "zhuānyè",
        "vi": "chuyên ngành; chuyên nghiệp"
      },
      {
        "hanzi": "本科",
        "pinyin": "běnkē",
        "vi": "bậc đại học"
      },
      {
        "hanzi": "硕士",
        "pinyin": "shuòshì",
        "vi": "thạc sĩ"
      },
      {
        "hanzi": "研究生",
        "pinyin": "yánjiūshēng",
        "vi": "nghiên cứu sinh; học viên sau đại học"
      },
      {
        "hanzi": "博士",
        "pinyin": "bóshì",
        "vi": "tiến sĩ"
      },
      {
        "hanzi": "研究",
        "pinyin": "yánjiū",
        "vi": "nghiên cứu"
      },
      {
        "hanzi": "活动",
        "pinyin": "huódòng",
        "vi": "hoạt động"
      },
      {
        "hanzi": "通过",
        "pinyin": "tōngguò",
        "vi": "thông qua"
      },
      {
        "hanzi": "交流",
        "pinyin": "jiāoliú",
        "vi": "giao lưu; trao đổi"
      },
      {
        "hanzi": "适应",
        "pinyin": "shìyìng",
        "vi": "thích ứng"
      },
      {
        "hanzi": "将来",
        "pinyin": "jiānglái",
        "vi": "tương lai"
      },
      {
        "hanzi": "国际",
        "pinyin": "guójì",
        "vi": "quốc tế"
      },
      {
        "hanzi": "当",
        "pinyin": "dāng",
        "vi": "làm; đảm nhiệm"
      },
      {
        "hanzi": "教育",
        "pinyin": "jiàoyù",
        "vi": "giáo dục"
      },
      {
        "hanzi": "成为",
        "pinyin": "chéngwéi",
        "vi": "trở thành"
      },
      {
        "hanzi": "教师",
        "pinyin": "jiàoshī",
        "vi": "giáo viên"
      },
      {
        "hanzi": "贸易",
        "pinyin": "màoyì",
        "vi": "thương mại"
      },
      {
        "hanzi": "方面",
        "pinyin": "fāngmiàn",
        "vi": "phương diện"
      },
      {
        "hanzi": "知识",
        "pinyin": "zhīshi",
        "vi": "kiến thức"
      },
      {
        "hanzi": "另",
        "pinyin": "lìng",
        "vi": "khác"
      }
    ],
    "texts": [
      {
        "id": 1,
        "title": "课文 1",
        "content": "老师：你们好，欢迎到中国留学！请把护照、签证和入学通知书给我。\n白家月：好的。这是我们的证件和材料。\n（几分钟后。）\n老师：办好了，这是你们的学生证，下周一开始上课。先试听两周，然后在网上选课。\n白家月、陈天中：谢谢老师。\n老师：不客气，你们以后有任何问题都可以来找我。",
        "sourcePages": [
          12
        ],
        "targets": [
          "签证",
          "入学",
          "通知",
          "证件",
          "材料",
          "任何"
        ]
      },
      {
        "id": 2,
        "title": "课文 2",
        "content": "陈天中：你看，咱们的校园真大！有图书馆、体育馆、超市，还有好几个食堂。\n白家月：是啊，我觉得学校就像一座小城市，什么都有，方便极了。\n陈天中：刚才老师说，咱们可以申请奖学金，你了解过吗？\n白家月：我听说过一点儿，好像成绩好、表现好的学生都有机会获得奖学金。\n陈天中：那太好了，要是申请到奖学金，就能减轻不少经济压力。\n白家月：没错，我们一起加油吧！",
        "sourcePages": [
          14
        ],
        "targets": [
          "食堂",
          "申请",
          "奖学金",
          "表现",
          "获得",
          "要是",
          "减轻",
          "经济",
          "压力",
          "加油"
        ]
      },
      {
        "id": 3,
        "title": "课文 3",
        "content": "随着中国的发展，越来越多的外国学生来到中国的大学学习。他们可以先上一年的中文课程，然后根据自己的兴趣和需要选择专业。除了读本科课程，他们还可以申请读硕士研究生或者博士研究生。\n在大学里，外国学生可以和中国学生一起学习、做研究、参加校园活动。通过这些交流，外国学生能更快地适应中国的大学生活。",
        "sourcePages": [
          16
        ],
        "targets": [
          "随着",
          "课程",
          "专业",
          "本科",
          "申请",
          "硕士",
          "研究生",
          "博士",
          "活动",
          "通过"
        ]
      },
      {
        "id": 4,
        "title": "课文 4",
        "content": "很多外国学生来中国学习以前，就已经想好了自己的发展方向。有人对经济感兴趣，希望将来在国际公司工作；有人喜欢医学，打算回国后当一名医生；还有人对教育有热情，想要成为一名教师。\n陈天中想选择跟经济有关的专业，希望通过学习，了解更多国际贸易方面的知识。安妮以后想做一名中文老师，所以要选择国际中文教育专业。对他们来说，来到中国留学，一方面是为了学习语言和知识，另一方面也是为将来的工作和生活做准备。",
        "sourcePages": [
          18
        ],
        "targets": [
          "经济",
          "将来",
          "国际",
          "教育",
          "成为",
          "教师",
          "专业",
          "通过",
          "贸易",
          "方面"
        ]
      }
    ],
    "translations": [
      {
        "vi": "Nếu xin được học bổng thì có thể giảm bớt không ít áp lực kinh tế.",
        "zh": "要是申请到奖学金，就能减轻不少经济压力。"
      },
      {
        "vi": "Thông qua những giao lưu này, sinh viên nước ngoài có thể thích ứng nhanh hơn với cuộc sống đại học tại Trung Quốc.",
        "zh": "通过这些交流，外国学生能更快地适应中国的大学生活。"
      },
      {
        "vi": "Trần Thiên Trung hy vọng thông qua học tập để hiểu thêm kiến thức về thương mại quốc tế.",
        "zh": "陈天中希望通过学习，了解更多国际贸易方面的知识。"
      }
    ]
  },
  {
    "n": 2,
    "title": "租到了合适的房子",
    "volume": "上",
    "page": 12,
    "grammar": [
      "×就是了",
      "……，不过……",
      "并",
      "由于"
    ],
    "words": [
      {
        "hanzi": "房东",
        "pinyin": "fángdōng",
        "vi": "chủ nhà"
      },
      {
        "hanzi": "出租",
        "pinyin": "chūzū",
        "vi": "cho thuê"
      },
      {
        "hanzi": "房租",
        "pinyin": "fángzū",
        "vi": "tiền thuê nhà"
      },
      {
        "hanzi": "收拾",
        "pinyin": "shōushi",
        "vi": "thu dọn"
      },
      {
        "hanzi": "租",
        "pinyin": "zū",
        "vi": "thuê"
      },
      {
        "hanzi": "嗯",
        "pinyin": "ng",
        "vi": "ừ; vâng"
      },
      {
        "hanzi": "亮",
        "pinyin": "liàng",
        "vi": "sáng"
      },
      {
        "hanzi": "就是",
        "pinyin": "jiùshì",
        "vi": "chính là; cứ… là được"
      },
      {
        "hanzi": "种",
        "pinyin": "zhòng",
        "vi": "trồng"
      },
      {
        "hanzi": "周围",
        "pinyin": "zhōuwéi",
        "vi": "xung quanh"
      },
      {
        "hanzi": "不过",
        "pinyin": "búguò",
        "vi": "tuy nhiên"
      },
      {
        "hanzi": "毕业",
        "pinyin": "bìyè",
        "vi": "tốt nghiệp"
      },
      {
        "hanzi": "恐怕",
        "pinyin": "kǒngpà",
        "vi": "e rằng"
      },
      {
        "hanzi": "热闹",
        "pinyin": "rènao",
        "vi": "náo nhiệt"
      },
      {
        "hanzi": "入住",
        "pinyin": "rùzhù",
        "vi": "dọn vào ở; nhận phòng"
      },
      {
        "hanzi": "日记",
        "pinyin": "rìjì",
        "vi": "nhật ký"
      },
      {
        "hanzi": "顺利",
        "pinyin": "shùnlì",
        "vi": "thuận lợi"
      },
      {
        "hanzi": "并",
        "pinyin": "bìng",
        "vi": "và; đồng thời; hoàn toàn (trước phủ định)"
      },
      {
        "hanzi": "客厅",
        "pinyin": "kètīng",
        "vi": "phòng khách"
      },
      {
        "hanzi": "台",
        "pinyin": "tái",
        "vi": "lượng từ cho máy móc"
      },
      {
        "hanzi": "厨房",
        "pinyin": "chúfáng",
        "vi": "nhà bếp"
      },
      {
        "hanzi": "平常",
        "pinyin": "píngcháng",
        "vi": "thường ngày"
      },
      {
        "hanzi": "基本上",
        "pinyin": "jīběnshang",
        "vi": "về cơ bản"
      },
      {
        "hanzi": "整个",
        "pinyin": "zhěnggè",
        "vi": "toàn bộ"
      },
      {
        "hanzi": "毛巾",
        "pinyin": "máojīn",
        "vi": "khăn mặt"
      },
      {
        "hanzi": "建议",
        "pinyin": "jiànyì",
        "vi": "đề nghị; lời khuyên"
      },
      {
        "hanzi": "查看",
        "pinyin": "chákàn",
        "vi": "xem xét; kiểm tra"
      },
      {
        "hanzi": "信息",
        "pinyin": "xìnxī",
        "vi": "thông tin"
      },
      {
        "hanzi": "查找",
        "pinyin": "cházhǎo",
        "vi": "tra tìm"
      },
      {
        "hanzi": "接着",
        "pinyin": "jiēzhe",
        "vi": "tiếp theo"
      },
      {
        "hanzi": "同时",
        "pinyin": "tóngshí",
        "vi": "đồng thời"
      },
      {
        "hanzi": "位置",
        "pinyin": "wèizhi",
        "vi": "vị trí"
      },
      {
        "hanzi": "价格",
        "pinyin": "jiàgé",
        "vi": "giá cả"
      },
      {
        "hanzi": "理想",
        "pinyin": "lǐxiǎng",
        "vi": "lý tưởng"
      },
      {
        "hanzi": "由于",
        "pinyin": "yóuyú",
        "vi": "do; bởi vì"
      },
      {
        "hanzi": "工资",
        "pinyin": "gōngzī",
        "vi": "tiền lương"
      },
      {
        "hanzi": "感",
        "pinyin": "gǎn",
        "vi": "cảm giác (hậu tố)"
      }
    ],
    "texts": [
      {
        "id": 1,
        "title": "课文 1",
        "content": "房东：请进！我给你们介绍一下，这个房子有两个房间，那个大房间出租，房租每月5500元。现在已经收拾好了，想租的话，今天就可以搬进来。\n白家月：嗯，这个房间真不小，还挺亮。小区离我们学校也不远。\n房东：是的，我们小区离地铁站也很近，生活上很方便。如果决定租了，告诉我就是了。\n白家月：好的，我们再去看看外边的环境。",
        "sourcePages": [
          23
        ],
        "targets": [
          "出租",
          "房租",
          "收拾",
          "嗯",
          "亮",
          "就是"
        ]
      },
      {
        "id": 2,
        "title": "课文 2",
        "content": "李文：家月，你看，那边还有个小花园。\n白家月：嗯，这个小区到处是花，还种了不少树，周围也很安静。\n李文：是啊！这个小区的环境真不错，不过我听说，附近有十几家公司，很多刚毕业的学生都租住在这里。周末他们可能会玩得很晚，恐怕会影响你休息。\n白家月：没关系，我还想多认识一些朋友，和他们一起玩呢。\n李文：是呢，大家可以一起热闹热闹。\n白家月：这里房租合适、环境很好，而且房东也热情，所以我决定租这个房子了，明天就入住新家。",
        "sourcePages": [
          25
        ],
        "targets": [
          "嗯",
          "种",
          "周围",
          "不过",
          "毕业",
          "恐怕",
          "热闹",
          "房租",
          "房东",
          "入住"
        ]
      },
      {
        "id": 3,
        "title": "课文 3",
        "content": "8月25日，晴\n昨天我顺利租到了合适的房子，今天李文帮我搬家。搬进去的时候，房东又向我介绍了一下房子里的东西，并告诉我这些东西怎么用。\n我看了一下，客厅里有椅子、沙发，还有一台大电视；厨房里有冰箱和一些做饭用的东西，不过，我平常主要在学校食堂吃，基本上不做饭。我租的房间里，除了一张床以外，还有一台空调、一张书桌和一把椅子。\n看完整个房子后，我准备再去买几条毛巾，其他东西不需要。",
        "sourcePages": [
          27
        ],
        "targets": [
          "顺利",
          "租",
          "房东",
          "客厅",
          "厨房",
          "不过",
          "平常",
          "基本上",
          "整个",
          "毛巾"
        ]
      },
      {
        "id": 4,
        "title": "课文 4",
        "content": "在李文的帮助下，白家月租到了合适的房子。对白家月来说，这次租房并不容易。根据李文的建议，她先在租房网站和App上查看有关信息，查找合适的房子，接着又去看了看房子，同时了解房子周围的环境。她看了好几个房子，才找到一个位置、环境和价格都合适的，最后顺利租到了理想的房子。\n租房的时候，李文告诉白家月，在中国，由于很多刚工作的年轻人工资还不太高，所以他们一开始也不买房，都选择租房。工作几年后，不少人就会买房，因为大家一直觉得，有房才有家，有自己的房子会更有安全感。",
        "sourcePages": [
          29
        ],
        "targets": [
          "建议",
          "查看",
          "信息",
          "查找",
          "接着",
          "同时",
          "周围",
          "位置",
          "价格",
          "顺利"
        ]
      }
    ],
    "translations": [
      {
        "vi": "Nếu quyết định thuê rồi thì cứ nói với tôi là được.",
        "zh": "如果决定租了，告诉我就是了。"
      },
      {
        "vi": "Cô ấy đã tìm được một căn nhà có vị trí, môi trường và giá cả đều phù hợp.",
        "zh": "她找到了一个位置、环境和价格都合适的房子。"
      },
      {
        "vi": "Do lương của nhiều người trẻ mới đi làm chưa cao nên ban đầu họ chọn thuê nhà.",
        "zh": "由于很多刚工作的年轻人工资还不太高，所以他们一开始都选择租房。"
      }
    ]
  },
  {
    "n": 3,
    "title": "手机扫一扫",
    "volume": "上",
    "page": 23,
    "grammar": [
      "……是……，就是/不过……",
      "不仅/不光……，还/而且……",
      "甚至",
      "于是"
    ],
    "words": [
      {
        "hanzi": "十字路口",
        "pinyin": "shízì lùkǒu",
        "vi": "ngã tư"
      },
      {
        "hanzi": "直接",
        "pinyin": "zhíjiē",
        "vi": "trực tiếp"
      },
      {
        "hanzi": "转",
        "pinyin": "zhuǎn",
        "vi": "rẽ; chuyển"
      },
      {
        "hanzi": "正好",
        "pinyin": "zhènghǎo",
        "vi": "vừa hay; đúng lúc"
      },
      {
        "hanzi": "熟悉",
        "pinyin": "shúxī",
        "vi": "quen thuộc"
      },
      {
        "hanzi": "正",
        "pinyin": "zhèng",
        "vi": "chính; thẳng"
      },
      {
        "hanzi": "目的地",
        "pinyin": "mùdìdì",
        "vi": "điểm đến"
      },
      {
        "hanzi": "下载",
        "pinyin": "xiàzài",
        "vi": "tải xuống"
      },
      {
        "hanzi": "进行",
        "pinyin": "jìnxíng",
        "vi": "tiến hành"
      },
      {
        "hanzi": "支付",
        "pinyin": "zhīfù",
        "vi": "thanh toán"
      },
      {
        "hanzi": "软件",
        "pinyin": "ruǎnjiàn",
        "vi": "phần mềm"
      },
      {
        "hanzi": "不仅",
        "pinyin": "bùjǐn",
        "vi": "không chỉ"
      },
      {
        "hanzi": "扫码",
        "pinyin": "sǎomǎ",
        "vi": "quét mã"
      },
      {
        "hanzi": "结账",
        "pinyin": "jiézhàng",
        "vi": "thanh toán hóa đơn"
      },
      {
        "hanzi": "购物",
        "pinyin": "gòuwù",
        "vi": "mua sắm"
      },
      {
        "hanzi": "订",
        "pinyin": "dìng",
        "vi": "đặt trước"
      },
      {
        "hanzi": "快递",
        "pinyin": "kuàidì",
        "vi": "chuyển phát nhanh"
      },
      {
        "hanzi": "现金",
        "pinyin": "xiànjīn",
        "vi": "tiền mặt"
      },
      {
        "hanzi": "网购",
        "pinyin": "wǎnggòu",
        "vi": "mua sắm trực tuyến"
      },
      {
        "hanzi": "寄",
        "pinyin": "jì",
        "vi": "gửi"
      },
      {
        "hanzi": "等",
        "pinyin": "děng",
        "vi": "vân vân"
      },
      {
        "hanzi": "货",
        "pinyin": "huò",
        "vi": "hàng hóa"
      },
      {
        "hanzi": "甚至",
        "pinyin": "shènzhì",
        "vi": "thậm chí"
      },
      {
        "hanzi": "改变",
        "pinyin": "gǎibiàn",
        "vi": "thay đổi"
      },
      {
        "hanzi": "手指",
        "pinyin": "shǒuzhǐ",
        "vi": "ngón tay"
      },
      {
        "hanzi": "乱",
        "pinyin": "luàn",
        "vi": "bừa bãi; lung tung"
      },
      {
        "hanzi": "管",
        "pinyin": "guǎn",
        "vi": "quản lý; kiểm soát"
      },
      {
        "hanzi": "提供",
        "pinyin": "tígōng",
        "vi": "cung cấp"
      },
      {
        "hanzi": "身份证",
        "pinyin": "shēnfènzhèng",
        "vi": "căn cước công dân"
      },
      {
        "hanzi": "个人",
        "pinyin": "gèrén",
        "vi": "cá nhân"
      },
      {
        "hanzi": "能否",
        "pinyin": "néngfǒu",
        "vi": "có thể hay không"
      },
      {
        "hanzi": "保护",
        "pinyin": "bǎohù",
        "vi": "bảo vệ"
      },
      {
        "hanzi": "于是",
        "pinyin": "yúshì",
        "vi": "thế là"
      },
      {
        "hanzi": "密码",
        "pinyin": "mìmǎ",
        "vi": "mật khẩu"
      },
      {
        "hanzi": "随便",
        "pinyin": "suíbiàn",
        "vi": "tùy tiện"
      },
      {
        "hanzi": "技术",
        "pinyin": "jìshù",
        "vi": "kỹ thuật; công nghệ"
      },
      {
        "hanzi": "法律",
        "pinyin": "fǎlǜ",
        "vi": "pháp luật"
      },
      {
        "hanzi": "手段",
        "pinyin": "shǒuduàn",
        "vi": "biện pháp; phương tiện"
      },
      {
        "hanzi": "保证",
        "pinyin": "bǎozhèng",
        "vi": "bảo đảm"
      },
      {
        "hanzi": "网络",
        "pinyin": "wǎngluò",
        "vi": "mạng"
      },
      {
        "hanzi": "微信",
        "pinyin": "Wēixìn",
        "vi": "WeChat",
        "properNoun": true
      },
      {
        "hanzi": "支付宝",
        "pinyin": "Zhīfùbǎo",
        "vi": "Alipay",
        "properNoun": true
      }
    ],
    "texts": [
      {
        "id": 1,
        "title": "课文 1",
        "content": "陈天中：请问，花园小区怎么走？\n同学：你往前走，到十字路口不要过马路，直接右转就到小区门口了。正好我也去那边，一起走吧。\n陈天中：好的。我刚来中国，不熟悉路。北京真是太大了。\n同学：北京大是大，不过这边的路基本上都是正南正北、正东正西的，很好找。你也可以用手机地图，很容易就能找到目的地。\n陈天中：嗯，不过很多中文地名我还不认识。\n同学：没关系，你很快就会熟悉的。",
        "sourcePages": [
          34
        ],
        "targets": [
          "十字路口",
          "直接",
          "转",
          "正好",
          "熟悉",
          "目的地"
        ]
      },
      {
        "id": 2,
        "title": "课文 2",
        "content": "陈天中：前两天和李文喝咖啡时，他帮我下载了微信和支付宝，教我认识里边的汉字，还教我用手机进行支付。\n白家月：他也教了我怎么用这两个软件。\n陈天中：现在我不仅会扫码结账，还会用手机在网上购物了。昨天我就在网上订了一台电脑，今天下午一点送到。\n白家月：学会了这些，我们在中国生活真是方便了不少。\n陈天中：对，快递员要到了，我得马上回去！家月，明天见！\n白家月：好的，天中，再见。",
        "sourcePages": [
          36,
          37
        ],
        "targets": [
          "下载",
          "支付",
          "进行",
          "软件",
          "不仅",
          "扫码",
          "结账",
          "购物",
          "订",
          "快递"
        ]
      },
      {
        "id": 3,
        "title": "课文 3",
        "content": "白家月和陈天中刚到北京时就发现，中国人在饭馆或超市结账时，几乎都用手机支付，只有他们用现金结账。\n在李文的帮助下，白家月和陈天中都学会了用手机支付、网购、寄快递等等。在中国网购，不仅选择多、价格不高，而且送货很快，很多留学生甚至改变了自己的购物习惯。不过，由于网购太方便了，动动手指就能买到想要的东西，他们也开始担心自己在网购时会乱花钱。怎么才能管住自己不乱花钱呢？",
        "sourcePages": [
          38
        ],
        "targets": [
          "结账",
          "支付",
          "现金",
          "网购",
          "快递",
          "不仅",
          "甚至",
          "改变",
          "购物",
          "手指"
        ]
      },
      {
        "id": 4,
        "title": "课文 4",
        "content": "网上购物或者订票时，我们经常需要提供姓名、手机号、身份证号等个人信息。在提供这些信息时，我们也会担心：我的个人信息能否得到保护？于是，有人在网上说出了自己的担心，很快就有人给出了一些建议。比如，别把密码随便告诉别人，不在网上发自己的车票、机票信息……\n现在，很多国家也通过技术、法律等手段来保证个人信息安全。比如中国的网络安全法、个人信息保护法等就很好地保护了人们的个人信息。",
        "sourcePages": [
          40
        ],
        "targets": [
          "购物",
          "提供",
          "身份证",
          "个人",
          "能否",
          "保护",
          "于是",
          "密码",
          "随便",
          "技术"
        ]
      }
    ],
    "translations": [
      {
        "vi": "Đến ngã tư không cần qua đường, rẽ phải luôn là đến cổng khu chung cư.",
        "zh": "到十字路口不要过马路，直接右转就到小区门口了。"
      },
      {
        "vi": "Bây giờ tôi không chỉ biết quét mã thanh toán mà còn biết dùng điện thoại mua sắm trên mạng.",
        "zh": "现在我不仅会扫码结账，还会用手机在网上购物了。"
      },
      {
        "vi": "Đừng tùy tiện nói mật khẩu của mình cho người khác.",
        "zh": "别把密码随便告诉别人。"
      }
    ]
  },
  {
    "n": 4,
    "title": "很高兴能帮到你",
    "volume": "上",
    "page": 35,
    "grammar": [
      "动词＋得/不了",
      "再说",
      "既……，又/也……",
      "来得及/来不及"
    ],
    "words": [
      {
        "hanzi": "啊",
        "pinyin": "a",
        "vi": "a; ôi"
      },
      {
        "hanzi": "停",
        "pinyin": "tíng",
        "vi": "dừng"
      },
      {
        "hanzi": "交",
        "pinyin": "jiāo",
        "vi": "nộp; đóng"
      },
      {
        "hanzi": "费",
        "pinyin": "fèi",
        "vi": "phí; chi phí"
      },
      {
        "hanzi": "信号",
        "pinyin": "xìnhào",
        "vi": "tín hiệu"
      },
      {
        "hanzi": "感谢",
        "pinyin": "gǎnxiè",
        "vi": "cảm ơn"
      },
      {
        "hanzi": "联系",
        "pinyin": "liánxì",
        "vi": "liên hệ"
      },
      {
        "hanzi": "方式",
        "pinyin": "fāngshì",
        "vi": "phương thức"
      },
      {
        "hanzi": "客气",
        "pinyin": "kèqi",
        "vi": "khách sáo"
      },
      {
        "hanzi": "剩",
        "pinyin": "shèng",
        "vi": "còn lại"
      },
      {
        "hanzi": "提",
        "pinyin": "tí",
        "vi": "xách"
      },
      {
        "hanzi": "袋子",
        "pinyin": "dàizi",
        "vi": "túi"
      },
      {
        "hanzi": "重",
        "pinyin": "zhòng",
        "vi": "nặng; trọng lượng"
      },
      {
        "hanzi": "算",
        "pinyin": "suàn",
        "vi": "tính; coi như"
      },
      {
        "hanzi": "再说",
        "pinyin": "zàishuō",
        "vi": "hơn nữa"
      },
      {
        "hanzi": "之间",
        "pinyin": "zhījiān",
        "vi": "giữa"
      },
      {
        "hanzi": "互相",
        "pinyin": "hùxiāng",
        "vi": "lẫn nhau"
      },
      {
        "hanzi": "辛苦",
        "pinyin": "xīnkǔ",
        "vi": "vất vả"
      },
      {
        "hanzi": "出行",
        "pinyin": "chūxíng",
        "vi": "đi lại"
      },
      {
        "hanzi": "距离",
        "pinyin": "jùlí",
        "vi": "khoảng cách"
      },
      {
        "hanzi": "往往",
        "pinyin": "wǎngwǎng",
        "vi": "thường thường"
      },
      {
        "hanzi": "既",
        "pinyin": "jì",
        "vi": "vừa; đã"
      },
      {
        "hanzi": "电动车",
        "pinyin": "diàndòngchē",
        "vi": "xe điện"
      },
      {
        "hanzi": "速度",
        "pinyin": "sùdù",
        "vi": "tốc độ"
      },
      {
        "hanzi": "充电",
        "pinyin": "chōngdiàn",
        "vi": "sạc điện"
      },
      {
        "hanzi": "流行",
        "pinyin": "liúxíng",
        "vi": "thịnh hành"
      },
      {
        "hanzi": "省",
        "pinyin": "shěng",
        "vi": "tiết kiệm"
      },
      {
        "hanzi": "力气",
        "pinyin": "lìqi",
        "vi": "sức lực"
      },
      {
        "hanzi": "乘客",
        "pinyin": "chéngkè",
        "vi": "hành khách"
      },
      {
        "hanzi": "购买",
        "pinyin": "gòumǎi",
        "vi": "mua"
      },
      {
        "hanzi": "食物",
        "pinyin": "shíwù",
        "vi": "thức ăn"
      },
      {
        "hanzi": "免费",
        "pinyin": "miǎnfèi",
        "vi": "miễn phí"
      },
      {
        "hanzi": "早餐",
        "pinyin": "zǎocān",
        "vi": "bữa sáng"
      },
      {
        "hanzi": "来得及",
        "pinyin": "láidejí",
        "vi": "kịp"
      },
      {
        "hanzi": "鲜花",
        "pinyin": "xiānhuā",
        "vi": "hoa tươi"
      },
      {
        "hanzi": "顺便",
        "pinyin": "shùnbiàn",
        "vi": "tiện thể"
      },
      {
        "hanzi": "心情",
        "pinyin": "xīnqíng",
        "vi": "tâm trạng"
      },
      {
        "hanzi": "更加",
        "pinyin": "gèngjiā",
        "vi": "càng thêm"
      },
      {
        "hanzi": "愉快",
        "pinyin": "yúkuài",
        "vi": "vui vẻ"
      }
    ],
    "texts": [
      {
        "id": 1,
        "title": "课文 1",
        "content": "陈天中：啊，我的手机停机了！怎么办啊？\n路人：你好，你看上去很着急，需要帮忙吗？\n陈天中：我忘了交电话费，手机停机了。我没带现金，手机没有信号，上不了网，买不了地铁票了。\n路人：你要去哪儿？我帮你买张票。\n陈天中：太感谢你了，我要去北京大学站。对了，能不能告诉我你的联系方式？我想把钱还给你。\n路人：别客气，很高兴能帮到你。",
        "sourcePages": [
          46
        ],
        "targets": [
          "啊",
          "停",
          "交",
          "费",
          "信号",
          "感谢",
          "联系",
          "方式",
          "客气"
        ]
      },
      {
        "id": 2,
        "title": "课文 2",
        "content": "白家月：阿姨，您怎么站在这儿不上楼？\n邻居：我开车去超市买了不少东西，刚拿过来了一些。我先休息一会儿，再去车里拿剩下的。\n白家月：我正好要上楼，我帮您提上去吧。\n邻居：不用不用，这几个袋子太重了，我自己拿吧。\n白家月：没事，我提着这些东西就算锻炼身体了，再说邻居之间就是要互相帮助啊。\n邻居：谢谢家月！那就辛苦你了。",
        "sourcePages": [
          48
        ],
        "targets": [
          "剩",
          "提",
          "袋子",
          "重",
          "算",
          "再说",
          "之间",
          "互相",
          "啊",
          "辛苦"
        ]
      },
      {
        "id": 3,
        "title": "课文 3",
        "content": "在城市里，人们出行的方式越来越多。短距离出行时，骑自行车往往是人们常见的选择。白家月就很喜欢骑车去学校，她觉得这样既方便，又能锻炼身体，还能保护环境。\n除了骑自行车，人们还会选择骑电动车。电动车速度快，价格不高，充电也很方便，所以越来越流行。陈天中平时也骑自行车，不过为了省力气，他最近打算买一辆电动车。",
        "sourcePages": [
          50
        ],
        "targets": [
          "出行",
          "方式",
          "距离",
          "往往",
          "既",
          "电动车",
          "速度",
          "充电",
          "流行",
          "力气"
        ]
      },
      {
        "id": 4,
        "title": "课文 4",
        "content": "在中国，乘客可以在不少地铁站里直接扫码购买食物和饮料，有的地铁站还提供免费借雨伞、发雨衣等服务。\n有些地铁站附近公司比较多，工作日站里还有早餐车，没来得及吃早饭的人在这里就能买到热包子和牛奶等，省了不少时间。有的地铁站甚至还有鲜花店，乘客下班时可以顺便买花送给家人。\n这些小小的服务，不仅方便了人们的出行，也让大家的心情变得更加愉快。",
        "sourcePages": [
          52
        ],
        "targets": [
          "乘客",
          "购买",
          "食物",
          "免费",
          "早餐",
          "来得及",
          "鲜花",
          "顺便",
          "出行",
          "心情"
        ]
      }
    ],
    "translations": [
      {
        "vi": "Điện thoại không có tín hiệu nên tôi không thể lên mạng và mua vé tàu điện ngầm.",
        "zh": "手机没有信号，上不了网，买不了地铁票了。"
      },
      {
        "vi": "Cô ấy cảm thấy như vậy vừa thuận tiện, vừa có thể rèn luyện thân thể.",
        "zh": "她觉得这样既方便，又能锻炼身体。"
      },
      {
        "vi": "Hành khách tan làm có thể tiện thể mua hoa tặng người nhà.",
        "zh": "乘客下班时可以顺便买花送给家人。"
      }
    ]
  },
  {
    "n": 5,
    "title": "“不怕辣”和“怕不辣”",
    "volume": "上",
    "page": 47,
    "grammar": [
      "至少",
      "够",
      "各×各的",
      "等"
    ],
    "words": [
      {
        "hanzi": "至少",
        "pinyin": "zhìshǎo",
        "vi": "ít nhất"
      },
      {
        "hanzi": "中餐",
        "pinyin": "zhōngcān",
        "vi": "món ăn Trung Quốc; bữa ăn kiểu Trung Quốc"
      },
      {
        "hanzi": "专门",
        "pinyin": "zhuānmén",
        "vi": "chuyên; đặc biệt"
      },
      {
        "hanzi": "煮",
        "pinyin": "zhǔ",
        "vi": "nấu; luộc"
      },
      {
        "hanzi": "油",
        "pinyin": "yóu",
        "vi": "dầu"
      },
      {
        "hanzi": "道",
        "pinyin": "dào",
        "vi": "lượng từ cho món ăn"
      },
      {
        "hanzi": "熟",
        "pinyin": "shú/shóu",
        "vi": "chín; quen thuộc"
      },
      {
        "hanzi": "倒",
        "pinyin": "dào",
        "vi": "rót; đổ"
      },
      {
        "hanzi": "辣椒",
        "pinyin": "làjiāo",
        "vi": "ớt"
      },
      {
        "hanzi": "辣",
        "pinyin": "là",
        "vi": "cay"
      },
      {
        "hanzi": "敢",
        "pinyin": "gǎn",
        "vi": "dám"
      },
      {
        "hanzi": "肚子",
        "pinyin": "dùzi",
        "vi": "bụng"
      },
      {
        "hanzi": "相同",
        "pinyin": "xiāngtóng",
        "vi": "giống nhau"
      },
      {
        "hanzi": "顺序",
        "pinyin": "shùnxù",
        "vi": "thứ tự"
      },
      {
        "hanzi": "够",
        "pinyin": "gòu",
        "vi": "đủ; khá"
      },
      {
        "hanzi": "不够",
        "pinyin": "búgòu",
        "vi": "không đủ"
      },
      {
        "hanzi": "达到",
        "pinyin": "dádào",
        "vi": "đạt đến"
      },
      {
        "hanzi": "聚",
        "pinyin": "jù",
        "vi": "tụ họp"
      },
      {
        "hanzi": "午餐",
        "pinyin": "wǔcān",
        "vi": "bữa trưa"
      },
      {
        "hanzi": "咸",
        "pinyin": "xián",
        "vi": "mặn"
      },
      {
        "hanzi": "凉",
        "pinyin": "liáng",
        "vi": "mát; nguội"
      },
      {
        "hanzi": "酸",
        "pinyin": "suān",
        "vi": "chua"
      },
      {
        "hanzi": "汤",
        "pinyin": "tāng",
        "vi": "canh; súp"
      },
      {
        "hanzi": "各",
        "pinyin": "gè",
        "vi": "mỗi; từng"
      },
      {
        "hanzi": "付",
        "pinyin": "fù",
        "vi": "trả (tiền)"
      },
      {
        "hanzi": "聚餐",
        "pinyin": "jùcān",
        "vi": "tụ họp ăn uống"
      },
      {
        "hanzi": "随意",
        "pinyin": "suíyì",
        "vi": "tùy ý"
      },
      {
        "hanzi": "正式",
        "pinyin": "zhèngshì",
        "vi": "chính thức"
      },
      {
        "hanzi": "普通",
        "pinyin": "pǔtōng",
        "vi": "thông thường"
      },
      {
        "hanzi": "重视",
        "pinyin": "zhòngshì",
        "vi": "coi trọng"
      },
      {
        "hanzi": "座位",
        "pinyin": "zuòwèi",
        "vi": "chỗ ngồi"
      },
      {
        "hanzi": "安排",
        "pinyin": "ānpái",
        "vi": "sắp xếp"
      },
      {
        "hanzi": "按照",
        "pinyin": "ànzhào",
        "vi": "theo"
      },
      {
        "hanzi": "年龄",
        "pinyin": "niánlíng",
        "vi": "tuổi tác"
      },
      {
        "hanzi": "面对",
        "pinyin": "miànduì",
        "vi": "đối diện"
      },
      {
        "hanzi": "主人",
        "pinyin": "zhǔrén",
        "vi": "chủ nhà"
      },
      {
        "hanzi": "等",
        "pinyin": "děng",
        "vi": "đợi đến khi"
      },
      {
        "hanzi": "尊重",
        "pinyin": "zūnzhòng",
        "vi": "tôn trọng"
      },
      {
        "hanzi": "水煮鱼",
        "pinyin": "Shuǐzhǔyú",
        "vi": "cá nấu kiểu Tứ Xuyên",
        "properNoun": true
      },
      {
        "hanzi": "辣子鸡",
        "pinyin": "Làzǐjī",
        "vi": "gà xào ớt",
        "properNoun": true
      },
      {
        "hanzi": "松鼠鳜鱼",
        "pinyin": "Sōngshǔ Guìyú",
        "vi": "cá quế chế biến hình sóc",
        "properNoun": true
      },
      {
        "hanzi": "红烧羊肉",
        "pinyin": "Hóngshāo Yángròu",
        "vi": "thịt cừu kho",
        "properNoun": true
      },
      {
        "hanzi": "贵州",
        "pinyin": "Guìzhōu",
        "vi": "Quý Châu",
        "properNoun": true
      },
      {
        "hanzi": "酸汤米线",
        "pinyin": "Suāntāng Mǐxiàn",
        "vi": "bún gạo canh chua",
        "properNoun": true
      }
    ],
    "texts": [
      {
        "id": 1,
        "title": "课文 1",
        "content": "刘明：家月，你来中国至少两个月了，习惯吃中餐了吗？\n白家月：习惯了，而且我很喜欢吃中国菜。\n王一雪：你还没吃过水煮鱼吧？这是我专门为你做的。\n白家月：看起来不像水煮鱼，更像“油煮鱼”。\n王一雪：这道菜是先用水把鱼煮熟，最后再倒上辣椒油，其实只有最上面那一层是油。你尝尝，对你来说辣不辣？\n白家月：辣是辣，但是非常好吃！\n刘明：那你多吃点儿，不要客气。",
        "sourcePages": [
          58,
          59
        ],
        "targets": [
          "至少",
          "中餐",
          "煮",
          "专门",
          "油",
          "道",
          "熟",
          "倒",
          "辣椒"
        ]
      },
      {
        "id": 2,
        "title": "课文 2",
        "content": "王一雪：我听李文说，你现在也爱吃辣了？\n白家月：是的，来中国以后，我越来越喜欢吃辣了。\n王一雪：我们以前不太敢吃辣，吃完可能会肚子不舒服，不过现在也慢慢适应了。\n刘明：对，我们现在都不怕辣了。家月，你是“不怕辣”还是“怕不辣”？\n白家月：中文真有意思，相同的字，顺序一换，意思就变了。\n刘明：你的中文水平够高的，这都听懂了！你说得对，“不怕辣”是说不怕吃辣的菜，“怕不辣”是担心菜还不够辣呢。\n白家月：我还达不到“怕不辣”的水平，甚至也不能算“不怕辣”，只是喜欢吃辣。",
        "sourcePages": [
          60,
          61
        ],
        "targets": [
          "辣",
          "敢",
          "肚子",
          "相同",
          "顺序",
          "够",
          "不够"
        ]
      },
      {
        "id": 3,
        "title": "课文 3",
        "content": "周末，白家月、陈天中、李文和安妮聚在一起吃午餐。白家月想吃辣的，要了辣子鸡；陈天中爱吃甜的，想尝尝松鼠鳜鱼；李文更喜欢吃咸的，点了红烧羊肉和一道凉菜；安妮听说贵州酸汤很有名，点了酸汤米线。他们边吃边聊，非常愉快。\n结账时，李文想请客，但大家觉得还是各付各的更合适。于是，李文付完钱后，大家把钱转给了他，还笑着说下次再一起聚餐。",
        "sourcePages": [
          62,
          63
        ],
        "targets": [
          "聚",
          "午餐",
          "辣",
          "咸",
          "道",
          "凉",
          "酸",
          "汤",
          "各",
          "聚餐"
        ]
      },
      {
        "id": 4,
        "title": "课文 4",
        "content": "今天吃饭的时候，大家坐得比较随意。李文告诉白家月，在中国，正式聚餐和普通聚餐不同，正式聚餐时人们比较重视座位的安排，比如可以按照年龄大小来安排，年龄比较大的客人往往会坐在中间或者面对门口的座位。大家坐下时，主人会请客人先坐。如果聚餐时有老人，年轻人要等老人坐下后再坐。\n白家月听后觉得很有意思，她认为这么做是照顾客人、尊重老人的表现。",
        "sourcePages": [
          64
        ],
        "targets": [
          "随意",
          "正式",
          "聚餐",
          "普通",
          "重视",
          "座位",
          "安排",
          "按照",
          "年龄",
          "面对"
        ]
      }
    ],
    "translations": [
      {
        "vi": "Bạn đến Trung Quốc ít nhất hai tháng rồi, đã quen ăn món Trung Quốc chưa?",
        "zh": "你来中国至少两个月了，习惯吃中餐了吗？"
      },
      {
        "vi": "Cùng một chữ, chỉ cần đổi thứ tự thì ý nghĩa đã thay đổi.",
        "zh": "相同的字，顺序一换，意思就变了。"
      },
      {
        "vi": "Nếu có người lớn tuổi trong buổi tụ họp ăn uống, người trẻ nên đợi họ ngồi xuống rồi mới ngồi.",
        "zh": "如果聚餐时有老人，年轻人要等老人坐下后再坐。"
      }
    ]
  },
  {
    "n": 6,
    "title": "我陪你去看病",
    "volume": "上",
    "page": 59,
    "grammar": [
      "厉害",
      "（没）有什么（好）×的",
      "偶尔",
      "……，好……"
    ],
    "words": [
      {
        "hanzi": "咳嗽",
        "pinyin": "késou",
        "vi": "ho"
      },
      {
        "hanzi": "咳",
        "pinyin": "ké",
        "vi": "ho"
      },
      {
        "hanzi": "厉害",
        "pinyin": "lìhai",
        "vi": "nghiêm trọng; lợi hại"
      },
      {
        "hanzi": "严重",
        "pinyin": "yánzhòng",
        "vi": "nghiêm trọng"
      },
      {
        "hanzi": "赶快",
        "pinyin": "gǎnkuài",
        "vi": "mau chóng"
      },
      {
        "hanzi": "陪",
        "pinyin": "péi",
        "vi": "đi cùng; ở bên"
      },
      {
        "hanzi": "翻译",
        "pinyin": "fānyì",
        "vi": "phiên dịch; dịch"
      },
      {
        "hanzi": "护士",
        "pinyin": "hùshi",
        "vi": "y tá"
      },
      {
        "hanzi": "表",
        "pinyin": "biǎo",
        "vi": "biểu mẫu"
      },
      {
        "hanzi": "性别",
        "pinyin": "xìngbié",
        "vi": "giới tính"
      },
      {
        "hanzi": "国籍",
        "pinyin": "guójí",
        "vi": "quốc tịch"
      },
      {
        "hanzi": "家庭",
        "pinyin": "jiātíng",
        "vi": "gia đình"
      },
      {
        "hanzi": "地址",
        "pinyin": "dìzhǐ",
        "vi": "địa chỉ"
      },
      {
        "hanzi": "挂号",
        "pinyin": "guàhào",
        "vi": "đăng ký khám bệnh"
      },
      {
        "hanzi": "排队",
        "pinyin": "páiduì",
        "vi": "xếp hàng"
      },
      {
        "hanzi": "大厅",
        "pinyin": "dàtīng",
        "vi": "sảnh lớn"
      },
      {
        "hanzi": "偶尔",
        "pinyin": "ǒu'ěr",
        "vi": "thỉnh thoảng"
      },
      {
        "hanzi": "身",
        "pinyin": "shēn",
        "vi": "thân mình; bộ (quần áo)"
      },
      {
        "hanzi": "结果",
        "pinyin": "jiéguǒ",
        "vi": "kết quả"
      },
      {
        "hanzi": "性",
        "pinyin": "xìng",
        "vi": "tính; thuộc tính (hậu tố)"
      },
      {
        "hanzi": "体温",
        "pinyin": "tǐwēn",
        "vi": "thân nhiệt"
      },
      {
        "hanzi": "降",
        "pinyin": "jiàng",
        "vi": "giảm; hạ"
      },
      {
        "hanzi": "光",
        "pinyin": "guāng",
        "vi": "chỉ"
      },
      {
        "hanzi": "打针",
        "pinyin": "dǎzhēn",
        "vi": "tiêm thuốc"
      },
      {
        "hanzi": "有效",
        "pinyin": "yǒuxiào",
        "vi": "có hiệu quả"
      },
      {
        "hanzi": "按时",
        "pinyin": "ànshí",
        "vi": "đúng giờ"
      },
      {
        "hanzi": "汗",
        "pinyin": "hàn",
        "vi": "mồ hôi"
      },
      {
        "hanzi": "醒",
        "pinyin": "xǐng",
        "vi": "tỉnh dậy"
      },
      {
        "hanzi": "感觉",
        "pinyin": "gǎnjué",
        "vi": "cảm thấy; cảm giác"
      },
      {
        "hanzi": "低",
        "pinyin": "dī",
        "vi": "thấp"
      },
      {
        "hanzi": "难受",
        "pinyin": "nánshòu",
        "vi": "khó chịu"
      },
      {
        "hanzi": "通",
        "pinyin": "tōng",
        "vi": "thông; hiểu"
      },
      {
        "hanzi": "过程",
        "pinyin": "guòchéng",
        "vi": "quá trình"
      },
      {
        "hanzi": "部",
        "pinyin": "bù",
        "vi": "bộ phận"
      },
      {
        "hanzi": "收费",
        "pinyin": "shōufèi",
        "vi": "thu phí"
      },
      {
        "hanzi": "情况",
        "pinyin": "qíngkuàng",
        "vi": "tình hình"
      },
      {
        "hanzi": "好",
        "pinyin": "hǎo",
        "vi": "để; nhằm"
      },
      {
        "hanzi": "治疗",
        "pinyin": "zhìliáo",
        "vi": "điều trị"
      },
      {
        "hanzi": "步",
        "pinyin": "bù",
        "vi": "bước"
      }
    ],
    "texts": [
      {
        "id": 1,
        "title": "课文 1",
        "content": "白家月：喂，李文，我身体不舒服。\n李文：你怎么了？听你的声音，好像感冒了。\n白家月：对，我还发烧、一直咳嗽，咳得很厉害。\n李文：那挺严重的，最好赶快去医院检查一下。\n白家月：我也这么想，不过我来中国后还没去过医院，不知道怎么在中国的医院看病。\n李文：没关系，我陪你一起去，还能帮你翻译。你在家等一下，我现在就去接你。\n白家月：太好了！有你陪着，我就放心多了。",
        "sourcePages": [
          70
        ],
        "targets": [
          "身",
          "好",
          "咳嗽",
          "厉害",
          "严重",
          "赶快",
          "陪",
          "翻译"
        ]
      },
      {
        "id": 2,
        "title": "课文 2",
        "content": "李文：护士，您好，我的这位外国朋友生病了，第一次来这里看病，需要怎么做？\n护士：请在这张表上写上病人的姓名、性别、国籍、年龄、电话号码和家庭地址。\n李文：我写好了，您看看，这样可以吗？\n护士：没问题，您拿着病人的护照去挂号吧。\n李文：家月，我去排队挂号，你先在大厅休息，别着急。\n白家月：好的，真是太谢谢你了！\n李文：你跟我有什么好客气的。",
        "sourcePages": [
          72
        ],
        "targets": [
          "护士",
          "好",
          "表",
          "性别",
          "国籍",
          "家庭",
          "地址",
          "挂号",
          "排队",
          "大厅"
        ]
      },
      {
        "id": 3,
        "title": "课文 3",
        "content": "下午白家月去看病了，她告诉医生，自己平时身体不错，偶尔才会生一次病。这次她病得很厉害，头也一直疼，身上一点儿力气都没有。医生给她做了检查，检查结果出来后，发现她得了比较严重的流行性感冒。\n医生告诉她，现在需要把体温降下来，光吃药恐怕不够，打针会更有效。医生还让她回家以后按时吃药，多喝水，多休息。\n晚上，白家月睡觉时出了一身汗。第二天醒来时，她感觉头不那么疼了，体温也低了一些，身体不那么难受了。",
        "sourcePages": [
          74
        ],
        "targets": [
          "偶尔",
          "厉害",
          "结果",
          "严重",
          "体温",
          "打针",
          "有效",
          "按时",
          "感觉",
          "难受"
        ]
      },
      {
        "id": 4,
        "title": "课文 4",
        "content": "外国人第一次在中国看病，可能会担心语言不通，或者觉得看病的过程和自己的国家不同。其实，这些问题都有办法解决。\n有的医院有国际部，那里的医生一般会说英文，交流比较方便，但是国际部的收费比较高。如果没有特别需要，可以选择普通部，用简单的中文和医生交流。\n在中国看病要先挂号，然后再去找医生。医生会问病人的情况，有时还会做一些检查，好给出合适的治疗方法。只要按照医生说的一步一步来，一般都可以顺利得到治疗。",
        "sourcePages": [
          76
        ],
        "targets": [
          "通",
          "过程",
          "部",
          "收费",
          "挂号",
          "情况",
          "好",
          "治疗",
          "步"
        ]
      }
    ],
    "translations": [
      {
        "vi": "Bác sĩ còn dặn cô ấy sau khi về nhà uống thuốc đúng giờ, uống nhiều nước và nghỉ ngơi nhiều.",
        "zh": "医生还让她回家以后按时吃药，多喝水，多休息。"
      },
      {
        "vi": "Tôi đi xếp hàng đăng ký khám, bạn nghỉ ở sảnh trước nhé.",
        "zh": "我去排队挂号，你先在大厅休息。"
      },
      {
        "vi": "Nếu không có nhu cầu đặc biệt, có thể chọn khoa thông thường.",
        "zh": "如果没有特别需要，可以选择普通部。"
      }
    ]
  },
  {
    "n": 7,
    "title": "在工作中学习",
    "volume": "上",
    "page": 71,
    "grammar": [
      "在……方面",
      "既然……，就……",
      "拿……来说",
      "使字句"
    ],
    "words": [
      {
        "hanzi": "打扰",
        "pinyin": "dǎrǎo",
        "vi": "làm phiền"
      },
      {
        "hanzi": "市场",
        "pinyin": "shìchǎng",
        "vi": "thị trường"
      },
      {
        "hanzi": "调查",
        "pinyin": "diàochá",
        "vi": "điều tra; khảo sát"
      },
      {
        "hanzi": "计划",
        "pinyin": "jìhuà",
        "vi": "kế hoạch"
      },
      {
        "hanzi": "内容",
        "pinyin": "nèiróng",
        "vi": "nội dung"
      },
      {
        "hanzi": "改",
        "pinyin": "gǎi",
        "vi": "sửa đổi"
      },
      {
        "hanzi": "细心",
        "pinyin": "xìxīn",
        "vi": "cẩn thận"
      },
      {
        "hanzi": "客户",
        "pinyin": "kèhù",
        "vi": "khách hàng"
      },
      {
        "hanzi": "真正",
        "pinyin": "zhēnzhèng",
        "vi": "thực sự"
      },
      {
        "hanzi": "想法",
        "pinyin": "xiǎngfǎ",
        "vi": "ý tưởng"
      },
      {
        "hanzi": "任务",
        "pinyin": "rènwu",
        "vi": "nhiệm vụ"
      },
      {
        "hanzi": "及时",
        "pinyin": "jíshí",
        "vi": "kịp thời"
      },
      {
        "hanzi": "出差",
        "pinyin": "chūchāi",
        "vi": "đi công tác"
      },
      {
        "hanzi": "经验",
        "pinyin": "jīngyàn",
        "vi": "kinh nghiệm"
      },
      {
        "hanzi": "采访",
        "pinyin": "cǎifǎng",
        "vi": "phỏng vấn"
      },
      {
        "hanzi": "产品",
        "pinyin": "chǎnpǐn",
        "vi": "sản phẩm"
      },
      {
        "hanzi": "看法",
        "pinyin": "kànfǎ",
        "vi": "quan điểm"
      },
      {
        "hanzi": "提前",
        "pinyin": "tíqián",
        "vi": "trước thời hạn"
      },
      {
        "hanzi": "便于",
        "pinyin": "biànyú",
        "vi": "thuận tiện cho"
      },
      {
        "hanzi": "既然",
        "pinyin": "jìrán",
        "vi": "đã… thì"
      },
      {
        "hanzi": "谈",
        "pinyin": "tán",
        "vi": "bàn bạc"
      },
      {
        "hanzi": "笔",
        "pinyin": "bǐ",
        "vi": "lượng từ cho khoản tiền; giao dịch"
      },
      {
        "hanzi": "生意",
        "pinyin": "shēngyi",
        "vi": "việc kinh doanh"
      },
      {
        "hanzi": "困难",
        "pinyin": "kùnnan",
        "vi": "khó khăn"
      },
      {
        "hanzi": "优点",
        "pinyin": "yōudiǎn",
        "vi": "ưu điểm"
      },
      {
        "hanzi": "缺点",
        "pinyin": "quēdiǎn",
        "vi": "nhược điểm"
      },
      {
        "hanzi": "实际",
        "pinyin": "shíjì",
        "vi": "thực tế"
      },
      {
        "hanzi": "效果",
        "pinyin": "xiàoguǒ",
        "vi": "hiệu quả"
      },
      {
        "hanzi": "点",
        "pinyin": "diǎn",
        "vi": "điểm"
      },
      {
        "hanzi": "一下",
        "pinyin": "yíxià",
        "vi": "ngay lập tức"
      },
      {
        "hanzi": "份",
        "pinyin": "fèn",
        "vi": "lượng từ cho phần; bản"
      },
      {
        "hanzi": "积累",
        "pinyin": "jīlěi",
        "vi": "tích lũy"
      },
      {
        "hanzi": "使",
        "pinyin": "shǐ",
        "vi": "khiến"
      },
      {
        "hanzi": "进入",
        "pinyin": "jìnrù",
        "vi": "bước vào"
      },
      {
        "hanzi": "社会",
        "pinyin": "shèhuì",
        "vi": "xã hội"
      },
      {
        "hanzi": "管理",
        "pinyin": "guǎnlǐ",
        "vi": "quản lý"
      },
      {
        "hanzi": "基础",
        "pinyin": "jīchǔ",
        "vi": "nền tảng"
      },
      {
        "hanzi": "能力",
        "pinyin": "nénglì",
        "vi": "năng lực"
      },
      {
        "hanzi": "今后",
        "pinyin": "jīnhòu",
        "vi": "sau này"
      }
    ],
    "texts": [
      {
        "id": 1,
        "title": "课文 1",
        "content": "同事：经理，打扰您一下。市场调查的计划书我昨天发到您邮箱了。在内容方面，您觉得有需要改的吗？\n王一雪：我看过了，写得不错，就是调查的地点只有超市，不太够。\n同事：好的，那我再加一些网店。\n王一雪：行。做调查的时候要细心，注意了解客户真正的想法。\n同事：明白了，我会认真准备，按时完成任务。\n王一雪：嗯，如果遇到什么问题，及时跟我联系。",
        "sourcePages": [
          82
        ],
        "targets": [
          "打扰",
          "一下",
          "市场",
          "调查",
          "计划",
          "内容",
          "细心",
          "客户",
          "真正",
          "想法"
        ]
      },
      {
        "id": 2,
        "title": "课文 2",
        "content": "同事：杨哥，经理让我下周去上海出差，做市场调查，你有这方面的经验吗？\n杨同乐：你要去几天？主要调查什么内容？\n同事：去四天，打算采访一些客户，了解他们对新产品的看法。\n杨同乐：那你要提前准备好问题，便于和客户交流。\n同事：好的，我已经准备了一些问题。\n杨同乐：很好。既然出差时间不长，就要安排好时间，多获得有用的信息。",
        "sourcePages": [
          84
        ],
        "targets": [
          "出差",
          "市场",
          "调查",
          "经验",
          "内容",
          "采访",
          "客户",
          "产品",
          "看法",
          "提前"
        ]
      },
      {
        "id": 3,
        "title": "课文 3",
        "content": "前段时间，杨同乐的同事谈成了一笔不错的生意。刚开始，这位同事也遇到了一些困难。拿和客户交流来说，虽然她能把产品的优缺点说得很清楚，但实际效果并不理想。杨同乐告诉她，这是因为她介绍的方式都一样。其实，不同年龄、不同性别的客户对产品的关注点是不一样的。\n于是，这位同事又认真地进行了几次市场调查，了解不同客户的想法。后来她在面对不同客户时，能根据他们的情况介绍产品，效果一下就好了很多。",
        "sourcePages": [
          86
        ],
        "targets": [
          "生意",
          "困难",
          "客户",
          "产品",
          "缺点",
          "实际",
          "效果",
          "市场",
          "调查",
          "想法"
        ]
      },
      {
        "id": 4,
        "title": "课文 4",
        "content": "有的年轻人经常换工作，总觉得下一份工作会更好。但是，适应新工作往往需要比较长的时间。如果总是换工作，不但很难积累经验，还可能会使自己的发展受到影响。\n我认为，年轻人刚进入社会时，不能只关心工资的高低，更要重视学习。比如，学习课本中没有的专业知识，了解公司的管理方式，学会和同事有效交流，等等。只有把这些基础打好，提高工作能力，今后才会有更好的发展机会。",
        "sourcePages": [
          88
        ],
        "targets": [
          "份",
          "积累",
          "经验",
          "使",
          "进入",
          "社会",
          "管理",
          "基础",
          "能力",
          "今后"
        ]
      }
    ],
    "translations": [
      {
        "vi": "Khi khảo sát cần cẩn thận, chú ý tìm hiểu suy nghĩ thực sự của khách hàng.",
        "zh": "做调查的时候要细心，注意了解客户真正的想法。"
      },
      {
        "vi": "Vì thời gian đi công tác không dài nên cần sắp xếp thời gian cho tốt.",
        "zh": "既然出差时间不长，就要安排好时间。"
      },
      {
        "vi": "Nếu luôn đổi việc, không những khó tích lũy kinh nghiệm mà còn có thể ảnh hưởng đến sự phát triển của bản thân.",
        "zh": "如果总是换工作，不但很难积累经验，还可能会使自己的发展受到影响。"
      }
    ]
  },
  {
    "n": 8,
    "title": "该放松时就放松",
    "volume": "上",
    "page": 83,
    "grammar": [
      "不管……，都/也……",
      "……，否则……",
      "跟……相比",
      "有A有B"
    ],
    "words": [
      {
        "hanzi": "紧张",
        "pinyin": "jǐnzhāng",
        "vi": "căng thẳng; khan hiếm"
      },
      {
        "hanzi": "放松",
        "pinyin": "fàngsōng",
        "vi": "thư giãn"
      },
      {
        "hanzi": "呀",
        "pinyin": "ya",
        "vi": "ôi; nhỉ"
      },
      {
        "hanzi": "不管",
        "pinyin": "bùguǎn",
        "vi": "bất kể"
      },
      {
        "hanzi": "郊区",
        "pinyin": "jiāoqū",
        "vi": "ngoại ô"
      },
      {
        "hanzi": "游玩",
        "pinyin": "yóuwán",
        "vi": "đi chơi; tham quan"
      },
      {
        "hanzi": "主意",
        "pinyin": "zhǔyi",
        "vi": "ý kiến; ý tưởng"
      },
      {
        "hanzi": "外出",
        "pinyin": "wàichū",
        "vi": "ra ngoài"
      },
      {
        "hanzi": "戴",
        "pinyin": "dài",
        "vi": "đội; đeo"
      },
      {
        "hanzi": "帽子",
        "pinyin": "màozi",
        "vi": "mũ"
      },
      {
        "hanzi": "项目",
        "pinyin": "xiàngmù",
        "vi": "dự án; hạng mục"
      },
      {
        "hanzi": "加班",
        "pinyin": "jiābān",
        "vi": "làm thêm giờ"
      },
      {
        "hanzi": "熬夜",
        "pinyin": "áoyè",
        "vi": "thức khuya"
      },
      {
        "hanzi": "否则",
        "pinyin": "fǒuzé",
        "vi": "nếu không thì"
      },
      {
        "hanzi": "失去",
        "pinyin": "shīqù",
        "vi": "mất đi"
      },
      {
        "hanzi": "值得",
        "pinyin": "zhíde",
        "vi": "đáng"
      },
      {
        "hanzi": "暂停",
        "pinyin": "zàntíng",
        "vi": "tạm dừng"
      },
      {
        "hanzi": "之后",
        "pinyin": "zhīhòu",
        "vi": "sau đó"
      },
      {
        "hanzi": "风景",
        "pinyin": "fēngjǐng",
        "vi": "phong cảnh"
      },
      {
        "hanzi": "效率",
        "pinyin": "xiàolǜ",
        "vi": "hiệu suất"
      },
      {
        "hanzi": "下降",
        "pinyin": "xiàjiàng",
        "vi": "giảm xuống"
      },
      {
        "hanzi": "相比",
        "pinyin": "xiāngbǐ",
        "vi": "so sánh với"
      },
      {
        "hanzi": "因此",
        "pinyin": "yīncǐ",
        "vi": "do đó"
      },
      {
        "hanzi": "提醒",
        "pinyin": "tíxǐng",
        "vi": "nhắc nhở"
      },
      {
        "hanzi": "与",
        "pinyin": "yǔ",
        "vi": "với; và"
      },
      {
        "hanzi": "大自然",
        "pinyin": "dàzìrán",
        "vi": "thiên nhiên"
      },
      {
        "hanzi": "美丽",
        "pinyin": "měilì",
        "vi": "đẹp"
      },
      {
        "hanzi": "景色",
        "pinyin": "jǐngsè",
        "vi": "cảnh sắc"
      },
      {
        "hanzi": "首都",
        "pinyin": "shǒudū",
        "vi": "thủ đô"
      },
      {
        "hanzi": "市区",
        "pinyin": "shìqū",
        "vi": "khu vực nội thành"
      },
      {
        "hanzi": "眼前",
        "pinyin": "yǎnqián",
        "vi": "trước mắt"
      },
      {
        "hanzi": "美景",
        "pinyin": "měijǐng",
        "vi": "cảnh đẹp"
      },
      {
        "hanzi": "参观",
        "pinyin": "cānguān",
        "vi": "tham quan"
      },
      {
        "hanzi": "景点",
        "pinyin": "jǐngdiǎn",
        "vi": "điểm tham quan"
      },
      {
        "hanzi": "交通",
        "pinyin": "jiāotōng",
        "vi": "giao thông"
      },
      {
        "hanzi": "乘坐",
        "pinyin": "chéngzuò",
        "vi": "đi bằng (phương tiện)"
      },
      {
        "hanzi": "十分",
        "pinyin": "shífēn",
        "vi": "rất"
      },
      {
        "hanzi": "实际上",
        "pinyin": "shíjìshang",
        "vi": "trên thực tế"
      },
      {
        "hanzi": "长城",
        "pinyin": "Chángchéng",
        "vi": "Vạn Lý Trường Thành",
        "properNoun": true
      },
      {
        "hanzi": "故宫",
        "pinyin": "Gùgōng",
        "vi": "Cố Cung",
        "properNoun": true
      }
    ],
    "texts": [
      {
        "id": 1,
        "title": "课文 1",
        "content": "安妮：家月，最近学习太紧张了，咱们明天出去放松放松吧。\n白家月：呀，正好我也想出去呢。咱们去哪儿好呢？\n安妮：不管去哪儿，能放松的地方都行。\n白家月：郊区怎么样？\n安妮：天中说，下周王老师要带咱们去郊区游玩呢。\n白家月：是吗？那咱们明天去爬长城吧，不是说“不到长城非好汉”吗？\n安妮：好主意！不过明天是个大晴天，外出记得戴帽子。",
        "sourcePages": [
          94
        ],
        "targets": [
          "紧张",
          "放松",
          "呀",
          "不管",
          "郊区",
          "游玩",
          "主意",
          "外出",
          "戴",
          "帽子"
        ]
      },
      {
        "id": 2,
        "title": "课文 2",
        "content": "李文：同乐哥，你们平时工作忙吗？\n杨同乐：挺忙的。以前我总觉得年轻时要多学多干，所以参加了公司里的很多项目，经常加班、熬夜，身体也亮起了红灯。\n李文：还是别给自己太大压力，否则，失去健康就不值得了。\n杨同乐：是啊，后来我就不接那么多项目了。我发现暂停下来、好好休息之后，我能把工作做得更快更好。\n李文：对，该工作时就工作，该放松时就要放松。\n杨同乐：是的，现在我周末常来郊区，在好山好水好风景中放松自己。",
        "sourcePages": [
          96
        ],
        "targets": [
          "项目",
          "加班",
          "熬夜",
          "否则",
          "失去",
          "值得",
          "暂停",
          "之后",
          "放松",
          "郊区"
        ]
      },
      {
        "id": 3,
        "title": "课文 3",
        "content": "以前杨同乐总觉得自己年轻，就应该多学多干、积累经验。很多年轻人和他想法一样。但是，由于工作紧张，他们经常加班、熬夜，休息不够，结果工作效率下降，健康也受到了影响。\n现在越来越多的人认识到，跟一直加班相比，休息好了再工作，效率更高。因此，很多人开始做出改变，提醒自己减轻压力、多多放松。比如，杨同乐周末时或者与朋友们去郊区游玩，在大自然美丽的景色中好好放松自己；或者就在家里安安静静地看看书。休息好了，再回去上班时，心情愉快，工作效率也更高。",
        "sourcePages": [
          98
        ],
        "targets": [
          "紧张",
          "加班",
          "熬夜",
          "效率",
          "下降",
          "相比",
          "因此",
          "提醒",
          "放松",
          "大自然"
        ]
      },
      {
        "id": 4,
        "title": "课文 4",
        "content": "一到周末，很多人都喜欢外出游玩。你一般去哪里呢？\n我生活在中国的首都——北京。在北京，周末的时候，有人会在市区公园走走，看看眼前的美景；有人喜欢去参观长城、故宫等有名的景点，放松心情的同时，也能了解历史文化。北京交通很方便，所以我和家人更爱乘坐公交车去郊区，偶尔也会自己开车。郊区有山有水，还有很多农家乐，吃、玩、住都十分方便。\n在我看来，不管去哪里玩，实际上都是为了放松。也可以说，只要能放松，去哪儿都合适。",
        "sourcePages": [
          100
        ],
        "targets": [
          "外出",
          "游玩",
          "首都",
          "市区",
          "眼前",
          "美景",
          "参观",
          "景点",
          "放松",
          "实际上"
        ]
      }
    ],
    "translations": [
      {
        "vi": "Bất kể đi đâu, chỉ cần là nơi có thể thư giãn thì đều được.",
        "zh": "不管去哪儿，能放松的地方都行。"
      },
      {
        "vi": "So với việc liên tục làm thêm giờ, nghỉ ngơi tốt rồi làm việc sẽ có hiệu suất cao hơn.",
        "zh": "跟一直加班相比，休息好了再工作，效率更高。"
      },
      {
        "vi": "Đừng tạo áp lực quá lớn cho bản thân, nếu không mất đi sức khỏe thì không đáng.",
        "zh": "还是别给自己太大压力，否则，失去健康就不值得了。"
      }
    ]
  },
  {
    "n": 9,
    "title": "遇见你，刚刚好",
    "volume": "上",
    "page": 95,
    "grammar": [
      "不……也……",
      "尽管……，但是/可是……",
      "此",
      "从来"
    ],
    "words": [
      {
        "hanzi": "祝",
        "pinyin": "zhù",
        "vi": "chúc"
      },
      {
        "hanzi": "巧克力",
        "pinyin": "qiǎokèlì",
        "vi": "sô-cô-la"
      },
      {
        "hanzi": "感动",
        "pinyin": "gǎndòng",
        "vi": "cảm động"
      },
      {
        "hanzi": "浪漫",
        "pinyin": "làngmàn",
        "vi": "lãng mạn"
      },
      {
        "hanzi": "幽默",
        "pinyin": "yōumò",
        "vi": "hài hước"
      },
      {
        "hanzi": "耐心",
        "pinyin": "nàixīn",
        "vi": "kiên nhẫn"
      },
      {
        "hanzi": "吸引",
        "pinyin": "xīyǐn",
        "vi": "thu hút"
      },
      {
        "hanzi": "当时",
        "pinyin": "dāngshí",
        "vi": "lúc đó"
      },
      {
        "hanzi": "错过",
        "pinyin": "cuòguò",
        "vi": "bỏ lỡ"
      },
      {
        "hanzi": "幸运",
        "pinyin": "xìngyùn",
        "vi": "may mắn"
      },
      {
        "hanzi": "幸福",
        "pinyin": "xìngfú",
        "vi": "hạnh phúc"
      },
      {
        "hanzi": "尽管",
        "pinyin": "jǐnguǎn",
        "vi": "mặc dù"
      },
      {
        "hanzi": "性格",
        "pinyin": "xìnggé",
        "vi": "tính cách"
      },
      {
        "hanzi": "共同",
        "pinyin": "gòngtóng",
        "vi": "chung"
      },
      {
        "hanzi": "责任",
        "pinyin": "zérèn",
        "vi": "trách nhiệm"
      },
      {
        "hanzi": "相互",
        "pinyin": "xiānghù",
        "vi": "lẫn nhau"
      },
      {
        "hanzi": "理解",
        "pinyin": "lǐjiě",
        "vi": "thấu hiểu"
      },
      {
        "hanzi": "支持",
        "pinyin": "zhīchí",
        "vi": "ủng hộ"
      },
      {
        "hanzi": "印象",
        "pinyin": "yìnxiàng",
        "vi": "ấn tượng"
      },
      {
        "hanzi": "实在",
        "pinyin": "shízài",
        "vi": "thật thà; thực sự"
      },
      {
        "hanzi": "阳光",
        "pinyin": "yángguāng",
        "vi": "ánh nắng; vui tươi"
      },
      {
        "hanzi": "负责",
        "pinyin": "fùzé",
        "vi": "chịu trách nhiệm; có trách nhiệm"
      },
      {
        "hanzi": "积极",
        "pinyin": "jījí",
        "vi": "tích cực"
      },
      {
        "hanzi": "此",
        "pinyin": "cǐ",
        "vi": "này; đây"
      },
      {
        "hanzi": "从此",
        "pinyin": "cóngcǐ",
        "vi": "từ đó"
      },
      {
        "hanzi": "产生",
        "pinyin": "chǎnshēng",
        "vi": "nảy sinh"
      },
      {
        "hanzi": "爱情",
        "pinyin": "àiqíng",
        "vi": "tình yêu"
      },
      {
        "hanzi": "间",
        "pinyin": "jiān",
        "vi": "giữa"
      },
      {
        "hanzi": "友情",
        "pinyin": "yǒuqíng",
        "vi": "tình bạn"
      },
      {
        "hanzi": "美好",
        "pinyin": "měihǎo",
        "vi": "tốt đẹp"
      },
      {
        "hanzi": "人生",
        "pinyin": "rénshēng",
        "vi": "cuộc đời"
      },
      {
        "hanzi": "精彩",
        "pinyin": "jīngcǎi",
        "vi": "đặc sắc; tuyệt vời"
      },
      {
        "hanzi": "感情",
        "pinyin": "gǎnqíng",
        "vi": "tình cảm"
      },
      {
        "hanzi": "深",
        "pinyin": "shēn",
        "vi": "sâu"
      },
      {
        "hanzi": "经营",
        "pinyin": "jīngyíng",
        "vi": "kinh doanh; vun đắp"
      },
      {
        "hanzi": "对方",
        "pinyin": "duìfāng",
        "vi": "đối phương"
      },
      {
        "hanzi": "感受",
        "pinyin": "gǎnshòu",
        "vi": "cảm nhận"
      },
      {
        "hanzi": "尤其",
        "pinyin": "yóuqí",
        "vi": "đặc biệt là"
      },
      {
        "hanzi": "日子",
        "pinyin": "rìzi",
        "vi": "ngày tháng; cuộc sống"
      },
      {
        "hanzi": "从来",
        "pinyin": "cónglái",
        "vi": "từ trước đến nay"
      }
    ],
    "texts": [
      {
        "id": 1,
        "title": "课文 1",
        "content": "李文：家月，给你的，祝你生日快乐！\n白家月：啊，好漂亮的花！还有巧克力！你怎么知道我喜欢这个巧克力？\n李文：上次咱们去超市，看你拿起来看了看又放下了，我就记住了。\n白家月：好感动！我不说你也懂我在想什么，你真是细心又浪漫。其实刚认识不久，你的幽默与耐心就很吸引我，不过我当时也只把你当普通朋友。如果你没有一直找我聊天儿，我们可能就错过了。\n李文：我终于遇见了对的人，哪能错过呢？\n白家月：遇见你，我也觉得很幸运。",
        "sourcePages": [
          106
        ],
        "targets": [
          "祝",
          "巧克力",
          "感动",
          "浪漫",
          "幽默",
          "耐心",
          "吸引",
          "当时",
          "错过",
          "幸运"
        ]
      },
      {
        "id": 2,
        "title": "课文 2",
        "content": "王一雪：看到一飞和同乐结婚后这么幸福，我这个介绍人也特别开心。\n刘明：是啊，同乐是你的好朋友，一飞是你妹妹，你都很了解。\n王一雪：嗯，他们尽管性格不同，但是有很多共同爱好。特别是同乐人好，性格也好，很有责任感。\n刘明：是的，一飞也算在对的时间遇到了对的人。后边的路还很长，希望他们能一直相互理解、相互支持。\n王一雪：我了解同乐，更了解一飞，相信他们会一直走下去的。\n刘明：祝他们越来越幸福。",
        "sourcePages": [
          108
        ],
        "targets": [
          "幸福",
          "尽管",
          "性格",
          "共同",
          "责任",
          "间",
          "相互",
          "理解",
          "支持",
          "祝"
        ]
      },
      {
        "id": 3,
        "title": "课文 3",
        "content": "王一雪比杨同乐更早进入公司。杨同乐刚来不久，王一雪对他印象就非常好：人很实在，性格阳光，工作负责，表现积极……后来他们一起出了次差，此次出差，让两人熟悉了起来，从此成了好朋友。一次聊天儿时，王一雪了解到杨同乐还没交女朋友，正好自己的妹妹王一飞也没有男朋友，于是王一雪就把王一飞介绍给了他。\n杨同乐和王一飞认识后，很聊得来，两人之间慢慢产生了爱情，最后成了夫妻。杨同乐说自己很幸运，和王一雪这份同事间的友情，给他带来了美好的爱情。",
        "sourcePages": [
          110
        ],
        "targets": [
          "印象",
          "实在",
          "性格",
          "阳光",
          "负责",
          "积极",
          "从此",
          "产生",
          "爱情",
          "幸运"
        ]
      },
      {
        "id": 4,
        "title": "课文 4",
        "content": "李文在校园里遇见白家月，从此，他们的人生变得更加精彩；王一飞和杨同乐通过王一雪介绍认识后，感情越来越深，最后两人幸福地走到了一起。\n在我看来，遇见爱情的方式并不重要，重要的是在合适的时间遇到合适的人。遇见你，刚刚好。不过美好的遇见只是爱的开始，爱更需要经营。在一段感情中，两个人要多关注对方的感受，尤其是结婚后，更要共同经营好家庭，日子才能越过越好。爱，从来都是相互尊重、理解与支持，不是吗？",
        "sourcePages": [
          112
        ],
        "targets": [
          "从此",
          "人生",
          "精彩",
          "感情",
          "幸福",
          "爱情",
          "美好",
          "经营",
          "对方",
          "感受"
        ]
      }
    ],
    "translations": [
      {
        "vi": "Mặc dù tính cách của họ khác nhau, nhưng họ có nhiều sở thích chung.",
        "zh": "他们尽管性格不同，但是有很多共同爱好。"
      },
      {
        "vi": "Hy vọng họ có thể luôn thấu hiểu và ủng hộ lẫn nhau.",
        "zh": "希望他们能一直相互理解、相互支持。"
      },
      {
        "vi": "Trong một mối quan hệ tình cảm, hai người cần quan tâm nhiều hơn đến cảm nhận của đối phương.",
        "zh": "在一段感情中，两个人要多关注对方的感受。"
      }
    ]
  },
  {
    "n": 10,
    "title": "南方不懂北方的冷",
    "volume": "上",
    "page": 107,
    "grammar": [
      "说什么/怎么（着）也得×",
      "有的是",
      "而",
      "再次"
    ],
    "words": [
      {
        "hanzi": "小伙子",
        "pinyin": "xiǎohuǒzi",
        "vi": "chàng trai trẻ"
      },
      {
        "hanzi": "气温",
        "pinyin": "qìwēn",
        "vi": "nhiệt độ không khí"
      },
      {
        "hanzi": "零下",
        "pinyin": "língxià",
        "vi": "dưới 0 độ"
      },
      {
        "hanzi": "度",
        "pinyin": "dù",
        "vi": "độ"
      },
      {
        "hanzi": "冻",
        "pinyin": "dòng",
        "vi": "lạnh cóng; đông cứng"
      },
      {
        "hanzi": "后悔",
        "pinyin": "hòuhuǐ",
        "vi": "hối hận"
      },
      {
        "hanzi": "就是",
        "pinyin": "jiùshì",
        "vi": "đúng vậy"
      },
      {
        "hanzi": "温度",
        "pinyin": "wēndù",
        "vi": "nhiệt độ"
      },
      {
        "hanzi": "差别",
        "pinyin": "chābié",
        "vi": "sự khác biệt"
      },
      {
        "hanzi": "厚",
        "pinyin": "hòu",
        "vi": "dày"
      },
      {
        "hanzi": "寒假",
        "pinyin": "hánjià",
        "vi": "kỳ nghỉ đông"
      },
      {
        "hanzi": "暖和",
        "pinyin": "nuǎnhuo",
        "vi": "ấm áp"
      },
      {
        "hanzi": "低于",
        "pinyin": "dīyú",
        "vi": "thấp hơn"
      },
      {
        "hanzi": "摄氏度",
        "pinyin": "shèshìdù",
        "vi": "độ C"
      },
      {
        "hanzi": "受不了",
        "pinyin": "shòubuliǎo",
        "vi": "không chịu nổi"
      },
      {
        "hanzi": "举办",
        "pinyin": "jǔbàn",
        "vi": "tổ chức"
      },
      {
        "hanzi": "各种",
        "pinyin": "gèzhǒng",
        "vi": "các loại"
      },
      {
        "hanzi": "植物",
        "pinyin": "zhíwù",
        "vi": "thực vật"
      },
      {
        "hanzi": "公里",
        "pinyin": "gōnglǐ",
        "vi": "ki-lô-mét"
      },
      {
        "hanzi": "气候",
        "pinyin": "qìhòu",
        "vi": "khí hậu"
      },
      {
        "hanzi": "而",
        "pinyin": "ér",
        "vi": "mà; còn"
      },
      {
        "hanzi": "此外",
        "pinyin": "cǐwài",
        "vi": "ngoài ra"
      },
      {
        "hanzi": "方言",
        "pinyin": "fāngyán",
        "vi": "phương ngữ"
      },
      {
        "hanzi": "普通话",
        "pinyin": "pǔtōnghuà",
        "vi": "tiếng Phổ thông"
      },
      {
        "hanzi": "较",
        "pinyin": "jiào",
        "vi": "tương đối; khá"
      },
      {
        "hanzi": "使用",
        "pinyin": "shǐyòng",
        "vi": "sử dụng"
      },
      {
        "hanzi": "引起",
        "pinyin": "yǐnqǐ",
        "vi": "gây ra"
      },
      {
        "hanzi": "误会",
        "pinyin": "wùhuì",
        "vi": "hiểu lầm"
      },
      {
        "hanzi": "亲爱",
        "pinyin": "qīn'ài",
        "vi": "thân yêu"
      },
      {
        "hanzi": "再次",
        "pinyin": "zàicì",
        "vi": "một lần nữa"
      },
      {
        "hanzi": "开展",
        "pinyin": "kāizhǎn",
        "vi": "triển khai"
      },
      {
        "hanzi": "绿色",
        "pinyin": "lǜsè",
        "vi": "xanh; thân thiện môi trường"
      },
      {
        "hanzi": "环保",
        "pinyin": "huánbǎo",
        "vi": "bảo vệ môi trường"
      },
      {
        "hanzi": "拒绝",
        "pinyin": "jùjué",
        "vi": "từ chối"
      },
      {
        "hanzi": "浪费",
        "pinyin": "làngfèi",
        "vi": "lãng phí"
      },
      {
        "hanzi": "节约",
        "pinyin": "jiéyuē",
        "vi": "tiết kiệm"
      },
      {
        "hanzi": "资源",
        "pinyin": "zīyuán",
        "vi": "tài nguyên"
      },
      {
        "hanzi": "光",
        "pinyin": "guāng",
        "vi": "hết sạch"
      },
      {
        "hanzi": "垃圾",
        "pinyin": "lājī",
        "vi": "rác thải"
      },
      {
        "hanzi": "分类",
        "pinyin": "fēnlèi",
        "vi": "phân loại"
      },
      {
        "hanzi": "日常",
        "pinyin": "rìcháng",
        "vi": "hằng ngày"
      },
      {
        "hanzi": "广州",
        "pinyin": "Guǎngzhōu",
        "vi": "Quảng Châu",
        "properNoun": true
      },
      {
        "hanzi": "哈尔滨",
        "pinyin": "Hā'ěrbīn",
        "vi": "Cáp Nhĩ Tân",
        "properNoun": true
      }
    ],
    "texts": [
      {
        "id": 1,
        "title": "课文 1",
        "content": "刘明：你看，这个小伙子从广州去哈尔滨出差，没想到哈尔滨的气温降到了零下二十几度，把他冻坏了。\n王一雪：他一定后悔自己穿少了吧？\n刘明：是啊，这就叫南方不懂北方的冷。\n王一雪：就是呢，冬天北方和南方的温度差别还是很大的。\n刘明：所以冬天来北方，尤其是东北，一定要提前查好目的地的天气，看看下不下雪，气温怎么样。\n王一雪：对。更重要的是，说什么也得穿上厚一点儿的衣服。",
        "sourcePages": [
          118,
          119
        ],
        "targets": [
          "小伙子",
          "气温",
          "零下",
          "度",
          "冻",
          "后悔",
          "就是",
          "温度",
          "差别",
          "厚"
        ]
      },
      {
        "id": 2,
        "title": "课文 2",
        "content": "王一飞：寒假你们打算做什么呢？\n陈天中：我们刚刚还说呢，家月春节时要去广州，我计划去哈尔滨。\n王一飞：那时候广州暖和，但哈尔滨特别冷，气温一般都低于零下十摄氏度甚至零下二十摄氏度，这么低的温度你受不了吧？\n陈天中：没问题，受得了，我有的是厚衣服。我去哈尔滨主要是想看雪，听说春节时那里会举办很多活动。\n白家月：我想在广州过年，那里冬天比较暖和。而且我喜欢看花，听说广州的鲜花市场很有名，里面有各种植物。\n王一飞：真不错！听你们这么一说，我也想外出旅游了。",
        "sourcePages": [
          120,
          121
        ],
        "targets": [
          "寒假",
          "暖和",
          "气温",
          "低于",
          "零下",
          "摄氏度",
          "温度",
          "受不了",
          "举办",
          "各种"
        ]
      },
      {
        "id": 3,
        "title": "课文 3",
        "content": "广州和哈尔滨，一个在南方，一个在北方，两个城市之间的距离有三千多公里，气候也大不相同。广州基本上没有冬天，而哈尔滨的冬天一般会从十月开始，到第二年的三四月才结束。广州四季开满鲜花，所以又叫“花城”；哈尔滨冬天冰雪多，所以也叫“冰城”。\n此外，两地的方言也不一样。哈尔滨方言和普通话听起来比较像，而广州方言和普通话差别较大。如果广州人和哈尔滨人都只使用自己的方言，那么交流就很困难，甚至还可能引起误会。其实，中国很多地方都有自己的方言，所以，为了顺利交流，中国人从小都要学习普通话。",
        "sourcePages": [
          122,
          123
        ],
        "targets": [
          "公里",
          "气候",
          "而",
          "此外",
          "方言",
          "普通话",
          "差别",
          "使用",
          "引起",
          "误会"
        ]
      },
      {
        "id": 4,
        "title": "课文 4",
        "content": "亲爱的同学们：\n今年的“世界环境日”，我们再次开展“绿色生活”活动，希望同学们做到：\n一、绿色出行\n绿色一小步，环保一大步。根据距离选择绿色交通方式。距离短时可以走路或者骑自行车，距离长时多乘坐公交车或者地铁。\n二、拒绝浪费\n节约资源，坚持一水多用、人走灯关、餐餐都“光盘”。\n三、垃圾分类\n积极参加校园、小区环保活动，学习垃圾分类知识，从小事做起，做好垃圾分类。\n保护环境是每一个人的责任。同学们，让我们共同努力，让绿色生活成为我们的日常习惯！\n校学生会\n2026年6月5日",
        "sourcePages": [
          125
        ],
        "targets": [
          "再次",
          "开展",
          "绿色",
          "环保",
          "拒绝",
          "浪费",
          "节约",
          "资源",
          "垃圾",
          "分类"
        ]
      }
    ],
    "translations": [
      {
        "vi": "Mùa đông đến miền Bắc, nhất là vùng Đông Bắc, nhất định phải xem trước thời tiết ở điểm đến.",
        "zh": "冬天来北方，尤其是东北，一定要提前查好目的地的天气。"
      },
      {
        "vi": "Phương ngữ Quảng Châu và tiếng Phổ thông khác biệt khá lớn.",
        "zh": "广州方言和普通话差别较大。"
      },
      {
        "vi": "Bảo vệ môi trường là trách nhiệm của mỗi người.",
        "zh": "保护环境是每一个人的责任。"
      }
    ]
  },
  {
    "n": 11,
    "title": "活到老学到老",
    "volume": "下",
    "page": 1,
    "grammar": [
      "即使……，也……",
      "就是……，也……",
      "不是……，而是……",
      "就是说"
    ],
    "words": [
      {
        "hanzi": "老年",
        "pinyin": "lǎonián",
        "vi": "tuổi già"
      },
      {
        "hanzi": "散步",
        "pinyin": "sànbù",
        "vi": "đi dạo"
      },
      {
        "hanzi": "丰富",
        "pinyin": "fēngfù",
        "vi": "phong phú"
      },
      {
        "hanzi": "羡慕",
        "pinyin": "xiànmù",
        "vi": "ngưỡng mộ"
      },
      {
        "hanzi": "即使",
        "pinyin": "jíshǐ",
        "vi": "cho dù"
      },
      {
        "hanzi": "活",
        "pinyin": "huó",
        "vi": "sống"
      },
      {
        "hanzi": "继续",
        "pinyin": "jìxù",
        "vi": "tiếp tục"
      },
      {
        "hanzi": "网友",
        "pinyin": "wǎngyǒu",
        "vi": "bạn trên mạng"
      },
      {
        "hanzi": "无聊",
        "pinyin": "wúliáo",
        "vi": "nhàm chán"
      },
      {
        "hanzi": "数字",
        "pinyin": "shùzì",
        "vi": "chữ số; kỹ thuật số"
      },
      {
        "hanzi": "点名",
        "pinyin": "diǎnmíng",
        "vi": "điểm danh"
      },
      {
        "hanzi": "教授",
        "pinyin": "jiàoshòu",
        "vi": "giáo sư"
      },
      {
        "hanzi": "线上",
        "pinyin": "xiànshàng",
        "vi": "trực tuyến"
      },
      {
        "hanzi": "线下",
        "pinyin": "xiànxià",
        "vi": "trực tiếp; ngoại tuyến"
      },
      {
        "hanzi": "视频",
        "pinyin": "shìpín",
        "vi": "video"
      },
      {
        "hanzi": "记录",
        "pinyin": "jìlù",
        "vi": "ghi chép; ghi lại"
      },
      {
        "hanzi": "资料",
        "pinyin": "zīliào",
        "vi": "tư liệu"
      },
      {
        "hanzi": "自学",
        "pinyin": "zìxué",
        "vi": "tự học"
      },
      {
        "hanzi": "口语",
        "pinyin": "kǒuyǔ",
        "vi": "khẩu ngữ"
      },
      {
        "hanzi": "科技",
        "pinyin": "kējì",
        "vi": "khoa học công nghệ"
      },
      {
        "hanzi": "获取",
        "pinyin": "huòqǔ",
        "vi": "thu nhận"
      },
      {
        "hanzi": "礼貌",
        "pinyin": "lǐmào",
        "vi": "lễ phép; lịch sự"
      },
      {
        "hanzi": "打招呼",
        "pinyin": "dǎ zhāohu",
        "vi": "chào hỏi"
      },
      {
        "hanzi": "家长",
        "pinyin": "jiāzhǎng",
        "vi": "phụ huynh"
      },
      {
        "hanzi": "成功",
        "pinyin": "chénggōng",
        "vi": "thành công"
      },
      {
        "hanzi": "分数",
        "pinyin": "fēnshù",
        "vi": "điểm số"
      },
      {
        "hanzi": "目的",
        "pinyin": "mùdì",
        "vi": "mục đích"
      },
      {
        "hanzi": "养成",
        "pinyin": "yǎngchéng",
        "vi": "hình thành; tạo thành thói quen"
      },
      {
        "hanzi": "留",
        "pinyin": "liú",
        "vi": "để lại; dành lại"
      },
      {
        "hanzi": "做法",
        "pinyin": "zuòfǎ",
        "vi": "cách làm"
      },
      {
        "hanzi": "棒",
        "pinyin": "bàng",
        "vi": "tuyệt vời"
      },
      {
        "hanzi": "一生",
        "pinyin": "yìshēng",
        "vi": "cả đời"
      },
      {
        "hanzi": "快速",
        "pinyin": "kuàisù",
        "vi": "nhanh chóng"
      },
      {
        "hanzi": "优秀",
        "pinyin": "yōuxiù",
        "vi": "xuất sắc"
      },
      {
        "hanzi": "律师",
        "pinyin": "lǜshī",
        "vi": "luật sư"
      },
      {
        "hanzi": "仍",
        "pinyin": "réng",
        "vi": "vẫn"
      },
      {
        "hanzi": "准时",
        "pinyin": "zhǔnshí",
        "vi": "đúng giờ"
      },
      {
        "hanzi": "网页",
        "pinyin": "wǎngyè",
        "vi": "trang web"
      },
      {
        "hanzi": "弹",
        "pinyin": "tán",
        "vi": "chơi (nhạc cụ)"
      },
      {
        "hanzi": "钢琴",
        "pinyin": "gāngqín",
        "vi": "đàn piano"
      },
      {
        "hanzi": "重新",
        "pinyin": "chóngxīn",
        "vi": "lại; làm lại"
      },
      {
        "hanzi": "太极拳",
        "pinyin": "Tàijíquán",
        "vi": "Thái Cực quyền",
        "properNoun": true
      },
      {
        "hanzi": "孔子",
        "pinyin": "Kǒngzǐ",
        "vi": "Khổng Tử",
        "properNoun": true
      }
    ],
    "texts": [
      {
        "id": 1,
        "title": "课文 1",
        "content": "白家月：这里的老年人真不少。\n李文：嗯，住在附近的老年人都会来这儿，有的散步，有的唱歌、跳舞，还有的打太极拳。\n白家月：他们的生活真丰富，让人羡慕。\n李文：是的。有些人即使年龄大了，也坚持去老年班学习。\n白家月：真是活到老学到老啊。\n李文：对，我爷爷就每周都去老年班学电脑。他总说，老年人也要继续学习，“你看，我都七八十岁了，还上网和网友们聊天儿呢，生活一点儿都不无聊。”",
        "sourcePages": [
          6
        ],
        "targets": [
          "老年",
          "散步",
          "活",
          "丰富",
          "羡慕",
          "即使",
          "继续",
          "网友",
          "无聊"
        ]
      },
      {
        "id": 2,
        "title": "课文 2",
        "content": "安妮：家月，我们今天的课是在数字教室上的，感觉挺不一样的。\n白家月：是的，数字教室可以拍照点名，教授在线上点名，不用像线下那样一个个叫名字，特别节约时间。\n李文：最方便的是，课上没听明白时，课后还能在学校网站上找到视频记录看。\n安妮：对，上课我都不用着急记笔记了。\n李文：不仅数字教室很方便，现在网上到处是学习资料，想查什么都能查到，自学也更方便了。\n白家月：是的，只要有手机或电脑，我就是不在教室，也可以学习中文，和同学一起练口语。\n安妮：科技真是让获取知识变得简单多了。",
        "sourcePages": [
          8,
          9
        ],
        "targets": [
          "数字",
          "点名",
          "教授",
          "线上",
          "线下",
          "视频",
          "记录",
          "资料",
          "自学",
          "口语"
        ]
      },
      {
        "id": 3,
        "title": "课文 3",
        "content": "今天星期六，我们去了一雪姐姐家。姐姐家的两个孩子很有礼貌，我们一进门，就马上和我们打招呼。\n在姐姐家，我们也聊到了孩子的教育。姐姐说，以前他们和很多家长一样，觉得孩子上个好大学，人生才是成功的。所以，他们只关心孩子的分数，结果孩子压力特别大，每天都很不开心。后来，他们认识到，教育的目的不是让孩子考高分，而是帮助孩子养成好习惯。于是，他们做出改变，每天都给孩子留出时间外出锻炼身体，或者看些自己感兴趣的书。\n我觉得他们的做法真棒。",
        "sourcePages": [
          10,
          11
        ],
        "targets": [
          "礼貌",
          "打招呼",
          "家长",
          "成功",
          "分数",
          "目的",
          "养成",
          "留",
          "做法",
          "棒"
        ]
      },
      {
        "id": 4,
        "title": "课文 4",
        "content": "“学而不厌”是两千多年前中国教育家孔子说过的话，意思是人要一直坚持学习，就是说，学习是人一生的事情，要活到老学到老。在世界快速变化的今天，“学而不厌”变得更加重要。\n我有一位很优秀的律师朋友，他一直在学习新的法律知识。他说，这不仅是律师的要求和责任，也是提高自己能力的重要方法。\n同时我也认为，人就是不再工作了，坚持学习仍很重要。就像我爷爷，虽然七十多岁了，每天还准时去老年大学上课，学习做网页、弹钢琴。他说，重新当一回学生，生活更有意思了，也感觉自己更年轻了。",
        "sourcePages": [
          12,
          13
        ],
        "targets": [
          "一生",
          "活",
          "快速",
          "优秀",
          "律师",
          "准时",
          "老年",
          "网页",
          "钢琴",
          "重新"
        ]
      }
    ],
    "translations": [
      {
        "vi": "Mục đích của giáo dục không phải là để trẻ đạt điểm cao mà là giúp trẻ hình thành thói quen tốt.",
        "zh": "教育的目的不是让孩子考高分，而是帮助孩子养成好习惯。"
      },
      {
        "vi": "Có những người cho dù tuổi đã cao vẫn kiên trì đến lớp dành cho người cao tuổi để học.",
        "zh": "有些人即使年龄大了，也坚持去老年班学习。"
      },
      {
        "vi": "Khoa học công nghệ thực sự làm cho việc thu nhận kiến thức trở nên đơn giản hơn nhiều.",
        "zh": "科技真是让获取知识变得简单多了。"
      }
    ]
  },
  {
    "n": 12,
    "title": "幸福的家庭",
    "volume": "下",
    "page": 13,
    "grammar": [
      "不怎么",
      "双重否定",
      "无论……，都/也……",
      "为了……而……"
    ],
    "words": [
      {
        "hanzi": "毛衣",
        "pinyin": "máoyī",
        "vi": "áo len"
      },
      {
        "hanzi": "样子",
        "pinyin": "yàngzi",
        "vi": "kiểu dáng; dáng vẻ"
      },
      {
        "hanzi": "适合",
        "pinyin": "shìhé",
        "vi": "phù hợp"
      },
      {
        "hanzi": "售货员",
        "pinyin": "shòuhuòyuán",
        "vi": "nhân viên bán hàng"
      },
      {
        "hanzi": "质量",
        "pinyin": "zhìliàng",
        "vi": "chất lượng"
      },
      {
        "hanzi": "强",
        "pinyin": "qiáng",
        "vi": "mạnh; hơn"
      },
      {
        "hanzi": "年底",
        "pinyin": "niándǐ",
        "vi": "cuối năm"
      },
      {
        "hanzi": "全",
        "pinyin": "quán",
        "vi": "toàn bộ"
      },
      {
        "hanzi": "打折",
        "pinyin": "dǎzhé",
        "vi": "giảm giá"
      },
      {
        "hanzi": "值",
        "pinyin": "zhí",
        "vi": "đáng giá"
      },
      {
        "hanzi": "估计",
        "pinyin": "gūjì",
        "vi": "ước chừng; đoán"
      },
      {
        "hanzi": "期",
        "pinyin": "qī",
        "vi": "kỳ; đợt"
      },
      {
        "hanzi": "听力",
        "pinyin": "tīnglì",
        "vi": "thính lực"
      },
      {
        "hanzi": "烦",
        "pinyin": "fán",
        "vi": "phiền; bực"
      },
      {
        "hanzi": "脱",
        "pinyin": "tuō",
        "vi": "cởi"
      },
      {
        "hanzi": "挂",
        "pinyin": "guà",
        "vi": "treo"
      },
      {
        "hanzi": "脾气",
        "pinyin": "píqi",
        "vi": "tính khí"
      },
      {
        "hanzi": "伤心",
        "pinyin": "shāngxīn",
        "vi": "đau lòng"
      },
      {
        "hanzi": "批评",
        "pinyin": "pīpíng",
        "vi": "phê bình"
      },
      {
        "hanzi": "道歉",
        "pinyin": "dàoqiàn",
        "vi": "xin lỗi"
      },
      {
        "hanzi": "老家",
        "pinyin": "lǎojiā",
        "vi": "quê nhà"
      },
      {
        "hanzi": "自",
        "pinyin": "zì",
        "vi": "từ"
      },
      {
        "hanzi": "父母",
        "pinyin": "fùmǔ",
        "vi": "bố mẹ"
      },
      {
        "hanzi": "父子",
        "pinyin": "fùzǐ",
        "vi": "cha con"
      },
      {
        "hanzi": "母子",
        "pinyin": "mǔzǐ",
        "vi": "mẹ con"
      },
      {
        "hanzi": "无论",
        "pinyin": "wúlùn",
        "vi": "bất kể"
      },
      {
        "hanzi": "条件",
        "pinyin": "tiáojiàn",
        "vi": "điều kiện"
      },
      {
        "hanzi": "允许",
        "pinyin": "yǔnxǔ",
        "vi": "cho phép"
      },
      {
        "hanzi": "另外",
        "pinyin": "lìngwài",
        "vi": "ngoài ra"
      },
      {
        "hanzi": "卫生",
        "pinyin": "wèishēng",
        "vi": "vệ sinh"
      },
      {
        "hanzi": "母亲",
        "pinyin": "mǔqīn",
        "vi": "mẹ"
      },
      {
        "hanzi": "待",
        "pinyin": "dāi",
        "vi": "ở lại"
      },
      {
        "hanzi": "将",
        "pinyin": "jiāng",
        "vi": "đem; dùng như 把"
      },
      {
        "hanzi": "闻",
        "pinyin": "wén",
        "vi": "ngửi"
      },
      {
        "hanzi": "味道",
        "pinyin": "wèidao",
        "vi": "mùi; vị"
      },
      {
        "hanzi": "冷静",
        "pinyin": "lěngjìng",
        "vi": "bình tĩnh"
      },
      {
        "hanzi": "鼻子",
        "pinyin": "bízi",
        "vi": "mũi"
      },
      {
        "hanzi": "父亲",
        "pinyin": "fùqīn",
        "vi": "cha"
      },
      {
        "hanzi": "城",
        "pinyin": "chéng",
        "vi": "thành phố"
      },
      {
        "hanzi": "鲜",
        "pinyin": "xiān",
        "vi": "tươi; ngon"
      },
      {
        "hanzi": "暖",
        "pinyin": "nuǎn",
        "vi": "ấm"
      },
      {
        "hanzi": "勇敢",
        "pinyin": "yǒnggǎn",
        "vi": "dũng cảm"
      },
      {
        "hanzi": "商量",
        "pinyin": "shāngliang",
        "vi": "bàn bạc"
      }
    ],
    "texts": [
      {
        "id": 1,
        "title": "课文 1",
        "content": "王一飞：你觉得老妈穿这件毛衣怎么样？\n杨同乐：样子不错，就是颜色好像不怎么适合她。\n售货员：老年人穿这种颜色的衣服正合适，颜色不深，质量还特别好。您看那位阿姨正试着呢，是不是很好看？\n王一飞：嗯，是挺不错的。同乐，我印象中，老妈也常穿这种颜色的衣服，她应该会喜欢的，买一件吧。\n杨同乐：好的，老妈高兴比什么都强。\n售货员：就是，老人开心最重要。我们店正好年底有活动，全场打七折呢，挺值的。",
        "sourcePages": [
          18
        ],
        "targets": [
          "毛衣",
          "样子",
          "适合",
          "质量",
          "强",
          "年底",
          "全",
          "值"
        ]
      },
      {
        "id": 2,
        "title": "课文 2",
        "content": "刘明：爷爷、奶奶还没回来呢？\n王一雪：没呢，估计快了。下午老年班举办一期听力保护活动，他们去参加活动了。\n刘明：他们的活动还挺丰富的！\n王一雪：嗯。小明最近要考试，心里有点儿烦，昨天因为脱、挂衣服这点儿小事，就对奶奶发脾气了。\n刘明：是吗？他这样做老人该伤心了。\n王一雪：就是啊。他也不是不知道自己错了，我批评他以后，他马上说放学回来就向奶奶道歉。\n刘明：好的，我也再跟他聊聊。\n王一雪：那就更好了。",
        "sourcePages": [
          20,
          21
        ],
        "targets": [
          "估计",
          "期",
          "听力",
          "烦",
          "脱",
          "挂",
          "脾气",
          "伤心",
          "批评",
          "道歉"
        ]
      },
      {
        "id": 3,
        "title": "课文 3",
        "content": "杨同乐的老家在上海，他自毕业后一直在北京工作。虽然没和父母生活在一起，但父子、母子关系特别好。杨同乐很关心父母，无论平时工作有多忙，他每个周末都会给父母打电话。条件允许时，他会回上海看父母。\n刘明和王一雪结婚后，一直没有和父母生活在一起，他们平时会另外找时间去看父母，帮父母做做饭，打扫打扫卫生。这两年，刘明的母亲身体不太好，他们很担心，就把父母接到了自己家里照顾。父母待在他们身边，他们也终于能放心地去工作了。",
        "sourcePages": [
          22,
          23
        ],
        "targets": [
          "老家",
          "父母",
          "父子",
          "母子",
          "无论",
          "条件",
          "允许",
          "另外",
          "卫生",
          "母亲"
        ]
      },
      {
        "id": 4,
        "title": "课文 4",
        "content": "下班回家，林静静将父母从老家寄来的鸡汤热了热，当闻到从小就熟悉的味道时，平时冷静的她鼻子还是酸了。\n林静静一个人来北京工作三年了，父母总是担心她为了节约时间而不好好吃饭，所以每个月都给她寄各种好吃的。这次母亲专门做了林静静最爱喝的鸡汤，为了让食物新鲜，父亲选择了城里最快的快递，上午寄出，下午就能收到。\n鸡汤很鲜，林静静心里更暖，她觉得父母好像就在身边。都说“儿行千里母担忧”，父母总对她说：“遇到困难别害怕，要勇敢面对，任何时候都可以和父母商量。”尽管在大城市生活压力有些大，但每当想到父母的这些话，尝到来自老家熟悉的味道，她就觉得又能笑着面对生活了。",
        "sourcePages": [
          24,
          25
        ],
        "targets": [
          "将",
          "父母",
          "老家",
          "味道",
          "冷静",
          "鼻子",
          "母亲",
          "父亲",
          "勇敢",
          "商量"
        ]
      }
    ],
    "translations": [
      {
        "vi": "Bất kể công việc bận đến đâu, cuối tuần anh ấy đều gọi điện cho bố mẹ.",
        "zh": "无论平时工作有多忙，他每个周末都会给父母打电话。"
      },
      {
        "vi": "Mẹ vui thì hơn bất cứ điều gì.",
        "zh": "老妈高兴比什么都强。"
      },
      {
        "vi": "Gặp khó khăn đừng sợ, hãy dũng cảm đối mặt, bất cứ lúc nào cũng có thể bàn bạc với bố mẹ.",
        "zh": "遇到困难别害怕，要勇敢面对，任何时候都可以和父母商量。"
      }
    ]
  },
  {
    "n": 13,
    "title": "美好的日子",
    "volume": "下",
    "page": 25,
    "grammar": [
      "怎么都/也＋不/没……",
      "一＋量词＋比＋一＋量词",
      "大约、左右",
      "作为"
    ],
    "words": [
      {
        "hanzi": "熊",
        "pinyin": "xióng",
        "vi": "gấu"
      },
      {
        "hanzi": "老虎",
        "pinyin": "lǎohǔ",
        "vi": "hổ"
      },
      {
        "hanzi": "喊",
        "pinyin": "hǎn",
        "vi": "hét; gọi"
      },
      {
        "hanzi": "级",
        "pinyin": "jí",
        "vi": "cấp; bậc"
      },
      {
        "hanzi": "树林",
        "pinyin": "shùlín",
        "vi": "rừng cây"
      },
      {
        "hanzi": "景区",
        "pinyin": "jǐngqū",
        "vi": "khu thắng cảnh"
      },
      {
        "hanzi": "区",
        "pinyin": "qū",
        "vi": "khu vực"
      },
      {
        "hanzi": "美",
        "pinyin": "měi",
        "vi": "đẹp"
      },
      {
        "hanzi": "节假日",
        "pinyin": "jiéjiàrì",
        "vi": "ngày lễ và ngày nghỉ"
      },
      {
        "hanzi": "千万",
        "pinyin": "qiānwàn",
        "vi": "nhất định; tuyệt đối"
      },
      {
        "hanzi": "开玩笑",
        "pinyin": "kāi wánxiào",
        "vi": "đùa"
      },
      {
        "hanzi": "月饼",
        "pinyin": "yuèbing",
        "vi": "bánh trung thu"
      },
      {
        "hanzi": "葡萄",
        "pinyin": "pútao",
        "vi": "nho"
      },
      {
        "hanzi": "香",
        "pinyin": "xiāng",
        "vi": "thơm"
      },
      {
        "hanzi": "街道",
        "pinyin": "jiēdào",
        "vi": "đường phố"
      },
      {
        "hanzi": "剧院",
        "pinyin": "jùyuàn",
        "vi": "nhà hát"
      },
      {
        "hanzi": "演出",
        "pinyin": "yǎnchū",
        "vi": "biểu diễn"
      },
      {
        "hanzi": "赶",
        "pinyin": "gǎn",
        "vi": "trùng vào; kịp"
      },
      {
        "hanzi": "巧",
        "pinyin": "qiǎo",
        "vi": "trùng hợp; khéo"
      },
      {
        "hanzi": "之中",
        "pinyin": "zhīzhōng",
        "vi": "trong số"
      },
      {
        "hanzi": "铁路",
        "pinyin": "tiělù",
        "vi": "đường sắt"
      },
      {
        "hanzi": "人员",
        "pinyin": "rényuán",
        "vi": "nhân viên; nhân sự"
      },
      {
        "hanzi": "反向",
        "pinyin": "fǎnxiàng",
        "vi": "hướng ngược lại"
      },
      {
        "hanzi": "团圆",
        "pinyin": "tuányuán",
        "vi": "đoàn tụ"
      },
      {
        "hanzi": "左右",
        "pinyin": "zuǒyòu",
        "vi": "khoảng; xấp xỉ"
      },
      {
        "hanzi": "大约",
        "pinyin": "dàyuē",
        "vi": "khoảng"
      },
      {
        "hanzi": "烤",
        "pinyin": "kǎo",
        "vi": "nướng"
      },
      {
        "hanzi": "西红柿",
        "pinyin": "xīhóngshì",
        "vi": "cà chua"
      },
      {
        "hanzi": "出现",
        "pinyin": "chūxiàn",
        "vi": "xuất hiện"
      },
      {
        "hanzi": "作为",
        "pinyin": "zuòwéi",
        "vi": "với tư cách là"
      },
      {
        "hanzi": "传统",
        "pinyin": "chuántǒng",
        "vi": "truyền thống"
      },
      {
        "hanzi": "有着",
        "pinyin": "yǒuzhe",
        "vi": "có; sở hữu"
      },
      {
        "hanzi": "意义",
        "pinyin": "yìyì",
        "vi": "ý nghĩa"
      },
      {
        "hanzi": "到来",
        "pinyin": "dàolái",
        "vi": "đến"
      },
      {
        "hanzi": "美食",
        "pinyin": "měishí",
        "vi": "món ăn ngon"
      },
      {
        "hanzi": "年夜饭",
        "pinyin": "niányèfàn",
        "vi": "bữa cơm tất niên"
      },
      {
        "hanzi": "回忆",
        "pinyin": "huíyì",
        "vi": "hồi tưởng"
      },
      {
        "hanzi": "童年",
        "pinyin": "tóngnián",
        "vi": "tuổi thơ"
      },
      {
        "hanzi": "记忆",
        "pinyin": "jìyì",
        "vi": "ký ức"
      },
      {
        "hanzi": "已",
        "pinyin": "yǐ",
        "vi": "đã"
      },
      {
        "hanzi": "中年",
        "pinyin": "zhōngnián",
        "vi": "trung niên"
      },
      {
        "hanzi": "仍然",
        "pinyin": "réngrán",
        "vi": "vẫn"
      },
      {
        "hanzi": "兄弟",
        "pinyin": "xiōngdì",
        "vi": "anh em trai"
      },
      {
        "hanzi": "东北虎",
        "pinyin": "Dōngběihǔ",
        "vi": "hổ Siberia",
        "properNoun": true
      },
      {
        "hanzi": "北京野生动物园",
        "pinyin": "Běijīng Yěshēng Dòngwùyuán",
        "vi": "Công viên động vật hoang dã Bắc Kinh",
        "properNoun": true
      },
      {
        "hanzi": "中秋节",
        "pinyin": "Zhōngqiūjié",
        "vi": "Tết Trung thu",
        "properNoun": true
      },
      {
        "hanzi": "加拿大",
        "pinyin": "Jiānádà",
        "vi": "Canada",
        "properNoun": true
      },
      {
        "hanzi": "元宵节",
        "pinyin": "Yuánxiāojié",
        "vi": "Tết Nguyên tiêu",
        "properNoun": true
      },
      {
        "hanzi": "端午节",
        "pinyin": "Duānwǔjié",
        "vi": "Tết Đoan ngọ",
        "properNoun": true
      },
      {
        "hanzi": "除夕",
        "pinyin": "Chúxī",
        "vi": "đêm giao thừa",
        "properNoun": true
      },
      {
        "hanzi": "春晚",
        "pinyin": "Chūnwǎn",
        "vi": "chương trình Gala Xuân",
        "properNoun": true
      }
    ],
    "texts": [
      {
        "id": 1,
        "title": "课文 1",
        "content": "刘小明：爸爸、妈妈，快看，熊和老虎都在这儿呢！\n王一雪：小明，注意安全，不要一直大喊！\n刘明：你们看，那个叫东北虎，是国家一级保护动物。那边树林里还有很多动物呢。\n刘小明：咱们都能看到吧？\n王一雪：对。景区的车每到一个动物区都会停一会儿，让人们能近距离看看这些动物。\n刘明：真不错，这景区真大、真美！我知道北京野生动物园很大，可怎么也没想到这么大！\n王一雪：这里有几千只动物呢，能不大吗？现在是节假日，人多。小明，一会儿千万别跑丢了，我可不是开玩笑呢。",
        "sourcePages": [
          30,
          31
        ],
        "targets": [
          "熊",
          "老虎",
          "喊",
          "级",
          "树林",
          "景区",
          "美",
          "节假日",
          "千万",
          "开玩笑"
        ]
      },
      {
        "id": 2,
        "title": "课文 2",
        "content": "王一飞：来，大家快吃月饼，这儿还有葡萄、西瓜。\n杨同乐：这是今年的新茶，你们也尝尝。\n陈天中：好的。这茶闻着真香！\n白家月：我还是第一次在中国过中秋节呢。\n安妮：我在加拿大时和中国朋友一起过过中秋节。我记得那天，外面的街道、剧院有很多演出活动。\n王一飞：在中国，每年中秋节都会举办很多活动，而且这几年一年比一年热闹。对了，家月，今天是李文爷爷的生日，李文来不了了，你就多吃一块月饼吧。\n白家月：谢谢，那我就不客气了。\n杨同乐：中秋节和生日赶在了一块儿，真巧、真好！中秋节多陪陪家人也是应该的。",
        "sourcePages": [
          33
        ],
        "targets": [
          "月饼",
          "葡萄",
          "香",
          "街道",
          "剧院",
          "演出",
          "赶",
          "巧"
        ]
      },
      {
        "id": 3,
        "title": "课文 3",
        "content": "中秋节时中国人一般都会回家过节。但是有些人由于工作需要，不能回家，只能一个人留在工作的地方过节。周力就是这些人之中的一位。他是一名铁路工作人员，今年中秋假期，要负责铁路安全检查。\n周力的父母知道儿子这次不能回家后，就决定来一次“反向团圆”。早上五点左右他们就坐上了高铁，大约七点就来到了儿子工作的城市。在儿子家，他们做了一桌儿子爱吃的饭菜，有烤肉、烤鱼、饺子等等，还有西红柿鸡蛋汤。周力下班回家，看到一桌子饭菜和突然出现的父母，他感觉特别幸福。\n这个中秋节，地点变了，但爱没变。",
        "sourcePages": [
          35
        ],
        "targets": [
          "之中",
          "铁路",
          "人员",
          "反向",
          "团圆",
          "左右",
          "大约",
          "烤",
          "西红柿",
          "出现"
        ]
      },
      {
        "id": 4,
        "title": "课文 4",
        "content": "中国有很多节日，比如春节、元宵节、端午节、中秋节等。\n作为一年里最重要的传统节日，春节对中国人来说有着特别的意义。春节到来时，人们不管在哪里，都想回家过年。春节前也最忙，既要收拾房子、打扫卫生，又要准备各种美食。除夕这天晚上，一家人一边吃年夜饭，一边看春晚。零点一到，大家互祝新年快乐，到处都是幸福的笑声。\n每当回忆起童年，我最美好的记忆很多也发生在过年时。虽然现在已人到中年，离开了家，但是春节仍然是我最喜欢的节日，过年时也更想父母、兄弟姐妹。",
        "sourcePages": [
          37,
          38
        ],
        "targets": [
          "作为",
          "传统",
          "有着",
          "意义",
          "到来",
          "美食",
          "年夜饭",
          "回忆",
          "童年",
          "记忆"
        ]
      }
    ],
    "translations": [
      {
        "vi": "Hôm nay là ngày lễ, rất đông người, tuyệt đối đừng chạy lạc nhé.",
        "zh": "现在是节假日，人多，一会儿千万别跑丢了。"
      },
      {
        "vi": "Mỗi năm Trung thu đều tổ chức rất nhiều hoạt động, hơn nữa mấy năm nay năm sau náo nhiệt hơn năm trước.",
        "zh": "每年中秋节都会举办很多活动，而且这几年一年比一年热闹。"
      },
      {
        "vi": "Là ngày lễ truyền thống quan trọng nhất trong năm, Tết có ý nghĩa đặc biệt đối với người Trung Quốc.",
        "zh": "作为一年里最重要的传统节日，春节对中国人来说有着特别的意义。"
      }
    ]
  },
  {
    "n": 14,
    "title": "合适才买",
    "volume": "下",
    "page": 38,
    "grammar": [
      "究竟",
      "首先……，然后/其次……",
      "加上",
      "对于"
    ],
    "words": [
      {
        "hanzi": "茶叶",
        "pinyin": "cháyè",
        "vi": "lá trà"
      },
      {
        "hanzi": "究竟",
        "pinyin": "jiūjìng",
        "vi": "rốt cuộc"
      },
      {
        "hanzi": "分为",
        "pinyin": "fēnwéi",
        "vi": "chia thành"
      },
      {
        "hanzi": "抱歉",
        "pinyin": "bàoqiàn",
        "vi": "xin lỗi"
      },
      {
        "hanzi": "暂时",
        "pinyin": "zànshí",
        "vi": "tạm thời"
      },
      {
        "hanzi": "满",
        "pinyin": "mǎn",
        "vi": "đầy; đạt mức"
      },
      {
        "hanzi": "两",
        "pinyin": "liǎng",
        "vi": "lạng (50 g tại Trung Quốc)"
      },
      {
        "hanzi": "超过",
        "pinyin": "chāoguò",
        "vi": "vượt quá"
      },
      {
        "hanzi": "盒子",
        "pinyin": "hézi",
        "vi": "hộp"
      },
      {
        "hanzi": "装",
        "pinyin": "zhuāng",
        "vi": "đựng; lắp"
      },
      {
        "hanzi": "各位",
        "pinyin": "gèwèi",
        "vi": "quý vị"
      },
      {
        "hanzi": "顾客",
        "pinyin": "gùkè",
        "vi": "khách hàng"
      },
      {
        "hanzi": "本",
        "pinyin": "běn",
        "vi": "của mình; này"
      },
      {
        "hanzi": "假日",
        "pinyin": "jiàrì",
        "vi": "ngày nghỉ"
      },
      {
        "hanzi": "低价",
        "pinyin": "dījià",
        "vi": "giá thấp"
      },
      {
        "hanzi": "促销",
        "pinyin": "cùxiāo",
        "vi": "khuyến mãi"
      },
      {
        "hanzi": "广播",
        "pinyin": "guǎngbō",
        "vi": "phát thanh"
      },
      {
        "hanzi": "减",
        "pinyin": "jiǎn",
        "vi": "giảm"
      },
      {
        "hanzi": "广告",
        "pinyin": "guǎnggào",
        "vi": "quảng cáo"
      },
      {
        "hanzi": "首先",
        "pinyin": "shǒuxiān",
        "vi": "trước tiên"
      },
      {
        "hanzi": "牌子",
        "pinyin": "páizi",
        "vi": "nhãn hiệu"
      },
      {
        "hanzi": "降价",
        "pinyin": "jiàngjià",
        "vi": "giảm giá"
      },
      {
        "hanzi": "样式",
        "pinyin": "yàngshì",
        "vi": "kiểu dáng"
      },
      {
        "hanzi": "价钱",
        "pinyin": "jiàqian",
        "vi": "giá tiền"
      },
      {
        "hanzi": "商业",
        "pinyin": "shāngyè",
        "vi": "thương mại"
      },
      {
        "hanzi": "商品",
        "pinyin": "shāngpǐn",
        "vi": "hàng hóa"
      },
      {
        "hanzi": "种类",
        "pinyin": "zhǒnglèi",
        "vi": "chủng loại"
      },
      {
        "hanzi": "盲盒",
        "pinyin": "mánghé",
        "vi": "hộp quà bí ẩn"
      },
      {
        "hanzi": "缺",
        "pinyin": "quē",
        "vi": "thiếu"
      },
      {
        "hanzi": "许多",
        "pinyin": "xǔduō",
        "vi": "nhiều"
      },
      {
        "hanzi": "表示",
        "pinyin": "biǎoshì",
        "vi": "bày tỏ; biểu thị"
      },
      {
        "hanzi": "加上",
        "pinyin": "jiāshang",
        "vi": "cộng thêm; hơn nữa"
      },
      {
        "hanzi": "态度",
        "pinyin": "tàidu",
        "vi": "thái độ"
      },
      {
        "hanzi": "友好",
        "pinyin": "yǒuhǎo",
        "vi": "thân thiện"
      },
      {
        "hanzi": "使得",
        "pinyin": "shǐde",
        "vi": "khiến cho"
      },
      {
        "hanzi": "者",
        "pinyin": "zhě",
        "vi": "người (hậu tố)"
      },
      {
        "hanzi": "仔细",
        "pinyin": "zǐxì",
        "vi": "kỹ lưỡng"
      },
      {
        "hanzi": "对于",
        "pinyin": "duìyú",
        "vi": "đối với"
      },
      {
        "hanzi": "不光",
        "pinyin": "bùguāng",
        "vi": "không chỉ"
      },
      {
        "hanzi": "外套",
        "pinyin": "wàitào",
        "vi": "áo khoác"
      },
      {
        "hanzi": "袜子",
        "pinyin": "wàzi",
        "vi": "tất; vớ"
      }
    ],
    "texts": [
      {
        "id": 1,
        "title": "课文 1",
        "content": "售货员：您要什么茶？\n安妮：我先看看。这里茶叶这么多，究竟买哪种好呢？\n售货员：茶叶主要分为红茶、绿茶等，看您喜欢喝哪种。\n安妮：我想买一些自己喝，再买些送人。这种绿茶还有吗？\n售货员：抱歉，暂时没有。如果自己喝，可以买这个绿茶，今天满二两送半两，超过半斤再送小礼物；如果送人，可以买个盒子装进去。\n安妮：嗯，那就先买六两这种绿茶吧，再买一个盒子。请帮我分着装，盒子里装半斤，剩下的用纸包一下就行。",
        "sourcePages": [
          43
        ],
        "targets": [
          "茶叶",
          "究竟",
          "分为",
          "抱歉",
          "暂时",
          "满",
          "两",
          "超过",
          "盒子",
          "装"
        ]
      },
      {
        "id": 2,
        "title": "课文 2",
        "content": "广播员：各位顾客，本商场正在举办运动鞋假日低价促销活动，全场五折。\n王一雪：一飞，广播里说价格减了一半呢，咱们过去看看？\n王一飞：好的。不过咱们也不能只听广告说什么，还得看质量。\n王一雪：对，首先看样子喜不喜欢，然后再看质量怎么样、价格合适不合适。\n售货员：二位看看喜欢哪双？这个牌子质量很好，今天又降价，一双减300块。\n王一雪：嗯，我知道这个牌子。一飞，你喜欢吗？你看，这个鞋的样式很新，价钱也不高。\n王一飞：你喜欢就买吧。我再看看别的。\n王一雪：好的。请给我拿一双37号的吧。",
        "sourcePages": [
          45,
          46
        ],
        "targets": [
          "各位",
          "顾客",
          "假日",
          "低价",
          "促销",
          "广告",
          "首先",
          "牌子",
          "降价",
          "样式"
        ]
      },
      {
        "id": 3,
        "title": "课文 3",
        "content": "李文的朋友徐前在商业区开了家小店，专门卖年轻人喜欢的东西。他的店里商品种类不少，既有几十年前的老游戏机，也有最近流行的盲盒等等，很吸引年轻人。\n徐前说，自己就是年轻人，知道年轻人喜欢什么。他也常和来店里的年轻顾客聊天儿，了解他们的兴趣爱好。前段时间刚进的盲盒很快就卖到了缺货。许多年轻人表示，在徐前的店里能感受到快乐。小店虽然小，但东西适合年轻人，加上店员态度友好，使得小店的生意越来越好。李文觉得自己的朋友真会做生意。",
        "sourcePages": [
          47
        ],
        "targets": [
          "商业",
          "商品",
          "种类",
          "盲盒",
          "顾客",
          "许多",
          "表示",
          "加上",
          "态度",
          "友好"
        ]
      },
      {
        "id": 4,
        "title": "课文 4",
        "content": "关于购物，你是一位冷静购物者，还是不冷静购物者？一般来说，冷静购物者往往是真正需要一件东西时才买。购买时，还会从质量、价格等各方面仔细比较。不冷静购物者看见一个东西时，只要感觉喜欢就买，不管需要不需要，结果常常买完就后悔，买的东西也成了“垃圾”，还不环保。王一飞说，她从来不随便买东西。对于想买的东西，她不光看质量，还看价格。无论是一件外套，还是一条裤子，甚至一双袜子，都是仔细比较后才决定买不买。\n其实，不仅是买东西，人生的很多事情都一样，选择合适的才是最好的。",
        "sourcePages": [
          49
        ],
        "targets": [
          "者",
          "仔细",
          "对于",
          "不光",
          "外套",
          "袜子"
        ]
      }
    ],
    "translations": [
      {
        "vi": "Trước tiên xem có thích kiểu dáng hay không, sau đó xem chất lượng thế nào và giá có phù hợp không.",
        "zh": "首先看样子喜不喜欢，然后再看质量怎么样、价格合适不合适。"
      },
      {
        "vi": "Đối với món đồ muốn mua, cô ấy không chỉ xem chất lượng mà còn xem giá.",
        "zh": "对于想买的东西，她不光看质量，还看价格。"
      },
      {
        "vi": "Trên thực tế, không chỉ mua đồ, nhiều việc trong cuộc sống cũng vậy, lựa chọn điều phù hợp mới là tốt nhất.",
        "zh": "其实，不仅是买东西，人生的很多事情都一样，选择合适的才是最好的。"
      }
    ]
  },
  {
    "n": 15,
    "title": "我去应聘了",
    "volume": "下",
    "page": 50,
    "grammar": [
      "再也不/没……",
      "由",
      "把＋宾语＋动词（＋一/了）＋动词",
      "A不如B（＋形容词）"
    ],
    "words": [
      {
        "hanzi": "期中",
        "pinyin": "qīzhōng",
        "vi": "giữa kỳ"
      },
      {
        "hanzi": "医药",
        "pinyin": "yīyào",
        "vi": "y dược"
      },
      {
        "hanzi": "应聘",
        "pinyin": "yìngpìn",
        "vi": "ứng tuyển"
      },
      {
        "hanzi": "招聘",
        "pinyin": "zhāopìn",
        "vi": "tuyển dụng"
      },
      {
        "hanzi": "实习",
        "pinyin": "shíxí",
        "vi": "thực tập"
      },
      {
        "hanzi": "考虑",
        "pinyin": "kǎolǜ",
        "vi": "cân nhắc"
      },
      {
        "hanzi": "单位",
        "pinyin": "dānwèi",
        "vi": "đơn vị; cơ quan"
      },
      {
        "hanzi": "毕业生",
        "pinyin": "bìyèshēng",
        "vi": "sinh viên tốt nghiệp"
      },
      {
        "hanzi": "经历",
        "pinyin": "jīnglì",
        "vi": "trải nghiệm; trải qua"
      },
      {
        "hanzi": "消息",
        "pinyin": "xiāoxi",
        "vi": "tin tức"
      },
      {
        "hanzi": "报名",
        "pinyin": "bàomíng",
        "vi": "đăng ký"
      },
      {
        "hanzi": "填写",
        "pinyin": "tiánxiě",
        "vi": "điền vào"
      },
      {
        "hanzi": "笔试",
        "pinyin": "bǐshì",
        "vi": "thi viết"
      },
      {
        "hanzi": "面试",
        "pinyin": "miànshì",
        "vi": "phỏng vấn"
      },
      {
        "hanzi": "答",
        "pinyin": "dá",
        "vi": "trả lời"
      },
      {
        "hanzi": "由",
        "pinyin": "yóu",
        "vi": "do; bởi"
      },
      {
        "hanzi": "部门",
        "pinyin": "bùmén",
        "vi": "bộ phận"
      },
      {
        "hanzi": "负责人",
        "pinyin": "fùzérén",
        "vi": "người phụ trách"
      },
      {
        "hanzi": "不论",
        "pinyin": "búlùn",
        "vi": "bất luận"
      },
      {
        "hanzi": "肯定",
        "pinyin": "kěndìng",
        "vi": "chắc chắn"
      },
      {
        "hanzi": "短信",
        "pinyin": "duǎnxìn",
        "vi": "tin nhắn"
      },
      {
        "hanzi": "激动",
        "pinyin": "jīdòng",
        "vi": "xúc động; phấn khích"
      },
      {
        "hanzi": "扔",
        "pinyin": "rēng",
        "vi": "ném"
      },
      {
        "hanzi": "理发",
        "pinyin": "lǐfà",
        "vi": "cắt tóc"
      },
      {
        "hanzi": "镜子",
        "pinyin": "jìngzi",
        "vi": "gương"
      },
      {
        "hanzi": "自我",
        "pinyin": "zìwǒ",
        "vi": "bản thân"
      },
      {
        "hanzi": "能够",
        "pinyin": "nénggòu",
        "vi": "có thể"
      },
      {
        "hanzi": "运用",
        "pinyin": "yùnyòng",
        "vi": "vận dụng"
      },
      {
        "hanzi": "工厂",
        "pinyin": "gōngchǎng",
        "vi": "nhà máy"
      },
      {
        "hanzi": "规定",
        "pinyin": "guīdìng",
        "vi": "quy định"
      },
      {
        "hanzi": "课堂",
        "pinyin": "kètáng",
        "vi": "lớp học"
      },
      {
        "hanzi": "完全",
        "pinyin": "wánquán",
        "vi": "hoàn toàn"
      },
      {
        "hanzi": "例如",
        "pinyin": "lìrú",
        "vi": "ví dụ"
      },
      {
        "hanzi": "不如",
        "pinyin": "bùrú",
        "vi": "không bằng; thà"
      },
      {
        "hanzi": "细节",
        "pinyin": "xìjié",
        "vi": "chi tiết"
      },
      {
        "hanzi": "答案",
        "pinyin": "dá'àn",
        "vi": "đáp án"
      },
      {
        "hanzi": "职业",
        "pinyin": "zhíyè",
        "vi": "nghề nghiệp"
      }
    ],
    "texts": [
      {
        "id": 1,
        "title": "课文 1",
        "content": "陈天中：李文，期中考试后就再也没见过你了，你这段时间在忙什么呢？\n李文：我最近去一家医药公司应聘了，他们正在招聘实习生。\n陈天中：你这么早就考虑实习了？\n李文：现在很多单位在招聘毕业生时，都很重视有没有实习经历，所以我想提前去锻炼一下，积累一些经验。\n陈天中：那现在有结果了吗？\n李文：我还在等消息，希望能有好结果。",
        "sourcePages": [
          55
        ],
        "targets": [
          "期中",
          "医药",
          "应聘",
          "招聘",
          "实习",
          "考虑",
          "单位",
          "毕业生",
          "经历",
          "消息"
        ]
      },
      {
        "id": 2,
        "title": "课文 2",
        "content": "陈天中：李文，你是怎么应聘的？\n李文：我先在网上报名，填写个人信息，然后等公司通知我去参加笔试。\n陈天中：笔试都考些什么？\n李文：主要是一些专业知识。考完没多久，他们就让我去面试了。\n陈天中：看来你笔试答得不错，那你面试得怎么样？\n李文：那天是由部门负责人来面试的，我有点儿紧张。他让我介绍了自己的学习经历、兴趣爱好和对工作的想法。\n陈天中：听起来挺正式的。\n李文：是啊，我觉得这次经历很有用。不论结果怎么样，对我以后找工作肯定有帮助。",
        "sourcePages": [
          57,
          58
        ],
        "targets": [
          "应聘",
          "报名",
          "填写",
          "笔试",
          "面试",
          "部门",
          "负责人",
          "经历",
          "不论",
          "肯定"
        ]
      },
      {
        "id": 3,
        "title": "课文 3",
        "content": "一天下午，李文突然收到一条短信，说他通过了面试，让他下周一到公司实习。李文看到信息后，激动得把手机扔到床上，在屋子里跳了起来。之后的几天，李文忙着做各种准备。为了给大家留个好印象，他去理发店把头发理了理，又去商店买了一身正式的衣服，还打算在镜子前把自我介绍练一练。\n在他看来，这次实习是一个新的开始。他希望不仅能够运用专业知识完成任务，还能够积累更多经验，为将来找工作打下基础。",
        "sourcePages": [
          59
        ],
        "targets": [
          "短信",
          "面试",
          "实习",
          "激动",
          "扔",
          "理发",
          "镜子",
          "自我",
          "能够",
          "运用"
        ]
      },
      {
        "id": 4,
        "title": "课文 4",
        "content": "在中国，很多大学生在毕业前都会去实习。实习的地方有公司、工厂，也有学校和医院。学生们通过实习，可以积累工作经验，熟悉工作内容和单位的管理规定，提前了解并适应社会。\n在实习中，学生常常会发现，课堂上学到的知识和实际工作并不完全一样。例如：有些事情，在课本上学不如自己做一遍，因为只有在做的时候，才会发现有很多细节需要注意；还有一些问题，在书上找不到答案，只能通过日常工作慢慢理解。在这样的过程中，学生能够对学到的知识有更好的认识，也更清楚自己的职业发展方向。",
        "sourcePages": [
          61
        ],
        "targets": [
          "实习",
          "工厂",
          "单位",
          "规定",
          "课堂",
          "完全",
          "例如",
          "不如",
          "细节",
          "答案"
        ]
      }
    ],
    "translations": [
      {
        "vi": "Tôi muốn đi thực tập trước để rèn luyện và tích lũy một số kinh nghiệm.",
        "zh": "我想提前去锻炼一下，积累一些经验。"
      },
      {
        "vi": "Thông qua thực tập, sinh viên có thể tích lũy kinh nghiệm làm việc và thích ứng với xã hội trước.",
        "zh": "学生们通过实习，可以积累工作经验，提前了解并适应社会。"
      },
      {
        "vi": "Bất luận kết quả thế nào, chắc chắn trải nghiệm này có ích cho việc tìm việc sau này của tôi.",
        "zh": "不论结果怎么样，这次经历对我以后找工作肯定有帮助。"
      }
    ]
  },
  {
    "n": 16,
    "title": "计划赶不上变化",
    "volume": "下",
    "page": 62,
    "grammar": [
      "把＋宾语＋动词＋了",
      "并且",
      "说不定",
      "却"
    ],
    "words": [
      {
        "hanzi": "本来",
        "pinyin": "běnlái",
        "vi": "vốn dĩ; ban đầu"
      },
      {
        "hanzi": "只好",
        "pinyin": "zhǐhǎo",
        "vi": "đành phải"
      },
      {
        "hanzi": "赶上",
        "pinyin": "gǎnshàng",
        "vi": "đuổi kịp"
      },
      {
        "hanzi": "旅行",
        "pinyin": "lǚxíng",
        "vi": "du lịch"
      },
      {
        "hanzi": "推迟",
        "pinyin": "tuīchí",
        "vi": "hoãn lại"
      },
      {
        "hanzi": "取消",
        "pinyin": "qǔxiāo",
        "vi": "hủy bỏ"
      },
      {
        "hanzi": "可惜",
        "pinyin": "kěxī",
        "vi": "đáng tiếc"
      },
      {
        "hanzi": "确实",
        "pinyin": "quèshí",
        "vi": "quả thực"
      },
      {
        "hanzi": "等到",
        "pinyin": "děngdào",
        "vi": "đợi đến khi"
      },
      {
        "hanzi": "早晨",
        "pinyin": "zǎochen",
        "vi": "buổi sáng"
      },
      {
        "hanzi": "忽然",
        "pinyin": "hūrán",
        "vi": "đột nhiên"
      },
      {
        "hanzi": "增加",
        "pinyin": "zēngjiā",
        "vi": "tăng thêm"
      },
      {
        "hanzi": "调整",
        "pinyin": "tiáozhěng",
        "vi": "điều chỉnh"
      },
      {
        "hanzi": "错误",
        "pinyin": "cuòwù",
        "vi": "sai sót; sai lầm"
      },
      {
        "hanzi": "并且",
        "pinyin": "bìngqiě",
        "vi": "và; hơn nữa"
      },
      {
        "hanzi": "例子",
        "pinyin": "lìzi",
        "vi": "ví dụ"
      },
      {
        "hanzi": "关键",
        "pinyin": "guānjiàn",
        "vi": "then chốt"
      },
      {
        "hanzi": "详细",
        "pinyin": "xiángxì",
        "vi": "chi tiết"
      },
      {
        "hanzi": "时间表",
        "pinyin": "shíjiānbiǎo",
        "vi": "thời gian biểu"
      },
      {
        "hanzi": "把握",
        "pinyin": "bǎwò",
        "vi": "sự chắc chắn; nắm chắc"
      },
      {
        "hanzi": "相反",
        "pinyin": "xiāngfǎn",
        "vi": "ngược lại"
      },
      {
        "hanzi": "部分",
        "pinyin": "bùfen",
        "vi": "bộ phận; một phần"
      },
      {
        "hanzi": "轻松",
        "pinyin": "qīngsōng",
        "vi": "thoải mái"
      },
      {
        "hanzi": "标准",
        "pinyin": "biāozhǔn",
        "vi": "tiêu chuẩn"
      },
      {
        "hanzi": "严格",
        "pinyin": "yángé",
        "vi": "nghiêm khắc; nghiêm ngặt"
      },
      {
        "hanzi": "取得",
        "pinyin": "qǔdé",
        "vi": "đạt được"
      },
      {
        "hanzi": "说不定",
        "pinyin": "shuōbudìng",
        "vi": "có lẽ; chưa biết chừng"
      },
      {
        "hanzi": "灵活",
        "pinyin": "línghuó",
        "vi": "linh hoạt"
      },
      {
        "hanzi": "一切",
        "pinyin": "yíqiè",
        "vi": "tất cả"
      },
      {
        "hanzi": "却",
        "pinyin": "què",
        "vi": "lại; nhưng"
      },
      {
        "hanzi": "不得不",
        "pinyin": "bùdébù",
        "vi": "không thể không; buộc phải"
      },
      {
        "hanzi": "约",
        "pinyin": "yuē",
        "vi": "hẹn; khoảng"
      },
      {
        "hanzi": "不便",
        "pinyin": "búbiàn",
        "vi": "bất tiện"
      },
      {
        "hanzi": "失望",
        "pinyin": "shīwàng",
        "vi": "thất vọng"
      },
      {
        "hanzi": "也许",
        "pinyin": "yěxǔ",
        "vi": "có lẽ"
      },
      {
        "hanzi": "逛",
        "pinyin": "guàng",
        "vi": "đi dạo"
      },
      {
        "hanzi": "有趣",
        "pinyin": "yǒuqù",
        "vi": "thú vị"
      },
      {
        "hanzi": "观看",
        "pinyin": "guānkàn",
        "vi": "xem; quan sát"
      },
      {
        "hanzi": "部",
        "pinyin": "bù",
        "vi": "lượng từ cho phim, sách"
      },
      {
        "hanzi": "无法",
        "pinyin": "wúfǎ",
        "vi": "không có cách nào"
      },
      {
        "hanzi": "接受",
        "pinyin": "jiēshòu",
        "vi": "chấp nhận"
      }
    ],
    "texts": [
      {
        "id": 1,
        "title": "课文 1",
        "content": "王一雪：家月，周末你还打算去南京旅游吗？我去年去过那里，可以给你介绍一下。\n白家月：本来都计划好了，可是昨天突然接到通知，下周学校要安排一次考试，所以周末只好在家复习了。\n王一雪：真是计划赶不上变化啊！看来你的旅行计划只能推迟了。\n白家月：是的，我已经把机票和酒店取消了。虽然有点儿可惜，但学习更重要。\n王一雪：学习确实要放在第一位。等到考试结束后，你再找个时间去。\n白家月：我也是这么想的，以后肯定还有很多机会。",
        "sourcePages": [
          67
        ],
        "targets": [
          "本来",
          "只好",
          "旅行",
          "推迟",
          "取消",
          "可惜",
          "确实",
          "等到"
        ]
      },
      {
        "id": 2,
        "title": "课文 2",
        "content": "杨同乐：刚接到通知，明天早晨的会议，时间改到下周了。\n王一雪：啊？时间都安排好了，怎么说变就变了？\n杨同乐：是啊，没想到忽然要改时间。\n王一雪：好吧，那再看看有没有新的安排，或者增加的会议内容。\n杨同乐：好的。会议材料还需要调整吗？\n王一雪：再检查一下有没有细节上的错误，并且试着增加一些例子，把内容准备得更全一些。\n杨同乐：没问题，这样效果肯定会更好。\n王一雪：看来有时候变化不一定是坏事，关键是我们怎么去适应变化。",
        "sourcePages": [
          69,
          70
        ],
        "targets": [
          "早晨",
          "忽然",
          "增加",
          "调整",
          "错误",
          "并且",
          "例子",
          "关键"
        ]
      },
      {
        "id": 3,
        "title": "课文 3",
        "content": "在生活和工作中，有的人喜欢做计划，他们会提前安排好每天要做的事情，然后按照详细的时间表去完成任务，觉得这样做更有把握。相反，也有一部分人不爱做计划，他们认为随意一些也很好，想到什么就去做什么，感觉这样比较轻松。\n其实，事前做计划是好是坏没有标准答案。严格按照计划做事，常常能取得不错的效果；而不做计划，说不定也会带来新的发现。无论做不做计划，只要既能按时完成任务，又能根据情况灵活调整，就是适合自己的方式。",
        "sourcePages": [
          71
        ],
        "targets": [
          "详细",
          "时间表",
          "把握",
          "相反",
          "部分",
          "轻松",
          "标准",
          "严格",
          "取得",
          "说不定"
        ]
      },
      {
        "id": 4,
        "title": "课文 4",
        "content": "人们常说“计划赶不上变化”。有时候，你准备好了一切，却突然出现了新情况，让你不得不改变计划。比如准备出去旅行，可能因为有事而取消；约好见朋友，可能因为天气不好而推迟。\n虽然变化经常打乱计划，给我们带来不便，甚至让人感到失望，但这些变化也许会给生活带来新的可能。比如没去成旅行，于是在家门口的小公园逛了逛，发现那里也很有趣；没见到朋友，于是在家观看了一部电影，心情也变得很愉快。\n生活中很多变化是无法提前知道的，我们要做的就是学会接受变化、适应变化，在变化中找到新的解决办法。这样不仅能锻炼自己在面对不同情况时解决问题的能力，也能让我们的生活更轻松。",
        "sourcePages": [
          73,
          74
        ],
        "targets": [
          "一切",
          "不得不",
          "旅行",
          "取消",
          "推迟",
          "不便",
          "失望",
          "也许",
          "有趣",
          "观看"
        ]
      }
    ],
    "translations": [
      {
        "vi": "Tôi đã hủy vé máy bay và khách sạn rồi.",
        "zh": "我已经把机票和酒店取消了。"
      },
      {
        "vi": "Kiểm tra lại xem có sai sót ở chi tiết nào không, đồng thời thử thêm một số ví dụ.",
        "zh": "再检查一下有没有细节上的错误，并且试着增加一些例子。"
      },
      {
        "vi": "Bạn đã chuẩn bị xong mọi thứ, nhưng tình huống mới đột nhiên xuất hiện khiến bạn buộc phải thay đổi kế hoạch.",
        "zh": "你准备好了一切，却突然出现了新情况，让你不得不改变计划。"
      }
    ]
  },
  {
    "n": 17,
    "title": "运动让我更健康",
    "volume": "下",
    "page": 74,
    "grammar": [
      "你×你的吧",
      "一A一B",
      "主语＋表扬/批评＋宾语1＋动词＋宾语2",
      "连……也/都……，……更……"
    ],
    "words": [
      {
        "hanzi": "路过",
        "pinyin": "lùguò",
        "vi": "đi ngang qua"
      },
      {
        "hanzi": "趟",
        "pinyin": "tàng",
        "vi": "lượt; chuyến"
      },
      {
        "hanzi": "健身房",
        "pinyin": "jiànshēnfáng",
        "vi": "phòng tập thể hình"
      },
      {
        "hanzi": "健身",
        "pinyin": "jiànshēn",
        "vi": "tập thể hình"
      },
      {
        "hanzi": "体重",
        "pinyin": "tǐzhòng",
        "vi": "cân nặng"
      },
      {
        "hanzi": "会员",
        "pinyin": "huìyuán",
        "vi": "hội viên"
      },
      {
        "hanzi": "饼干",
        "pinyin": "bǐnggān",
        "vi": "bánh quy"
      },
      {
        "hanzi": "酸奶",
        "pinyin": "suānnǎi",
        "vi": "sữa chua"
      },
      {
        "hanzi": "果汁",
        "pinyin": "guǒzhī",
        "vi": "nước ép trái cây"
      },
      {
        "hanzi": "教练",
        "pinyin": "jiàoliàn",
        "vi": "huấn luyện viên"
      },
      {
        "hanzi": "动作",
        "pinyin": "dòngzuò",
        "vi": "động tác"
      },
      {
        "hanzi": "科学",
        "pinyin": "kēxué",
        "vi": "khoa học"
      },
      {
        "hanzi": "受伤",
        "pinyin": "shòushāng",
        "vi": "bị thương"
      },
      {
        "hanzi": "操场",
        "pinyin": "cāochǎng",
        "vi": "sân vận động; sân tập"
      },
      {
        "hanzi": "其中",
        "pinyin": "qízhōng",
        "vi": "trong số đó"
      },
      {
        "hanzi": "之",
        "pinyin": "zhī",
        "vi": "trợ từ kết cấu (của)"
      },
      {
        "hanzi": "火",
        "pinyin": "huǒ",
        "vi": "nổi tiếng; thịnh hành"
      },
      {
        "hanzi": "好处",
        "pinyin": "hǎochu",
        "vi": "lợi ích"
      },
      {
        "hanzi": "设备",
        "pinyin": "shèbèi",
        "vi": "thiết bị"
      },
      {
        "hanzi": "全身",
        "pinyin": "quánshēn",
        "vi": "toàn thân"
      },
      {
        "hanzi": "准确",
        "pinyin": "zhǔnquè",
        "vi": "chính xác"
      },
      {
        "hanzi": "仅仅",
        "pinyin": "jǐnjǐn",
        "vi": "chỉ; vẻn vẹn"
      },
      {
        "hanzi": "表扬",
        "pinyin": "biǎoyáng",
        "vi": "khen ngợi"
      },
      {
        "hanzi": "进步",
        "pinyin": "jìnbù",
        "vi": "tiến bộ"
      },
      {
        "hanzi": "鼓励",
        "pinyin": "gǔlì",
        "vi": "khích lệ"
      },
      {
        "hanzi": "帅",
        "pinyin": "shuài",
        "vi": "đẹp trai"
      },
      {
        "hanzi": "乒乓球",
        "pinyin": "pīngpāngqiú",
        "vi": "bóng bàn"
      },
      {
        "hanzi": "队",
        "pinyin": "duì",
        "vi": "đội"
      },
      {
        "hanzi": "项",
        "pinyin": "xiàng",
        "vi": "hạng mục"
      },
      {
        "hanzi": "赢得",
        "pinyin": "yíngdé",
        "vi": "giành được"
      },
      {
        "hanzi": "叫作",
        "pinyin": "jiàozuò",
        "vi": "được gọi là"
      },
      {
        "hanzi": "梦",
        "pinyin": "mèng",
        "vi": "giấc mơ"
      },
      {
        "hanzi": "不断",
        "pinyin": "búduàn",
        "vi": "không ngừng"
      },
      {
        "hanzi": "队员",
        "pinyin": "duìyuán",
        "vi": "thành viên đội"
      },
      {
        "hanzi": "训练",
        "pinyin": "xùnliàn",
        "vi": "huấn luyện; tập luyện"
      },
      {
        "hanzi": "球队",
        "pinyin": "qiúduì",
        "vi": "đội bóng"
      },
      {
        "hanzi": "球迷",
        "pinyin": "qiúmí",
        "vi": "người hâm mộ bóng"
      },
      {
        "hanzi": "梦想",
        "pinyin": "mèngxiǎng",
        "vi": "ước mơ"
      },
      {
        "hanzi": "大赛",
        "pinyin": "dàsài",
        "vi": "giải đấu lớn"
      },
      {
        "hanzi": "赢",
        "pinyin": "yíng",
        "vi": "thắng"
      },
      {
        "hanzi": "连",
        "pinyin": "lián",
        "vi": "ngay cả"
      }
    ],
    "texts": [
      {
        "id": 1,
        "title": "课文 1",
        "content": "王一雪：下班了！同乐，我今天正好要路过你们家那边，用不用我开车送你？\n杨同乐：谢谢一雪姐，不过您走您的吧，我一会儿还要去一趟健身房。\n王一雪：去健身房？你什么时候开始健身的？\n杨同乐：我上个星期发现单位旁边新开了一家健身房。我最近体重增加了不少，正好想运动一下，就进去看了看。\n王一雪：感觉怎么样？\n杨同乐：挺不错的。当时正好有打折活动，我就办了一张会员卡。",
        "sourcePages": [
          79
        ],
        "targets": [
          "路过",
          "趟",
          "健身房",
          "体重",
          "会员"
        ]
      },
      {
        "id": 2,
        "title": "课文 2",
        "content": "王一雪：同乐，你晚上不吃饭就去健身，不会饿吗？\n杨同乐：我带了饼干、酸奶和果汁，一会儿吃完了再去。\n王一雪：那你为什么不在家附近找健身房？吃完晚饭，休息一下再去，不是更好吗？\n杨同乐：离我家最近的健身房也要坐两站公交车，一来一回得半个小时，太浪费时间了。\n王一雪：确实。那这家健身房的教练怎么样？\n杨同乐：教练很热情，也非常专业，动作讲得很清楚。\n王一雪：听你这么一说，我也想试试了。我现在都是在家看着视频练，动作不一定标准。\n杨同乐：好啊，那您也来吧。锻炼要科学，否则容易受伤。",
        "sourcePages": [
          81
        ],
        "targets": [
          "健身",
          "饼干",
          "酸奶",
          "果汁",
          "健身房",
          "教练",
          "动作",
          "科学",
          "受伤"
        ]
      },
      {
        "id": 3,
        "title": "课文 3",
        "content": "有人爱在操场跑步，有人喜欢通过打球锻炼身体，还有一部分人愿意去健身房健身，杨同乐就是其中之一。\n杨同乐认为健身房火起来是因为它有很多好处——环境好、设备全，可以锻炼全身。另外，健身房里一般还有专业教练，能帮助大家把动作做准确，练习的效果也更好。\n仅仅经过一个月左右的锻炼，杨同乐就感觉自己的身体比以前更健康了。教练也表扬他取得了很大的进步，并鼓励他坚持下去，还说随着身体越来越好，人看起来也会更帅。",
        "sourcePages": [
          83
        ],
        "targets": [
          "操场",
          "健身房",
          "其中",
          "好处",
          "设备",
          "全身",
          "教练",
          "动作",
          "准确",
          "仅仅"
        ]
      },
      {
        "id": 4,
        "title": "课文 4",
        "content": "中国乒乓球队非常有名，常在各项比赛中赢得第一名，被叫作“梦之队”。为了不断提高自己的水平，队员们每天都要进行严格的训练。正因为这样，球队才能在比赛中取得更好的成绩，获得更多球迷的喜爱。许多年轻的乒乓球运动员都有一个梦想，那就是进入国家队，参加世界大赛，为球队赢下比赛。\n在中国，除了专业运动员，喜欢打乒乓球的普通人也特别多。连一些年龄比较大的人都坚持打球，年轻人更是把它作为一种日常锻炼的方式。可以说，乒乓球是中国人生活中最常见的运动之一。",
        "sourcePages": [
          85
        ],
        "targets": [
          "乒乓球",
          "队",
          "赢得",
          "叫作",
          "不断",
          "队员",
          "训练",
          "球迷",
          "梦想",
          "大赛"
        ]
      }
    ],
    "translations": [
      {
        "vi": "Đi và về mất nửa tiếng, quá lãng phí thời gian.",
        "zh": "一来一回得半个小时，太浪费时间了。"
      },
      {
        "vi": "Huấn luyện viên cũng khen anh ấy đã đạt được tiến bộ rất lớn và khích lệ anh kiên trì tiếp tục.",
        "zh": "教练也表扬他取得了很大的进步，并鼓励他坚持下去。"
      },
      {
        "vi": "Để không ngừng nâng cao trình độ của mình, các thành viên đội hằng ngày đều phải tập luyện nghiêm ngặt.",
        "zh": "为了不断提高自己的水平，队员们每天都要进行严格的训练。"
      }
    ]
  },
  {
    "n": 18,
    "title": "科技改变生活",
    "volume": "下",
    "page": 86,
    "grammar": [
      "数词＋形容词＋量词",
      "让/叫字被动句",
      "到底",
      "然而"
    ],
    "words": [
      {
        "hanzi": "猜",
        "pinyin": "cāi",
        "vi": "đoán"
      },
      {
        "hanzi": "共享",
        "pinyin": "gòngxiǎng",
        "vi": "chia sẻ"
      },
      {
        "hanzi": "单车",
        "pinyin": "dānchē",
        "vi": "xe đạp"
      },
      {
        "hanzi": "出口",
        "pinyin": "chūkǒu",
        "vi": "lối ra; xuất khẩu"
      },
      {
        "hanzi": "推",
        "pinyin": "tuī",
        "vi": "đẩy"
      },
      {
        "hanzi": "对",
        "pinyin": "duì",
        "vi": "hướng vào; đối với"
      },
      {
        "hanzi": "二维码",
        "pinyin": "èrwéimǎ",
        "vi": "mã QR"
      },
      {
        "hanzi": "注册",
        "pinyin": "zhùcè",
        "vi": "đăng ký"
      },
      {
        "hanzi": "费用",
        "pinyin": "fèiyòng",
        "vi": "chi phí"
      },
      {
        "hanzi": "说明",
        "pinyin": "shuōmíng",
        "vi": "giải thích; hướng dẫn"
      },
      {
        "hanzi": "办事",
        "pinyin": "bànshì",
        "vi": "giải quyết công việc"
      },
      {
        "hanzi": "差点儿",
        "pinyin": "chàdiǎnr",
        "vi": "suýt nữa"
      },
      {
        "hanzi": "拍",
        "pinyin": "pāi",
        "vi": "quay; chụp"
      },
      {
        "hanzi": "各个",
        "pinyin": "gègè",
        "vi": "từng; mỗi"
      },
      {
        "hanzi": "小组",
        "pinyin": "xiǎozǔ",
        "vi": "nhóm nhỏ"
      },
      {
        "hanzi": "讨论",
        "pinyin": "tǎolùn",
        "vi": "thảo luận"
      },
      {
        "hanzi": "演",
        "pinyin": "yǎn",
        "vi": "diễn"
      },
      {
        "hanzi": "厨师",
        "pinyin": "chúshī",
        "vi": "đầu bếp"
      },
      {
        "hanzi": "各地",
        "pinyin": "gèdì",
        "vi": "các nơi"
      },
      {
        "hanzi": "著名",
        "pinyin": "zhùmíng",
        "vi": "nổi tiếng"
      },
      {
        "hanzi": "小吃",
        "pinyin": "xiǎochī",
        "vi": "món ăn nhẹ"
      },
      {
        "hanzi": "互联网",
        "pinyin": "hùliánwǎng",
        "vi": "Internet"
      },
      {
        "hanzi": "点赞",
        "pinyin": "diǎnzàn",
        "vi": "bấm thích"
      },
      {
        "hanzi": "AI眼镜",
        "pinyin": "AI yǎnjìng",
        "vi": "kính AI"
      },
      {
        "hanzi": "3D打印机",
        "pinyin": "3D dǎyìnjī",
        "vi": "máy in 3D"
      },
      {
        "hanzi": "上门",
        "pinyin": "shàngmén",
        "vi": "đến tận nhà"
      },
      {
        "hanzi": "到底",
        "pinyin": "dàodǐ",
        "vi": "rốt cuộc"
      },
      {
        "hanzi": "仅",
        "pinyin": "jǐn",
        "vi": "chỉ"
      },
      {
        "hanzi": "多样",
        "pinyin": "duōyàng",
        "vi": "đa dạng"
      },
      {
        "hanzi": "推出",
        "pinyin": "tuīchū",
        "vi": "ra mắt; đưa ra"
      },
      {
        "hanzi": "预约",
        "pinyin": "yùyuē",
        "vi": "đặt lịch"
      },
      {
        "hanzi": "取",
        "pinyin": "qǔ",
        "vi": "lấy"
      },
      {
        "hanzi": "原因",
        "pinyin": "yuányīn",
        "vi": "nguyên nhân"
      },
      {
        "hanzi": "然而",
        "pinyin": "rán'ér",
        "vi": "tuy nhiên"
      },
      {
        "hanzi": "不必",
        "pinyin": "búbì",
        "vi": "không cần thiết"
      },
      {
        "hanzi": "亲戚",
        "pinyin": "qīnqi",
        "vi": "họ hàng"
      },
      {
        "hanzi": "按",
        "pinyin": "àn",
        "vi": "theo; ấn"
      },
      {
        "hanzi": "提出",
        "pinyin": "tíchū",
        "vi": "đề xuất"
      },
      {
        "hanzi": "大大",
        "pinyin": "dàdà",
        "vi": "rất nhiều; đáng kể"
      },
      {
        "hanzi": "现有",
        "pinyin": "xiànyǒu",
        "vi": "hiện có"
      }
    ],
    "texts": [
      {
        "id": 1,
        "title": "课文 1",
        "content": "白家月：安妮，我们在这儿呢。\n安妮：天中、家月，你们猜我是怎么过来的？\n白家月：坐公交车吗？\n安妮：我先坐的公交车，然后骑共享单车，快到那边那个出口时又推了一小段。\n白家月：我看很多人都骑共享单车，我还没骑过呢。\n陈天中：我骑过，很方便的。第一次骑的时候，你打开微信，对着共享单车上的二维码扫一下，在App上完成注册就可以了，怎么使用、费用标准什么的App上都有说明。\n白家月：好啊！哪天我出去办事时也试试。",
        "sourcePages": [
          91
        ],
        "targets": [
          "猜",
          "共享",
          "单车",
          "出口",
          "推",
          "二维码",
          "注册",
          "费用",
          "说明",
          "办事"
        ]
      },
      {
        "id": 2,
        "title": "课文 2",
        "content": "安妮：差点儿忘了，我给你们看个短视频。\n白家月：啊？你们拍的？真不错！\n安妮：对！前段时间老师留了个作业，叫各个小组拍个短视频，介绍中国美食。我们小组讨论后决定，由AI小语演厨师，做出中国各地的著名小吃。拍完后，老师说很不错。\n陈天中：嗯，语言也很幽默！\n安妮：后来这个视频让我同学放到了互联网上，很多人都来点赞。\n白家月：看来大家都喜欢这个视频。\n安妮：后边我们打算拍第二个、第三个，让小语带大家到中国各地走一走、看一看。\n陈天中：这样大家就能通过你们的视频了解中国了，我支持你们！",
        "sourcePages": [
          93,
          94
        ],
        "targets": [
          "差点儿",
          "各个",
          "小组",
          "讨论",
          "厨师",
          "各地",
          "著名",
          "小吃",
          "互联网",
          "点赞"
        ]
      },
      {
        "id": 3,
        "title": "课文 3",
        "content": "安妮骑共享单车到了白家月、陈天中的学校，三人从共享单车聊到AI眼镜和3D打印机，从绿色经济聊到上门经济。科技到底对世界产生了怎样的影响？他们都认为，科技确实改变了人们的生活。\n接着，安妮给大家看了她和同学们拍的短视频。安妮说，短视频是用手机拍的，他们找了一些免费的App，仅用几天就拍完了。视频里，小语做的小吃丰富多样，看起来好吃极了。短视频推出后，大家认为非常精彩，白家月和陈天中看后也特别喜欢，并且表示支持他们拍更多的视频。",
        "sourcePages": [
          95,
          96
        ],
        "targets": [
          "共享",
          "单车",
          "AI眼镜",
          "3D打印机",
          "上门",
          "到底",
          "对",
          "小吃",
          "多样",
          "推出"
        ]
      },
      {
        "id": 4,
        "title": "课文 4",
        "content": "随着互联网技术的发展，现在又出现了一种新的服务方式——上门经济，就是预约者通过网上预约，让服务人员在合适的时间到家里或约好的地点服务，服务内容有上门做饭、照顾小动物、取东西等。赵女士养了一只猫，由于工作等原因，她需要经常出差，然而又很担心猫的安全。有了上门服务后，她觉得方便多了，不必再找亲戚帮忙。每次出差，在网上预约并支付费用后，服务人员就会按她提出的要求上门照顾小猫，大大减轻了她的压力，赵女士也特别满意。\n当然，上门经济也有一些问题，特别是现有服务人员有些还不够专业，需要重新学习，提高服务质量。",
        "sourcePages": [
          97,
          98
        ],
        "targets": [
          "互联网",
          "上门",
          "预约",
          "原因",
          "然而",
          "不必",
          "亲戚",
          "费用",
          "提出",
          "大大"
        ]
      }
    ],
    "translations": [
      {
        "vi": "Trên ứng dụng có hướng dẫn về cách sử dụng và tiêu chuẩn chi phí.",
        "zh": "怎么使用、费用标准什么的App上都有说明。"
      },
      {
        "vi": "Công nghệ rốt cuộc đã tạo ra ảnh hưởng như thế nào đối với thế giới?",
        "zh": "科技到底对世界产生了怎样的影响？"
      },
      {
        "vi": "Sau khi đặt lịch và thanh toán chi phí trên mạng, nhân viên phục vụ sẽ đến tận nhà theo yêu cầu cô ấy đưa ra.",
        "zh": "在网上预约并支付费用后，服务人员就会按她提出的要求上门服务。"
      }
    ]
  },
  {
    "n": 19,
    "title": "他们都很棒",
    "volume": "下",
    "page": 99,
    "grammar": [
      "不是……，就是……",
      "动词＋一×是一×",
      "把字句（动量补语）",
      "把字句（时量补语）"
    ],
    "words": [
      {
        "hanzi": "话剧",
        "pinyin": "huàjù",
        "vi": "kịch nói"
      },
      {
        "hanzi": "排",
        "pinyin": "pái",
        "vi": "tập dượt; sắp xếp"
      },
      {
        "hanzi": "艺术",
        "pinyin": "yìshù",
        "vi": "nghệ thuật"
      },
      {
        "hanzi": "内心",
        "pinyin": "nèixīn",
        "vi": "nội tâm"
      },
      {
        "hanzi": "自信",
        "pinyin": "zìxìn",
        "vi": "tự tin"
      },
      {
        "hanzi": "少年",
        "pinyin": "shàonián",
        "vi": "thiếu niên"
      },
      {
        "hanzi": "歌手",
        "pinyin": "gēshǒu",
        "vi": "ca sĩ"
      },
      {
        "hanzi": "歌声",
        "pinyin": "gēshēng",
        "vi": "tiếng hát"
      },
      {
        "hanzi": "度假",
        "pinyin": "dùjià",
        "vi": "đi nghỉ"
      },
      {
        "hanzi": "演员",
        "pinyin": "yǎnyuán",
        "vi": "diễn viên"
      },
      {
        "hanzi": "演唱",
        "pinyin": "yǎnchàng",
        "vi": "biểu diễn ca hát"
      },
      {
        "hanzi": "留下",
        "pinyin": "liúxià",
        "vi": "để lại"
      },
      {
        "hanzi": "青年",
        "pinyin": "qīngnián",
        "vi": "thanh niên"
      },
      {
        "hanzi": "观众",
        "pinyin": "guānzhòng",
        "vi": "khán giả"
      },
      {
        "hanzi": "功课",
        "pinyin": "gōngkè",
        "vi": "bài vở; công tác chuẩn bị"
      },
      {
        "hanzi": "转发",
        "pinyin": "zhuǎnfā",
        "vi": "chuyển tiếp; chia sẻ lại"
      },
      {
        "hanzi": "入口",
        "pinyin": "rùkǒu",
        "vi": "lối vào"
      },
      {
        "hanzi": "入",
        "pinyin": "rù",
        "vi": "vào"
      },
      {
        "hanzi": "指",
        "pinyin": "zhǐ",
        "vi": "chỉ"
      },
      {
        "hanzi": "功夫",
        "pinyin": "gōngfu",
        "vi": "công phu; kỹ năng"
      },
      {
        "hanzi": "获奖",
        "pinyin": "huòjiǎng",
        "vi": "đoạt giải"
      },
      {
        "hanzi": "奖",
        "pinyin": "jiǎng",
        "vi": "giải thưởng"
      },
      {
        "hanzi": "期待",
        "pinyin": "qīdài",
        "vi": "mong đợi"
      },
      {
        "hanzi": "鼓掌",
        "pinyin": "gǔzhǎng",
        "vi": "vỗ tay"
      },
      {
        "hanzi": "邀请",
        "pinyin": "yāoqǐng",
        "vi": "mời"
      },
      {
        "hanzi": "庆祝",
        "pinyin": "qìngzhù",
        "vi": "chúc mừng; ăn mừng"
      },
      {
        "hanzi": "点头",
        "pinyin": "diǎntóu",
        "vi": "gật đầu"
      },
      {
        "hanzi": "作品",
        "pinyin": "zuòpǐn",
        "vi": "tác phẩm"
      },
      {
        "hanzi": "作者",
        "pinyin": "zuòzhě",
        "vi": "tác giả"
      },
      {
        "hanzi": "世纪",
        "pinyin": "shìjì",
        "vi": "thế kỷ"
      },
      {
        "hanzi": "读者",
        "pinyin": "dúzhě",
        "vi": "độc giả"
      },
      {
        "hanzi": "作家",
        "pinyin": "zuòjiā",
        "vi": "nhà văn"
      },
      {
        "hanzi": "版",
        "pinyin": "bǎn",
        "vi": "phiên bản; ấn bản"
      },
      {
        "hanzi": "文章",
        "pinyin": "wénzhāng",
        "vi": "bài văn; bài viết"
      },
      {
        "hanzi": "全部",
        "pinyin": "quánbù",
        "vi": "toàn bộ"
      },
      {
        "hanzi": "整理",
        "pinyin": "zhěnglǐ",
        "vi": "sắp xếp; chỉnh lý"
      },
      {
        "hanzi": "文字",
        "pinyin": "wénzì",
        "vi": "chữ viết; văn bản"
      },
      {
        "hanzi": "图片",
        "pinyin": "túpiàn",
        "vi": "hình ảnh"
      },
      {
        "hanzi": "报考",
        "pinyin": "bàokǎo",
        "vi": "đăng ký dự thi"
      },
      {
        "hanzi": "文学",
        "pinyin": "wénxué",
        "vi": "văn học"
      },
      {
        "hanzi": "国家大剧院",
        "pinyin": "Guójiā Dàjùyuàn",
        "vi": "Nhà hát lớn quốc gia Trung Quốc",
        "properNoun": true
      },
      {
        "hanzi": "京剧",
        "pinyin": "Jīngjù",
        "vi": "Kinh kịch",
        "properNoun": true
      },
      {
        "hanzi": "梅兰芳",
        "pinyin": "Méi Lánfāng",
        "vi": "Mai Lan Phương",
        "properNoun": true
      },
      {
        "hanzi": "马可·波罗",
        "pinyin": "Mǎkě Bōluó",
        "vi": "Marco Polo",
        "properNoun": true
      },
      {
        "hanzi": "意大利",
        "pinyin": "Yìdàlì",
        "vi": "Ý",
        "properNoun": true
      },
      {
        "hanzi": "马可·波罗游记",
        "pinyin": "Mǎkě Bōluó Yóujì",
        "vi": "Du ký Marco Polo",
        "properNoun": true
      },
      {
        "hanzi": "东方旅行日记",
        "pinyin": "Dōngfāng Lǚxíng Rìjì",
        "vi": "Nhật ký du lịch phương Đông",
        "properNoun": true
      }
    ],
    "texts": [
      {
        "id": 1,
        "title": "课文 1",
        "content": "王一雪：小雪，你们的话剧排好了吗？\n刘小雪：差不多了，妈妈。艺术节周五下午开始，我内心还是有些紧张，有时候不是忘词，就是忘记做动作。\n王一雪：没事，妈妈相信你一定可以。放松些，再自信些！\n刘小雪：好的，我同学演少年歌手，他的歌声美极了。我演他的妈妈，不知道像不像呢。\n王一雪：没问题的，努力做最好的自己就好。演出时，我和你爸都去给你加油。\n刘小雪：好的，谢谢妈妈！",
        "sourcePages": [
          104
        ],
        "targets": [
          "话剧",
          "排",
          "艺术",
          "内心",
          "自信",
          "少年",
          "歌手",
          "歌声"
        ]
      },
      {
        "id": 2,
        "title": "课文 2",
        "content": "李文：下周六晚上，我请大家去国家大剧院看京剧，怎么样？\n安妮：好啊。我小时候在加拿大度假时，在宾馆的电视上看过一次，是梅兰芳等演员演的，演员们都非常棒，他们演唱得好听极了，给我留下的印象特别深。\n李文：梅兰芳先生是中国著名京剧艺术家。咱们要看的这个京剧是青年演员们演的，要去看的观众也特别多。\n陈天中：不知道我们能不能看懂。\n白家月：咱们先做做功课，提前了解下，能懂一点儿是一点儿。\n陈天中：对，我先去网上查资料，查完后也转发给你们。\n安妮：谢谢天中！\n李文：那我就在网上订票了，到时候咱们在大剧院入口见。",
        "sourcePages": [
          106,
          107
        ],
        "targets": [
          "度假",
          "演员",
          "演唱",
          "留下",
          "艺术",
          "青年",
          "观众",
          "功课",
          "转发",
          "入口"
        ]
      },
      {
        "id": 3,
        "title": "课文 3",
        "content": "周六晚上，李文等四人来到国家大剧院观看京剧演出。入座后，李文指着节目表说：“这些演员很专业，功夫很深，在京剧比赛中获得很多奖，有的还是国家、国际大奖。我特别期待这场演出。”\n演出开始后，他们看到演员们做的动作很难，但是做得都特别好，观众们不断鼓掌。因为李文他们提前把故事了解了一遍，所以差不多都看懂了。演出结束后，演员们邀请观众和他们一起庆祝演出成功。\n回来的路上，大家特别激动，觉得京剧很有意思，演员演得很精彩。李文点头说：“是啊，以后咱们还来看。”",
        "sourcePages": [
          108
        ],
        "targets": [
          "入",
          "指",
          "演员",
          "功夫",
          "期待",
          "观众",
          "鼓掌",
          "邀请",
          "庆祝",
          "点头"
        ]
      },
      {
        "id": 4,
        "title": "课文 4",
        "content": "马可·波罗是意大利旅行家，在1275年和家人来到中国，在中国大约生活了17年，最后完成了一部作品——《马可·波罗游记》。在这部影响很大的作品中，作者向世界介绍了13世纪时的中国。\n作为读者，读完这部作品后，我也很想成为作家，更想来中国看看。来到中国后，我发现现在的中国和书里的中国已有很大不同。\n前两天，我去书店看到了中文版的《马可·波罗游记》，马上买了一本，到家后又把这本书看了两天。看完后，我决定把自己来中国后写的文章、日记等全部整理出来，完成一部文字加图片的作品——《东方旅行日记》，再次把中国介绍给世界。同时我也想继续学习中文和中国文化，报考中国语言文学专业的研究生。",
        "sourcePages": [
          110,
          111
        ],
        "targets": [
          "作品",
          "作者",
          "世纪",
          "读者",
          "作家",
          "文章",
          "全部",
          "整理",
          "文字",
          "图片"
        ]
      }
    ],
    "translations": [
      {
        "vi": "Đôi khi tôi không quên lời thoại thì lại quên thực hiện động tác.",
        "zh": "有时候不是忘词，就是忘记做动作。"
      },
      {
        "vi": "Chúng ta chuẩn bị trước, hiểu được chút nào hay chút ấy.",
        "zh": "咱们先做做功课，提前了解下，能懂一点儿是一点儿。"
      },
      {
        "vi": "Sau khi về nhà, tôi lại đọc cuốn sách này trong hai ngày.",
        "zh": "到家后又把这本书看了两天。"
      }
    ]
  },
  {
    "n": 20,
    "title": "看不完也读不完",
    "volume": "下",
    "page": 111,
    "grammar": [
      "难道",
      "疑问代词构成的反问句",
      "×就×（点儿）吧",
      "要是……，（就）……，否则……"
    ],
    "words": [
      {
        "hanzi": "堵车",
        "pinyin": "dǔchē",
        "vi": "tắc đường"
      },
      {
        "hanzi": "乘",
        "pinyin": "chéng",
        "vi": "đi bằng phương tiện"
      },
      {
        "hanzi": "难道",
        "pinyin": "nándào",
        "vi": "lẽ nào"
      },
      {
        "hanzi": "无",
        "pinyin": "wú",
        "vi": "không có"
      },
      {
        "hanzi": "动车",
        "pinyin": "dòngchē",
        "vi": "tàu điện cao tốc"
      },
      {
        "hanzi": "车速",
        "pinyin": "chēsù",
        "vi": "tốc độ xe"
      },
      {
        "hanzi": "列",
        "pinyin": "liè",
        "vi": "lượng từ cho đoàn tàu; hàng"
      },
      {
        "hanzi": "晚餐",
        "pinyin": "wǎncān",
        "vi": "bữa tối"
      },
      {
        "hanzi": "夜",
        "pinyin": "yè",
        "vi": "đêm"
      },
      {
        "hanzi": "大巴",
        "pinyin": "dàbā",
        "vi": "xe khách lớn"
      },
      {
        "hanzi": "安检",
        "pinyin": "ānjiǎn",
        "vi": "kiểm tra an ninh"
      },
      {
        "hanzi": "登机",
        "pinyin": "dēngjī",
        "vi": "lên máy bay"
      },
      {
        "hanzi": "小说",
        "pinyin": "xiǎoshuō",
        "vi": "tiểu thuyết"
      },
      {
        "hanzi": "航班",
        "pinyin": "hángbān",
        "vi": "chuyến bay"
      },
      {
        "hanzi": "值机",
        "pinyin": "zhíjī",
        "vi": "làm thủ tục lên máy bay"
      },
      {
        "hanzi": "旅客",
        "pinyin": "lǚkè",
        "vi": "hành khách"
      },
      {
        "hanzi": "牌",
        "pinyin": "pái",
        "vi": "thẻ; biển"
      },
      {
        "hanzi": "靠",
        "pinyin": "kào",
        "vi": "dựa; sát bên"
      },
      {
        "hanzi": "窗户",
        "pinyin": "chuānghu",
        "vi": "cửa sổ"
      },
      {
        "hanzi": "转机",
        "pinyin": "zhuǎnjī",
        "vi": "chuyển chuyến bay"
      },
      {
        "hanzi": "从中",
        "pinyin": "cóngzhōng",
        "vi": "từ trong đó"
      },
      {
        "hanzi": "总结",
        "pinyin": "zǒngjié",
        "vi": "tổng kết"
      },
      {
        "hanzi": "道路",
        "pinyin": "dàolù",
        "vi": "đường sá"
      },
      {
        "hanzi": "特点",
        "pinyin": "tèdiǎn",
        "vi": "đặc điểm"
      },
      {
        "hanzi": "所有",
        "pinyin": "suǒyǒu",
        "vi": "tất cả"
      },
      {
        "hanzi": "意见",
        "pinyin": "yìjiàn",
        "vi": "ý kiến"
      },
      {
        "hanzi": "细",
        "pinyin": "xì",
        "vi": "chi tiết; nhỏ"
      },
      {
        "hanzi": "烦恼",
        "pinyin": "fánnǎo",
        "vi": "phiền não"
      },
      {
        "hanzi": "百分之",
        "pinyin": "bǎi fēn zhī",
        "vi": "phần trăm"
      },
      {
        "hanzi": "节省",
        "pinyin": "jiéshěng",
        "vi": "tiết kiệm"
      },
      {
        "hanzi": "当",
        "pinyin": "dàng",
        "vi": "coi là"
      },
      {
        "hanzi": "红包",
        "pinyin": "hóngbāo",
        "vi": "lì xì; phong bao đỏ"
      },
      {
        "hanzi": "卷",
        "pinyin": "juàn",
        "vi": "quyển; tập"
      },
      {
        "hanzi": "里",
        "pinyin": "lǐ",
        "vi": "dặm Trung Quốc"
      },
      {
        "hanzi": "要是",
        "pinyin": "yàoshi",
        "vi": "nếu"
      },
      {
        "hanzi": "少数",
        "pinyin": "shǎoshù",
        "vi": "thiểu số"
      },
      {
        "hanzi": "民族",
        "pinyin": "mínzú",
        "vi": "dân tộc"
      },
      {
        "hanzi": "导游",
        "pinyin": "dǎoyóu",
        "vi": "hướng dẫn viên du lịch; hướng dẫn tham quan"
      },
      {
        "hanzi": "解释",
        "pinyin": "jiěshì",
        "vi": "giải thích"
      },
      {
        "hanzi": "泼",
        "pinyin": "pō",
        "vi": "té; hắt (nước)"
      },
      {
        "hanzi": "流利",
        "pinyin": "liúlì",
        "vi": "lưu loát"
      },
      {
        "hanzi": "杭州",
        "pinyin": "Hángzhōu",
        "vi": "Hàng Châu",
        "properNoun": true
      },
      {
        "hanzi": "西湖",
        "pinyin": "Xī Hú",
        "vi": "Tây Hồ",
        "properNoun": true
      },
      {
        "hanzi": "苏州",
        "pinyin": "Sūzhōu",
        "vi": "Tô Châu",
        "properNoun": true
      },
      {
        "hanzi": "苏州园林",
        "pinyin": "Sūzhōu Yuánlín",
        "vi": "Vườn cổ Tô Châu",
        "properNoun": true
      },
      {
        "hanzi": "老舍",
        "pinyin": "Lǎoshě",
        "vi": "Lão Xá",
        "properNoun": true
      },
      {
        "hanzi": "唐诗",
        "pinyin": "Tángshī",
        "vi": "thơ Đường",
        "properNoun": true
      },
      {
        "hanzi": "泼水节",
        "pinyin": "Pōshuǐjié",
        "vi": "lễ hội té nước",
        "properNoun": true
      },
      {
        "hanzi": "西双版纳",
        "pinyin": "Xīshuāngbǎnnà",
        "vi": "Tây Song Bản Nạp",
        "properNoun": true
      },
      {
        "hanzi": "唐装",
        "pinyin": "Tángzhuāng",
        "vi": "trang phục kiểu Đường",
        "properNoun": true
      }
    ],
    "texts": [
      {
        "id": 1,
        "title": "课文 1",
        "content": "安妮：终于上车了，刚刚路上堵车，差点儿晚了。\n白家月：没关系，晚了就改乘下一趟。天中，你坐哪儿？看你一直不坐下，我还在想，难道你买的是无座票吗？\n陈天中：我的座位就在前边，我想先站这儿跟你们说说话。\n安妮：动车车速也挺快啊！对了，这列车晚上七点多到杭州，咱们在车上吃晚餐，到站后就先去西湖吧，夜里的西湖更美。\n陈天中：好！后天我们坐大巴去苏州，看苏州园林。\n白家月：嗯。中国太大了！真是看也看不完啊。",
        "sourcePages": [
          116,
          117
        ],
        "targets": [
          "堵车",
          "乘",
          "难道",
          "无",
          "动车",
          "车速",
          "列",
          "晚餐",
          "夜",
          "大巴"
        ]
      },
      {
        "id": 2,
        "title": "课文 2",
        "content": "李文：安检完就等着登机了。你们在看什么？\n白家月：我在读老舍的小说。\n陈天中：我读的是一本中国历史书。\n安妮：我读唐诗呢。几千年的中国文化，真是读也读不完。\n李文：谁说不是呢？不过，现在咱们得去排队，航班的值机员在叫大家登机呢——\n（值机员的话）去西安的旅客开始登机，请拿好登机牌按顺序排队。\n……\n白家月：终于上来了，我的座位靠窗户。\n安妮：我在最外边。这么多人，是不是跟咱们一样，都是去感受泼水节的啊？\n李文：应该不是。很多人的目的是西安，你别忘了，咱们是在西安转机，然后再飞西双版纳。",
        "sourcePages": [
          119
        ],
        "targets": [
          "安检",
          "登机",
          "小说",
          "航班",
          "值机",
          "旅客",
          "牌",
          "靠",
          "窗户",
          "转机"
        ]
      },
      {
        "id": 3,
        "title": "课文 3",
        "content": "来中国留学后，白家月、安妮和陈天中常外出旅行，从中了解中国。他们还总结出几点旅行经验：\n第一，好计划是成功的一半。旅行前，要了解目的地天气、道路交通特点等，安排好每天的活动，保证所有人对计划都没意见。准备越细，烦恼越少。\n第二，节假日早点儿订机票、酒店和各种门票，否则很难订到。\n第三，转机会比直飞更便宜。此次去西双版纳，在西安转机，机票价格比直飞便宜了百分之四十多。虽然有些累，但累就累点儿吧，花更少的钱去看更多的地方，很值得，节省下来的钱就当是给自己的大“红包”了。",
        "sourcePages": [
          121
        ],
        "targets": [
          "从中",
          "总结",
          "道路",
          "特点",
          "所有",
          "意见",
          "烦恼",
          "转机",
          "百分之",
          "节省"
        ]
      },
      {
        "id": 4,
        "title": "课文 4",
        "content": "王一飞常对她的学生说：“读万卷书，行万里路。你们要是想多了解中国，就不能只通过读书，还要多出门旅行，否则只能认识课本里的中国。”\n旅行，不仅能看到自然美景，还能近距离感受不同的历史文化。比如，白家月等人想了解少数民族泼水节，就去了西双版纳。泼水节上，导游向他们解释说，被泼的水越多，新的一年就会越健康、幸福。安妮喜欢唐诗，就来到了西安，在那里遇到身穿唐装的“对诗人”，对诗人说上句，游客就能流利地说出下句。安妮觉得在西安，唐诗活了。\n虽然已经去了很多地方，但是白家月他们觉得还不够。他们也认为，美丽中国，不只是在书中，更是在脚下。",
        "sourcePages": [
          123,
          124
        ],
        "targets": [
          "卷",
          "里",
          "要是",
          "少数",
          "民族",
          "泼",
          "导游",
          "解释",
          "流利"
        ]
      }
    ],
    "translations": [
      {
        "vi": "Vào ngày lễ nên đặt vé máy bay, khách sạn và các loại vé sớm một chút, nếu không rất khó đặt được.",
        "zh": "节假日早点儿订机票、酒店和各种门票，否则很难订到。"
      },
      {
        "vi": "Khi đi du lịch, chúng ta không chỉ có thể ngắm cảnh đẹp thiên nhiên mà còn có thể cảm nhận lịch sử và văn hóa khác nhau ở khoảng cách gần.",
        "zh": "旅行，不仅能看到自然美景，还能近距离感受不同的历史文化。"
      },
      {
        "vi": "Nếu các bạn muốn hiểu thêm về Trung Quốc thì không thể chỉ đọc sách mà còn phải đi du lịch nhiều hơn.",
        "zh": "你们要是想多了解中国，就不能只通过读书，还要多出门旅行。"
      }
    ]
  }
];
