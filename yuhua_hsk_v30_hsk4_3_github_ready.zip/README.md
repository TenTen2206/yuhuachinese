# YuHua Chinese — v30

## HSK 3.0 / HSK 4
20 bài, 80 bài khóa (4/bài); 799 mục từ đánh số + 38 tên riêng, 837 mục từ theo từng bài; 60 câu luyện dịch Việt–Trung do biên soạn dựa trên bài khóa.
Giáo trình nguồn: 新HSK教程4上 (bài 1–10), 新HSK教程4下 (bài 11–20). Nội dung được nhập thủ công từ bản scan; nghĩa tiếng Việt do biên soạn, nên có thể còn lỗi chép nhỏ. Không sao chép bản PDF vào website.

Từ vựng, phát âm 2 tốc độ, ngữ pháp, 4 bài khóa, pinyin tự động, flashcard, dịch và đối chiếu đáp án, điền từ (tối đa 10 chỗ trống/bài khóa), mini quiz 8 câu, ôn tập toàn cấp (12 câu), test cuối khóa (25 câu), tiến độ riêng cho HSK4. Dữ liệu HSK1–3 giữ nguyên. HSK5–6 và HSK2.0 không thêm dữ liệu. Giọng nữ ưu tiên theo thiết bị; pinyin bài khóa cần tải thư viện pinyin-pro qua CDN. Không AI, API key hay đăng nhập.

## Deploy
Giải nén ZIP và upload các file trong thư mục gốc vào repository hiện tại: index.html, style-v4.css, hsk1-data.js, hsk2-data.js, data-v4.js, hsk4-data.js, app-v30.js, hero-yuhua.png. Không cần thay đổi thiết lập GitHub Pages.
