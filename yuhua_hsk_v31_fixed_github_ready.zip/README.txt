YuHua Chinese v31

Chỉ cần upload index.html vào đúng thư mục nguồn GitHub Pages, thay file index.html cũ. Không upload ZIP trực tiếp. Dữ liệu HSK 1–4, CSS, JavaScript và logo đã tích hợp trong file. Pinyin tự động vẫn cần CDN; phát âm dùng giọng của trình duyệt.

Kiểm tra trang hiển thị v31. Chọn Ôn tập bài học → HSK 3.0 → HSK 4. Hoặc mở https://tenten2206.github.io/chineseyuhua/?system=3.0&level=4&v=31

Dữ liệu HSK4 giữ nguyên v30. Không thay đổi nội dung HSK1–3. Không cần đăng nhập hay API.
